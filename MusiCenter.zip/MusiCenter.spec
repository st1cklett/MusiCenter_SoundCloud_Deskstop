# -*- mode: python ; coding: utf-8 -*-
# MusiCenter   ONEFILE build spec
# v39: Rust/musiaudio removed — audio handled by Web Audio API in browser.
# Produces ONE portable EXE (~35-45 MB) with everything inside.
# Run:  pyinstaller MusiCenter.spec
# Or:   build.bat  (does pip install + pyinstaller in one step)

import sys
from PyInstaller.utils.hooks import collect_all, collect_data_files

block_cipher = None

# Collect EVERYTHING from pywebview (all platform backends + JS assets)
webview_datas, webview_binaries, webview_hiddenimports = collect_all('webview')
certifi_datas = collect_data_files('certifi')

a = Analysis(
    ['main.py'],
    pathex=[],
    binaries=webview_binaries,
    datas=[
        ('web', 'web'),
        *webview_datas,
        *certifi_datas,
    ],
    hiddenimports=[
        # --- pywebview ---
        'webview',
        'webview.platforms',
        'webview.platforms.winforms',
        'webview.platforms.edgechromium',
        'webview.platforms.mshtml',
        'webview.js',
        *webview_hiddenimports,
        # --- .NET / CLR (pywebview Windows backend) ---
        'clr_loader',
        'pythonnet',
        # --- Flask stack ---
        'flask',
        'flask.templating',
        'flask.logging',
        'jinja2',
        'jinja2.ext',
        'werkzeug',
        'werkzeug.serving',
        'werkzeug.routing',
        'werkzeug.middleware',
        'werkzeug.middleware.proxy_fix',
        # --- HTTP / SSL ---
        'requests',
        'urllib3',
        'urllib3.util',
        'certifi',
        'charset_normalizer',
        'idna',
        # --- misc ---
        'bottle',
        'pystray',
        'PIL',
        'PIL.Image',
        'engineio',
        'email',
        'email.mime',
        'email.mime.text',
        'http',
        'http.server',
        'xml',
        'xml.etree',
        'xml.etree.ElementTree',
        'threading',
        'logging',
        'json',
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        'tkinter', '_tkinter',
        'pytest',
        'numpy', 'pandas', 'matplotlib', 'scipy',
        'PIL', 'cv2', 'pygame',
        'IPython', 'notebook',
        'wx', 'gi', 'gtk',
    ],
    noarchive=False,
    optimize=1,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

#     ONEFILE   single portable EXE
exe = EXE(
    pyz,
    a.scripts,
    a.binaries,      # <-- include binaries in EXE
    a.datas,         # <-- include datas in EXE
    [],
    name='MusiCenter',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=['vcruntime140.dll', 'python*.dll', 'WebView2Loader.dll'],
    console=False,
    icon='web\\assets\\icon.ico',
    # onefile runtime temp dir uses sys._MEIPASS   no install needed
)
