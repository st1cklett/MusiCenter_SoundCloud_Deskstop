@echo off
setlocal enabledelayedexpansion
echo ================================================
echo   MusiCenter - Build Single Portable EXE
echo   v39: Web Audio API (no Rust required!)
echo ================================================
echo.

REM -- Step 1: Python deps --------------------------------------
echo [1/3] Installing Python dependencies...
pip install --upgrade pyinstaller pywebview flask requests pythonnet clr-loader pystray Pillow --quiet
if errorlevel 1 (
    echo ERROR: pip install failed!
    pause & exit /b 1
)
echo      Dependencies installed OK
echo.

REM -- Step 2: Clean --------------------------------------------
echo [2/3] Cleaning previous build...
if exist build  rmdir /s /q build
if exist dist   rmdir /s /q dist
echo      Cleaned OK
echo.

REM -- Step 3: PyInstaller --------------------------------------
echo [3/3] Building EXE (may take 2-5 minutes)...
python -m PyInstaller --noconfirm MusiCenter.spec
if errorlevel 1 goto :error_build

if not exist "dist\MusiCenter.exe" goto :error_build

echo.
echo ================================================
echo   BUILD SUCCESS!
echo.
echo   File: dist\MusiCenter.exe
echo   Runs WITHOUT Python, WITHOUT Rust, WITHOUT any install.
echo   Requires: Windows 10/11 with WebView2.
echo ================================================
pause & exit /b 0

:error_build
echo.
echo ================================================
echo   BUILD FAILED!
echo   Fixes:
echo   1. pip install --upgrade pyinstaller pywebview
echo   2. Use Python 3.9-3.12 (3.13 may have issues)
echo   3. Run as Administrator
echo ================================================
pause & exit /b 1
