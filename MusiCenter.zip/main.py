"""MusiCenter - SoundCloud Desktop Client"""
import os
import sys
import json
import logging
import threading
import time
import struct
import zlib
import webview
from server import create_app


def get_resource_path(relative_path):
    if hasattr(sys, '_MEIPASS'):
        return os.path.join(sys._MEIPASS, relative_path)
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), relative_path)


def get_appdata_path():
    appdata = os.environ.get('APPDATA', os.path.expanduser('~'))
    path = os.path.join(appdata, 'MusiCenter')
    os.makedirs(path, exist_ok=True)
    return path


def setup_logging(appdata_dir):
    """Session-based logging: each session creates its own log file.
    Maximum 5 log files are kept; oldest is deleted when 6th is created.
    
    Crash-safe: uses line-buffered writes so logs are preserved even on crash/hang."""
    import glob
    import atexit
    from datetime import datetime

    logs_dir = os.path.join(appdata_dir, 'logs')
    os.makedirs(logs_dir, exist_ok=True)

    existing = sorted(glob.glob(os.path.join(logs_dir, 'session_*.log')))
    while len(existing) >= 5:
        try:
            os.remove(existing.pop(0))
        except Exception:
            break

    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    log_path = os.path.join(logs_dir, f'session_{timestamp}.log')

    log_file = open(log_path, 'w', encoding='utf-8', buffering=1)
    file_handler = logging.StreamHandler(log_file)
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(logging.Formatter('%(asctime)s [%(levelname)s] %(name)s: %(message)s'))

    logging.basicConfig(
        level=logging.DEBUG,
        format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
        handlers=[file_handler]
    )

    def _flush_logs():
        try:
            file_handler.flush()
            log_file.flush()
        except Exception:
            pass
    atexit.register(_flush_logs)

    import signal
    def _signal_handler(signum, frame):
        _flush_logs()
        os._exit(1)
    try:
        signal.signal(signal.SIGTERM, _signal_handler)
    except Exception:
        pass

    logger = logging.getLogger('MusiCenter')
    logger.info(f'[Logging] New session log: {log_path}')
    logger.info(f'[Logging] Logs directory: {logs_dir}')
    logger.info(f'[Logging] Crash-safe mode: line-buffered writes enabled')
    return logger


def read_background_mode(appdata_dir):
    """Read backgroundMode from storage.json before JS loads."""
    try:
        path = os.path.join(appdata_dir, 'storage.json')
        if os.path.exists(path):
            with open(path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            settings = data.get('settings', {})
            return bool(settings.get('backgroundMode', False))
    except Exception:
        pass
    return False


class NativeTray:
    WM_DESTROY       = 0x0002
    WM_COMMAND       = 0x0111
    WM_LBUTTONUP     = 0x0202
    WM_LBUTTONDBLCLK = 0x0203
    WM_RBUTTONUP     = 0x0205
    WM_TRAY          = 0x0401

    NIM_ADD    = 0
    NIM_MODIFY = 1
    NIM_DELETE = 2
    NIF_MESSAGE = 0x01
    NIF_ICON    = 0x02
    NIF_TIP     = 0x04

    MF_STRING    = 0x0000
    MF_SEPARATOR = 0x0800
    TPM_RIGHTBUTTON = 0x0002
    TPM_BOTTOMALIGN = 0x0020
    TPM_RETURNCMD   = 0x0100

    WS_POPUP = 0x80000000

    ID_SHOW = 2001
    ID_QUIT = 2002

    def __init__(self, on_show, on_quit, logger):
        self._on_show  = on_show
        self._on_quit  = on_quit
        self._log      = logger
        self._tooltip  = 'MusiCenter'
        self._hwnd     = None
        self._hicon    = None
        self._started  = False
        self._icon_visible = False
        self._lock     = threading.Lock()
        self._wnd_proc = None
        self._wm_taskbarcreated = 0
        self._ready_event = threading.Event()


    def start(self):
        """Start the message-loop thread and create the hidden window."""
        if self._started:
            return
        t = threading.Thread(target=self._message_loop,
                              daemon=True, name='tray-loop')
        t.start()
        self._ready_event.wait(timeout=2.0)

    def show_icon(self):
        """Add / restore the icon in the tray."""
        with self._lock:
            if self._icon_visible or not self._hwnd:
                return
            self._shell_notify(self.NIM_ADD)
            self._icon_visible = True
            self._log.info('[Tray] Icon shown')

    def hide_icon(self):
        """Remove the icon from the tray (background mode disabled)."""
        with self._lock:
            if not self._icon_visible or not self._hwnd:
                return
            self._shell_notify(self.NIM_DELETE)
            self._icon_visible = False
            self._log.info('[Tray] Icon hidden')

    def set_tooltip(self, text):
        self._tooltip = (text or 'MusiCenter')[:127]
        with self._lock:
            if self._icon_visible and self._hwnd:
                self._shell_notify(self.NIM_MODIFY)

    def destroy(self):
        """Full shutdown — called on app quit."""
        with self._lock:
            if self._icon_visible and self._hwnd:
                self._shell_notify(self.NIM_DELETE)
                self._icon_visible = False
        if self._hwnd:
            try:
                import ctypes
                import ctypes.wintypes as wt
                _user32 = ctypes.windll.user32
                _user32.PostMessageW.argtypes = (wt.HWND, wt.UINT, wt.WPARAM, wt.LPARAM)
                _user32.PostMessageW.restype = wt.BOOL
                _user32.PostMessageW(self._hwnd, self.WM_DESTROY, 0, 0)
            except Exception:
                pass


    def _message_loop(self):
        import ctypes
        import ctypes.wintypes as wt

        self._started = True
        user32   = ctypes.windll.user32
        kernel32 = ctypes.windll.kernel32
        shell32  = ctypes.windll.shell32

        try:
            uxtheme = ctypes.WinDLL('uxtheme')
            SetPreferredAppMode = uxtheme[135]
            SetPreferredAppMode.argtypes = (ctypes.c_int,)
            SetPreferredAppMode.restype = ctypes.c_int
            SetPreferredAppMode(2)
            try:
                FlushMenuThemes = uxtheme[136]
                FlushMenuThemes.argtypes = ()
                FlushMenuThemes.restype = None
                FlushMenuThemes()
            except Exception:
                pass
            self._log.info('[Tray] Dark menu mode enabled (ordinal 135+136)')
        except Exception as e:
            self._log.warning(f'[Tray] Dark menu not available: {e}')


        kernel32.GetModuleHandleW.argtypes = (wt.LPCWSTR,)
        kernel32.GetModuleHandleW.restype = wt.HINSTANCE

        WNDPROCTYPE = ctypes.WINFUNCTYPE(
            ctypes.c_long, wt.HWND, wt.UINT, wt.WPARAM, wt.LPARAM)

        user32.RegisterClassExW.restype = wt.ATOM

        user32.CreateWindowExW.argtypes = (
            wt.DWORD, wt.LPCWSTR, wt.LPCWSTR, wt.DWORD,
            ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
            wt.HWND, wt.HMENU, wt.HINSTANCE, wt.LPVOID)
        user32.CreateWindowExW.restype = wt.HWND

        user32.DefWindowProcW.argtypes = (wt.HWND, wt.UINT, wt.WPARAM, wt.LPARAM)
        user32.DefWindowProcW.restype = ctypes.c_long

        user32.GetMessageW.argtypes = (ctypes.c_void_p, wt.HWND, wt.UINT, wt.UINT)
        user32.GetMessageW.restype = wt.BOOL

        user32.TranslateMessage.argtypes = (ctypes.c_void_p,)
        user32.TranslateMessage.restype = wt.BOOL

        user32.DispatchMessageW.argtypes = (ctypes.c_void_p,)
        user32.DispatchMessageW.restype = ctypes.c_long

        user32.PostQuitMessage.argtypes = (ctypes.c_int,)
        user32.PostQuitMessage.restype = None

        user32.RegisterWindowMessageW.argtypes = (wt.LPCWSTR,)
        user32.RegisterWindowMessageW.restype = wt.UINT

        user32.CreatePopupMenu.argtypes = ()
        user32.CreatePopupMenu.restype = wt.HMENU

        user32.AppendMenuW.argtypes = (wt.HMENU, wt.UINT, ctypes.c_uint, wt.LPCWSTR)
        user32.AppendMenuW.restype = wt.BOOL

        user32.SetForegroundWindow.argtypes = (wt.HWND,)
        user32.SetForegroundWindow.restype = wt.BOOL

        user32.TrackPopupMenu.argtypes = (
            wt.HMENU, wt.UINT, ctypes.c_int, ctypes.c_int,
            ctypes.c_int, wt.HWND, ctypes.c_void_p)
        user32.TrackPopupMenu.restype = ctypes.c_int

        user32.DestroyMenu.argtypes = (wt.HMENU,)
        user32.DestroyMenu.restype = wt.BOOL

        user32.GetCursorPos.argtypes = (ctypes.c_void_p,)
        user32.GetCursorPos.restype = wt.BOOL

        user32.PostMessageW.argtypes = (wt.HWND, wt.UINT, wt.WPARAM, wt.LPARAM)
        user32.PostMessageW.restype = wt.BOOL

        user32.LoadImageW.argtypes = (
            wt.HINSTANCE, wt.LPCWSTR, wt.UINT,
            ctypes.c_int, ctypes.c_int, wt.UINT)
        user32.LoadImageW.restype = wt.HANDLE

        user32.LoadIconW.argtypes = (wt.HINSTANCE, wt.LPCWSTR)
        user32.LoadIconW.restype = wt.HICON

        user32.CreateIconFromResourceEx.argtypes = (
            ctypes.c_char_p, wt.DWORD, wt.BOOL, wt.DWORD,
            ctypes.c_int, ctypes.c_int, wt.UINT)
        user32.CreateIconFromResourceEx.restype = wt.HICON

        shell32.Shell_NotifyIconW.argtypes = (wt.DWORD, ctypes.c_void_p)
        shell32.Shell_NotifyIconW.restype = wt.BOOL

        self._wm_taskbarcreated = user32.RegisterWindowMessageW('TaskbarCreated')


        @WNDPROCTYPE
        def wnd_proc(hwnd, msg, wparam, lparam):
            if self._wm_taskbarcreated and msg == self._wm_taskbarcreated:
                self._log.info('[Tray] TaskbarCreated — re-adding icon')
                with self._lock:
                    if self._icon_visible:
                        self._shell_notify(self.NIM_ADD)
                return 0

            if msg == self.WM_TRAY:
                ev = lparam & 0xFFFF
                if ev in (self.WM_LBUTTONUP, self.WM_LBUTTONDBLCLK):
                    self._on_show()
                elif ev == self.WM_RBUTTONUP:
                    self._popup_menu(hwnd)
                return 0
            if msg == self.WM_COMMAND:
                cid = wparam & 0xFFFF
                if cid == self.ID_SHOW:
                    self._on_show()
                elif cid == self.ID_QUIT:
                    self._on_quit()
                return 0
            if msg == self.WM_DESTROY:
                user32.PostQuitMessage(0)
                return 0
            return user32.DefWindowProcW(hwnd, msg, wparam, lparam)

        self._wnd_proc = wnd_proc

        class WNDCLASSEX(ctypes.Structure):
            _fields_ = [
                ('cbSize',        wt.UINT),
                ('style',         wt.UINT),
                ('lpfnWndProc',   WNDPROCTYPE),
                ('cbClsExtra',    ctypes.c_int),
                ('cbWndExtra',    ctypes.c_int),
                ('hInstance',     wt.HINSTANCE),
                ('hIcon',         wt.HICON),
                ('hCursor',       wt.HANDLE),
                ('hbrBackground', wt.HANDLE),
                ('lpszMenuName',  wt.LPCWSTR),
                ('lpszClassName', wt.LPCWSTR),
                ('hIconSm',       wt.HICON),
            ]

        hinstance  = kernel32.GetModuleHandleW(None)
        class_name = 'MusiCenterTray_v3'

        wc             = WNDCLASSEX()
        wc.cbSize      = ctypes.sizeof(WNDCLASSEX)
        wc.lpfnWndProc = wnd_proc
        wc.hInstance   = hinstance
        wc.lpszClassName = class_name

        atom = user32.RegisterClassExW(ctypes.byref(wc))
        if not atom:
            self._log.warning('[Tray] RegisterClassExW returned 0 (may already be registered)')

        hwnd = user32.CreateWindowExW(
            0,
            class_name,
            'MusiCenter Tray',
            self.WS_POPUP,
            0, 0, 0, 0,
            None,
            None,
            hinstance,
            None
        )
        if not hwnd:
            self._log.error('[Tray] CreateWindowExW failed')
            self._ready_event.set()
            return

        self._hwnd  = hwnd
        self._hicon = self._build_hicon()
        self._log.info(f'[Tray] Hidden popup window created (hwnd={hwnd})')
        self._ready_event.set()

        class MSG(ctypes.Structure):
            _fields_ = [
                ('hwnd',    wt.HWND),
                ('message', wt.UINT),
                ('wParam',  wt.WPARAM),
                ('lParam',  wt.LPARAM),
                ('time',    wt.DWORD),
                ('pt',      ctypes.c_long * 2),
            ]

        msg = MSG()
        while True:
            r = user32.GetMessageW(ctypes.byref(msg), None, 0, 0)
            if r <= 0:
                break
            user32.TranslateMessage(ctypes.byref(msg))
            user32.DispatchMessageW(ctypes.byref(msg))

        self._log.info('[Tray] Message loop exited')

    def _shell_notify(self, action):
        """Must be called with self._lock held (or during init)."""
        import ctypes
        import ctypes.wintypes as wt

        class NOTIFYICONDATAW(ctypes.Structure):
            _fields_ = [
                ('cbSize',           wt.DWORD),
                ('hWnd',             wt.HWND),
                ('uID',              wt.UINT),
                ('uFlags',           wt.UINT),
                ('uCallbackMessage', wt.UINT),
                ('hIcon',            wt.HICON),
                ('szTip',            wt.WCHAR * 128),
                ('dwState',          wt.DWORD),
                ('dwStateMask',      wt.DWORD),
                ('szInfo',           wt.WCHAR * 256),
                ('uVersion',         wt.UINT),
                ('szInfoTitle',      wt.WCHAR * 64),
                ('dwInfoFlags',      wt.DWORD),
            ]

        nid = NOTIFYICONDATAW()
        nid.cbSize           = ctypes.sizeof(NOTIFYICONDATAW)
        nid.hWnd             = self._hwnd
        nid.uID              = 1
        nid.uFlags           = self.NIF_MESSAGE | self.NIF_ICON | self.NIF_TIP
        nid.uCallbackMessage = self.WM_TRAY
        nid.hIcon            = self._hicon or 0
        nid.szTip            = self._tooltip

        result = ctypes.windll.shell32.Shell_NotifyIconW(
            action, ctypes.byref(nid))
        if not result:
            self._log.warning(f'[Tray] Shell_NotifyIconW({action}) returned FALSE')
        return result

    def _popup_menu(self, hwnd):
        import ctypes
        import ctypes.wintypes as wt

        class POINT(ctypes.Structure):
            _fields_ = [('x', wt.LONG), ('y', wt.LONG)]

        user32 = ctypes.windll.user32
        pt = POINT()
        user32.GetCursorPos(ctypes.byref(pt))

        hmenu = user32.CreatePopupMenu()
        user32.AppendMenuW(hmenu, self.MF_STRING,    self.ID_SHOW,
                           'Открыть MusiCenter')
        user32.AppendMenuW(hmenu, self.MF_SEPARATOR, 0, None)
        user32.AppendMenuW(hmenu, self.MF_STRING,    self.ID_QUIT,
                           'Выход')

        user32.SetForegroundWindow(hwnd)
        cmd = user32.TrackPopupMenu(
            hmenu,
            self.TPM_RIGHTBUTTON | self.TPM_BOTTOMALIGN | self.TPM_RETURNCMD,
            pt.x, pt.y, 0, hwnd, None
        )
        user32.DestroyMenu(hmenu)

        if cmd == self.ID_SHOW:
            self._on_show()
        elif cmd == self.ID_QUIT:
            self._on_quit()

    def _build_hicon(self):
        import ctypes

        ico_path = get_resource_path('web/assets/icon.ico')
        if os.path.exists(ico_path):
            IMAGE_ICON = 1
            LR_LOADFROMFILE = 0x0010
            LR_DEFAULTSIZE  = 0x0040
            h = ctypes.windll.user32.LoadImageW(
                None, ico_path, IMAGE_ICON,
                32, 32, LR_LOADFROMFILE | LR_DEFAULTSIZE
            )
            if h:
                self._log.info(f'[Tray] Icon loaded: {ico_path}')
                return h

        try:
            data = self._make_ico_bytes()
            h = ctypes.windll.user32.CreateIconFromResourceEx(
                data, len(data), True, 0x00030000, 32, 32, 0)
            if h:
                self._log.info('[Tray] Icon built from inline bytes')
                return h
        except Exception as e:
            self._log.warning(f'[Tray] Inline icon error: {e}')

        try:
            IDI_APPLICATION = ctypes.cast(32512, ctypes.c_wchar_p)
            h = ctypes.windll.user32.LoadIconW(None, IDI_APPLICATION)
            self._log.info('[Tray] Using system default icon')
            return h
        except Exception:
            return 0

    @staticmethod
    def _make_ico_bytes():
        size = 32
        cx = cy = size / 2 - 0.5
        r_max = size / 2 - 1.0

        raw = bytearray()
        for y in range(size):
            raw += b'\x00'
            for x in range(size):
                dx, dy = x - cx, y - cy
                dist = (dx * dx + dy * dy) ** 0.5
                if dist <= r_max:
                    t   = max(0.0, min(1.0, dist / r_max))
                    g_c = int(85 + (170 - 85) * (1 - t))
                    a_c = int(255 * max(0.0, min(1.0, r_max - dist + 1.0)))
                    raw += bytes([255, g_c, 0, a_c])
                else:
                    raw += b'\x00\x00\x00\x00'

        def chunk(tag, data):
            crc = zlib.crc32(tag + data) & 0xFFFFFFFF
            return struct.pack('>I', len(data)) + tag + data + struct.pack('>I', crc)

        ihdr = struct.pack('>IIBBBBB', size, size, 8, 6, 0, 0, 0)
        png  = (b'\x89PNG\r\n\x1a\n'
                + chunk(b'IHDR', ihdr)
                + chunk(b'IDAT', zlib.compress(bytes(raw), 9))
                + chunk(b'IEND', b''))

        ico_hdr = struct.pack('<HHH', 0, 1, 1)
        ico_dir = struct.pack('<BBBBHHII',
                              size, size, 0, 0, 1, 32, len(png), 22)
        return ico_hdr + ico_dir + png


class WindowApi:

    def __init__(self, win, logger, initial_bg_mode=False):
        self._win        = win
        self._log        = logger
        self._maximized  = False
        self._hidden     = False
        self._bg_mode    = False
        self._resize_t   = 0
        self._track_title = 'MusiCenter'

        self._tray = NativeTray(
            on_show=self.show_window,
            on_quit=self.force_quit,
            logger=logger,
        )
        self._tray.start()

        if initial_bg_mode:
            self._bg_mode = True
            self._tray.show_icon()
            logger.info('[Tray] Background mode pre-enabled from saved settings')

    _hwnd = None

    def minimize(self):
        self._log.info('[Window] minimize()')
        self._win.minimize()

    def toggle_maximize(self):
        self._log.info('[Window] toggle_maximize()')
        self._maximized = not self._maximized
        if self._maximized:
            self._win.maximize()
        else:
            self._win.restore()

    _fullscreen = False
    _fs_prev_style = None
    _fs_prev_rect = None

    def toggle_fullscreen(self):
        """True Win32 fullscreen — covers taskbar, no borders, entire monitor."""
        self._log.info(f'[Window] toggle_fullscreen() current={self._fullscreen}')
        hwnd = self.__class__._hwnd
        if not hwnd:
            self._win.toggle_fullscreen()
            return

        try:
            import ctypes
            import ctypes.wintypes as wt

            _u32 = ctypes.windll.user32

            GWL_STYLE = -16
            WS_OVERLAPPEDWINDOW = 0x00CF0000
            SWP_FRAMECHANGED = 0x0020
            SWP_NOOWNERZORDER = 0x0200
            HWND_TOP = 0
            MONITOR_DEFAULTTONEAREST = 2
            SM_CXSCREEN = 0
            SM_CYSCREEN = 1

            class MONITORINFO(ctypes.Structure):
                _fields_ = [
                    ('cbSize', wt.DWORD),
                    ('rcMonitor', wt.RECT),
                    ('rcWork', wt.RECT),
                    ('dwFlags', wt.DWORD),
                ]

            if not self._fullscreen:
                self._fs_prev_style = _u32.GetWindowLongW(hwnd, GWL_STYLE)
                rect = wt.RECT()
                _u32.GetWindowRect(hwnd, ctypes.byref(rect))
                self._fs_prev_rect = (rect.left, rect.top, rect.right, rect.bottom)

                hmon = _u32.MonitorFromWindow(hwnd, MONITOR_DEFAULTTONEAREST)
                mi = MONITORINFO()
                mi.cbSize = ctypes.sizeof(MONITORINFO)
                _u32.GetMonitorInfoW(hmon, ctypes.byref(mi))
                mx, my = mi.rcMonitor.left, mi.rcMonitor.top
                mw = mi.rcMonitor.right - mi.rcMonitor.left
                mh = mi.rcMonitor.bottom - mi.rcMonitor.top

                new_style = self._fs_prev_style & ~WS_OVERLAPPEDWINDOW
                _u32.SetWindowLongW(hwnd, GWL_STYLE, new_style)

                _u32.SetWindowPos(
                    hwnd, HWND_TOP,
                    mx, my, mw, mh,
                    SWP_FRAMECHANGED | SWP_NOOWNERZORDER
                )
                self._fullscreen = True
                self._log.info(f'[Window] Fullscreen ON: {mw}x{mh} at ({mx},{my})')

            else:
                if self._fs_prev_style is not None:
                    _u32.SetWindowLongW(hwnd, GWL_STYLE, self._fs_prev_style)

                if self._fs_prev_rect:
                    x, y, r, b = self._fs_prev_rect
                    _u32.SetWindowPos(
                        hwnd, HWND_TOP,
                        x, y, r - x, b - y,
                        SWP_FRAMECHANGED | SWP_NOOWNERZORDER
                    )
                else:
                    self._win.restore()

                self._fullscreen = False
                self._log.info('[Window] Fullscreen OFF: restored')

        except Exception as e:
            self._log.error(f'[Window] toggle_fullscreen error: {e}')
            self._win.toggle_fullscreen()

    def start_native_drag(self):
        """Post a custom message to the UI thread which will initiate
        a native Windows drag (ReleaseCapture + WM_NCLBUTTONDOWN).

        Why PostMessage instead of direct call?
        — JS API methods run on a worker thread.
        — ReleaseCapture() only releases capture for the *calling* thread.
        — The mouse capture is held by the UI thread (WebView2 / WinForms).
        — So we must execute ReleaseCapture on the UI thread.
        — PostMessage puts our custom WM_APP_STARTDRAG into the UI
          thread's message queue; our WndProc hook picks it up.
        """
        hwnd = self.__class__._hwnd
        if not hwnd:
            self._log.warning('[Window] start_native_drag — no hwnd yet')
            return
        try:
            import ctypes
            import ctypes.wintypes as wt
            _u32 = ctypes.windll.user32
            WM_APP_STARTDRAG = 0x8001
            _u32.PostMessageW.argtypes = (wt.HWND, wt.UINT, wt.WPARAM, wt.LPARAM)
            _u32.PostMessageW.restype = wt.BOOL
            _u32.PostMessageW(hwnd, WM_APP_STARTDRAG, 0, 0)
        except Exception as e:
            self._log.warning(f'[Window] start_native_drag error: {e}')

    def close(self):
        try:
            self._win.evaluate_js('if(typeof YandexImport!=="undefined")YandexImport.saveAndClose()')
        except Exception:
            pass
        import time as _t; _t.sleep(0.3)

        if self._bg_mode:
            self._log.info('[Window] close() → hide to tray')
            self._win.hide()
            self._hidden = True
            self._tray.set_tooltip(
                f'MusiCenter  ♪ {self._track_title}' if self._track_title != 'MusiCenter'
                else 'MusiCenter')
        else:
            self._log.info('[Window] close() → destroy')
            for handler in logging.getLogger().handlers:
                try: handler.flush()
                except Exception: pass
            self._tray.destroy()
            try:
                self._win.destroy()
            except Exception as e:
                self._log.warning(f'[Window] destroy error (WebView2 may have crashed): {e}')
            self._kill_process_tree()

    def force_quit(self):
        self._log.info('[Window] force_quit()')
        for handler in logging.getLogger().handlers:
            try: handler.flush()
            except Exception: pass
        self._tray.destroy()
        try:
            self._win.destroy()
        except Exception:
            pass
        self._log.info('[Window] force_quit() → killing all child processes')
        for handler in logging.getLogger().handlers:
            try: handler.flush()
            except Exception: pass
        self._kill_process_tree()

    @staticmethod
    def _kill_process_tree():
        """Kill current process and ALL child processes (incl. WebView2 msedgewebview2.exe).
        This ensures nothing is left in Task Manager after 'Выход'.
        ★ Uses subprocess with CREATE_NO_WINDOW to avoid flashing a cmd window."""
        import os as _os
        try:
            import subprocess
            pid = _os.getpid()
            CREATE_NO_WINDOW = 0x08000000
            subprocess.Popen(
                f'taskkill /F /T /PID {pid}',
                shell=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                creationflags=CREATE_NO_WINDOW,
            )
        except Exception:
            pass
        _os._exit(0)

    def show_window(self):
        if self._hidden:
            self._log.info('[Window] show_window() — restored from tray')
            self._win.show()
            self._hidden = False
            self._tray.set_tooltip('MusiCenter')

    def set_background_mode(self, enabled):
        enabled = bool(enabled)
        if enabled == self._bg_mode:
            return
        self._bg_mode = enabled
        self._log.info(f'[Window] background_mode → {enabled}')
        if enabled:
            self._tray.show_icon()
        else:
            self._tray.hide_icon()
            if self._hidden:
                self.show_window()

    def update_tray_track(self, title):
        """Called from JS when the track changes."""
        self._track_title = (title or 'MusiCenter')[:100]
        if self._hidden and self._bg_mode:
            self._tray.set_tooltip(f'MusiCenter  ♪ {self._track_title}')

    def get_position(self):
        try:
            return {'x': int(self._win.x), 'y': int(self._win.y),
                    'w': int(self._win.width), 'h': int(self._win.height)}
        except Exception:
            return {'x': 0, 'y': 0, 'w': 1280, 'h': 800}

    def move_to(self, x, y):
        self._win.move(int(x), int(y))

    def resize_window(self, w, h):
        now = time.monotonic()
        if now - self._resize_t < 0.033:
            return
        self._resize_t = now
        self._win.resize(max(900, int(w)), max(600, int(h)))

    def move_and_resize(self, x, y, w, h):
        now = time.monotonic()
        if now - self._resize_t < 0.033:
            return
        self._resize_t = now
        self._win.move(int(x), int(y))
        self._win.resize(max(900, int(w)), max(600, int(h)))

    def snap_maximize(self):
        self._log.info('[Window] snap_maximize()')
        self._maximized = True
        self._win.maximize()

    def snap_half(self, side):
        """Snap window to left or right half of screen."""
        self._log.info(f'[Window] snap_half({side})')
        try:
            import ctypes
            _u32 = ctypes.WinDLL('user32')
            sw = _u32.GetSystemMetrics(0)
            sh = _u32.GetSystemMetrics(1)
            from ctypes import wintypes as wt
            class RECT(ctypes.Structure):
                _fields_ = [('left', wt.LONG), ('top', wt.LONG), ('right', wt.LONG), ('bottom', wt.LONG)]
            SPI_GETWORKAREA = 0x0030
            r = RECT()
            _u32.SystemParametersInfoW(SPI_GETWORKAREA, 0, ctypes.byref(r), 0)
            wa_w = r.right - r.left
            wa_h = r.bottom - r.top
            half_w = wa_w // 2
            if side == 'left':
                self._win.move(r.left, r.top)
                self._win.resize(half_w, wa_h)
            else:
                self._win.move(r.left + half_w, r.top)
                self._win.resize(half_w, wa_h)
            self._maximized = False
        except Exception as e:
            self._log.warning(f'[Window] snap_half error: {e}')

    def js_log(self, level, message):
        lvl = getattr(logging, level.upper(), logging.INFO)
        logging.getLogger('MusiCenter.JS').log(lvl, '[JS] %s', message)


def main():
    appdata_dir = get_appdata_path()
    log = setup_logging(appdata_dir)
    log.info('=' * 60)
    log.info('MusiCenter starting up')
    log.info(f'AppData dir: {appdata_dir}')

    web_dir = get_resource_path('web')
    log.info(f'Web dir: {web_dir}')

    initial_bg = read_background_mode(appdata_dir)
    log.info(f'Saved backgroundMode={initial_bg}')

    flask_app = create_app(web_dir, appdata_dir)
    port = 18923
    log.info(f'Starting Flask on port {port}')

    flask_thread = threading.Thread(
        target=lambda: flask_app.run(
            host='127.0.0.1', port=port, debug=False, use_reloader=False,
            threaded=True),
        daemon=True
    )
    flask_thread.start()

    api = WindowApi(None, log, initial_bg_mode=initial_bg)

    log.info('Creating pywebview window')
    window = webview.create_window(
        'MusiCenter', f'http://127.0.0.1:{port}',
        width=1280, height=800, min_size=(900, 600),
        frameless=True, easy_drag=False,
        background_color='#08080a', text_select=False, js_api=api,
    )
    api._win = window

    log.info('Starting webview event loop')

    def on_shown():
        """Patch window style for native Aero Snap + native drag.

        Key changes vs previous version:
        1. WS_THICKFRAME is added → enables Windows Aero Snap (drag to
           edges/corners to tile/maximise) and Win11 snap layouts.
        2. WS_CAPTION is added (needed for correct snap animations).
        3. WM_NCCALCSIZE is intercepted (returns 0) so the thick frame
           and caption bar are *not drawn* — the window stays visually
           frameless while gaining full native window management.
        4. WM_GETMINMAXINFO is intercepted so maximise fills the work
           area (not bleeding behind the taskbar).
        """
        try:
            import ctypes
            import ctypes.wintypes as wt

            _u32 = ctypes.WinDLL('user32')

            _u32.FindWindowW.argtypes = (wt.LPCWSTR, wt.LPCWSTR)
            _u32.FindWindowW.restype = wt.HWND
            hwnd = _u32.FindWindowW(None, 'MusiCenter')
            if not hwnd:
                log.warning('[Window] FindWindowW returned 0')
                return

            WindowApi._hwnd = hwnd
            log.info(f'[Window] hwnd = {hwnd}')

            GWL_STYLE      = -16
            GWLP_WNDPROC   = -4
            WS_THICKFRAME  = 0x00040000
            WS_CAPTION      = 0x00C00000
            WS_MINIMIZEBOX = 0x00020000
            WS_MAXIMIZEBOX = 0x00010000
            WS_SYSMENU     = 0x00080000
            SWP_FRAMECHANGED = 0x0020
            SWP_NOMOVE       = 0x0002
            SWP_NOSIZE       = 0x0001
            SWP_NOZORDER     = 0x0004
            WM_NCCALCSIZE    = 0x0083
            WM_GETMINMAXINFO = 0x0024
            WM_APP_STARTDRAG = 0x8001
            WM_NCLBUTTONDOWN = 0x00A1
            HTCAPTION        = 2

            _u32.GetWindowLongW.argtypes = (wt.HWND, ctypes.c_int)
            _u32.GetWindowLongW.restype = ctypes.c_long
            _u32.SetWindowLongW.argtypes = (wt.HWND, ctypes.c_int, ctypes.c_long)
            _u32.SetWindowLongW.restype = ctypes.c_long

            try:
                _SetWndProc = _u32.SetWindowLongPtrW
                _GetWndProc = _u32.GetWindowLongPtrW
            except AttributeError:
                _SetWndProc = _u32.SetWindowLongW
                _GetWndProc = _u32.GetWindowLongW

            LRESULT = ctypes.c_longlong if ctypes.sizeof(ctypes.c_void_p) == 8 else ctypes.c_long
            WNDPROC = ctypes.WINFUNCTYPE(LRESULT, wt.HWND, wt.UINT, wt.WPARAM, wt.LPARAM)

            _SetWndProc.argtypes = (wt.HWND, ctypes.c_int, ctypes.c_void_p)
            _SetWndProc.restype = ctypes.c_void_p
            _GetWndProc.argtypes = (wt.HWND, ctypes.c_int)
            _GetWndProc.restype = ctypes.c_void_p

            _u32.CallWindowProcW.argtypes = (ctypes.c_void_p, wt.HWND, wt.UINT, wt.WPARAM, wt.LPARAM)
            _u32.CallWindowProcW.restype = LRESULT

            _u32.SetWindowPos.argtypes = (
                wt.HWND, wt.HWND, ctypes.c_int, ctypes.c_int,
                ctypes.c_int, ctypes.c_int, wt.UINT)
            _u32.SetWindowPos.restype = wt.BOOL

            _u32.GetSystemMetrics.argtypes = (ctypes.c_int,)
            _u32.GetSystemMetrics.restype = ctypes.c_int

            style = _u32.GetWindowLongW(hwnd, GWL_STYLE)
            style |= (WS_THICKFRAME | WS_CAPTION |
                       WS_MINIMIZEBOX | WS_MAXIMIZEBOX | WS_SYSMENU)
            _u32.SetWindowLongW(hwnd, GWL_STYLE, style)
            log.info(f'[Window] Style patched: +WS_THICKFRAME +WS_CAPTION')

            old_proc_ptr = _GetWndProc(hwnd, GWLP_WNDPROC)

            class MINMAXINFO(ctypes.Structure):
                class POINT(ctypes.Structure):
                    _fields_ = [('x', wt.LONG), ('y', wt.LONG)]
                _fields_ = [
                    ('ptReserved',     POINT),
                    ('ptMaxSize',      POINT),
                    ('ptMaxPosition',  POINT),
                    ('ptMinTrackSize', POINT),
                    ('ptMaxTrackSize', POINT),
                ]

            class RECT(ctypes.Structure):
                _fields_ = [('left', wt.LONG), ('top', wt.LONG),
                            ('right', wt.LONG), ('bottom', wt.LONG)]

            SPI_GETWORKAREA = 0x0030
            _u32.SystemParametersInfoW.argtypes = (wt.UINT, wt.UINT, ctypes.c_void_p, wt.UINT)
            _u32.SystemParametersInfoW.restype = wt.BOOL

            _u32.ReleaseCapture.argtypes = ()
            _u32.ReleaseCapture.restype = wt.BOOL
            _u32.SendMessageW.argtypes = (wt.HWND, wt.UINT, wt.WPARAM, wt.LPARAM)
            _u32.SendMessageW.restype = ctypes.c_long

            WM_CLOSE = 0x0010

            WM_NCHITTEST     = 0x0084
            WM_NCLBUTTONDOWN = 0x00A1
            HTCLIENT         = 1
            HTCAPTION        = 2
            HTMAXBUTTON      = 9
            SM_CXFRAME       = 32
            SM_CYFRAME       = 33
            SM_CXPADDEDBORDER = 92

            class NCCALCSIZE_PARAMS(ctypes.Structure):
                _fields_ = [('rgrc', RECT * 3), ('lppos', ctypes.c_void_p)]

            _u32.GetWindowRect.argtypes = (wt.HWND, ctypes.c_void_p)
            _u32.GetWindowRect.restype = wt.BOOL
            _u32.ScreenToClient.argtypes = (wt.HWND, ctypes.c_void_p)
            _u32.ScreenToClient.restype = wt.BOOL
            _u32.IsZoomed.argtypes = (wt.HWND,)
            _u32.IsZoomed.restype = wt.BOOL

            @WNDPROC
            def new_wnd_proc(h, msg, wp, lp):

                if msg == WM_NCCALCSIZE:
                    if not wp:
                        return 0
                    if _u32.IsZoomed(h):
                        bx = (_u32.GetSystemMetrics(SM_CXFRAME) +
                              _u32.GetSystemMetrics(SM_CXPADDEDBORDER))
                        by = (_u32.GetSystemMetrics(SM_CYFRAME) +
                              _u32.GetSystemMetrics(SM_CXPADDEDBORDER))
                        params = ctypes.cast(lp, ctypes.POINTER(NCCALCSIZE_PARAMS)).contents
                        params.rgrc[0].left   += bx
                        params.rgrc[0].top    += by
                        params.rgrc[0].right  -= bx
                        params.rgrc[0].bottom -= by
                    return 0

                if msg == WM_GETMINMAXINFO and lp:
                    mmi = ctypes.cast(lp, ctypes.POINTER(MINMAXINFO)).contents
                    wa = RECT()
                    _u32.SystemParametersInfoW(SPI_GETWORKAREA, 0, ctypes.byref(wa), 0)
                    mmi.ptMaxPosition.x = wa.left
                    mmi.ptMaxPosition.y = wa.top
                    mmi.ptMaxSize.x = wa.right - wa.left
                    mmi.ptMaxSize.y = wa.bottom - wa.top
                    return 0

                if msg == WM_NCHITTEST:
                    xs = ctypes.c_short(lp & 0xFFFF).value
                    ys = ctypes.c_short((lp >> 16) & 0xFFFF).value
                    wr = RECT()
                    _u32.GetWindowRect(h, ctypes.byref(wr))
                    cx = xs - wr.left
                    cy = ys - wr.top
                    win_w = wr.right - wr.left
                    win_h = wr.bottom - wr.top

                    BORDER = (_u32.GetSystemMetrics(SM_CXFRAME) +
                              _u32.GetSystemMetrics(SM_CXPADDEDBORDER))

                    if not _u32.IsZoomed(h):
                        HTTOPLEFT     = 13
                        HTTOP         = 12
                        HTTOPRIGHT    = 14
                        HTLEFT        = 10
                        HTRIGHT       = 11
                        HTBOTTOMLEFT  = 16
                        HTBOTTOM      = 15
                        HTBOTTOMRIGHT = 17

                        if cy < BORDER:
                            if cx < BORDER:      return HTTOPLEFT
                            if cx > win_w - BORDER: return HTTOPRIGHT
                            return HTTOP
                        if cy > win_h - BORDER:
                            if cx < BORDER:      return HTBOTTOMLEFT
                            if cx > win_w - BORDER: return HTBOTTOMRIGHT
                            return HTBOTTOM
                        if cx < BORDER:          return HTLEFT
                        if cx > win_w - BORDER:  return HTRIGHT

                    TITLEBAR_H = 36
                    if cy < TITLEBAR_H:
                        btn_right = win_w
                        btn_min_left = win_w - 138
                        btn_max_left = win_w - 92
                        btn_close_left = win_w - 46

                        if btn_max_left <= cx <= btn_close_left:
                            return HTMAXBUTTON
                        if cx >= btn_min_left:
                            return HTCLIENT
                        return HTCAPTION

                    return HTCLIENT

                if msg == WM_NCLBUTTONDOWN and wp == HTMAXBUTTON:
                    return _u32.CallWindowProcW(old_proc_ptr, h, msg, wp, lp)

                if msg == WM_APP_STARTDRAG:
                    _u32.ReleaseCapture()
                    _u32.SendMessageW(h, WM_NCLBUTTONDOWN, HTCAPTION, 0)
                    return 0

                return _u32.CallWindowProcW(old_proc_ptr, h, msg, wp, lp)

            on_shown._wnd_proc_ref = new_wnd_proc

            _SetWndProc(hwnd, GWLP_WNDPROC, ctypes.cast(new_wnd_proc, ctypes.c_void_p))
            log.info('[Window] WndProc subclassed for WM_NCCALCSIZE + WM_GETMINMAXINFO')

            _u32.SetWindowPos(
                hwnd, None, 0, 0, 0, 0,
                SWP_FRAMECHANGED | SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER)
            log.info('[Window] SetWindowPos(SWP_FRAMECHANGED) done')

        except Exception as e:
            log.warning(f'[Window] Style / WndProc patch error: {e}')

    window.events.shown += on_shown

    _closing_guard = {'active': False}

    def on_closing():
        if _closing_guard['active']:
            log.info('[Window] on_closing() → re-entrant call ignored')
            return False

        try:
            if api._bg_mode:
                _closing_guard['active'] = True
                log.info('[Window] on_closing() → hide to tray (bg_mode=True)')
                try:
                    import ctypes
                    import ctypes.wintypes as _wt
                    _sw = ctypes.windll.user32
                    _sw.ShowWindow.argtypes = (_wt.HWND, ctypes.c_int)
                    _sw.ShowWindow.restype = _wt.BOOL
                    _sw.ShowWindow(WindowApi._hwnd or 0, 0)
                except Exception as _e:
                    log.warning(f'[Window] ShowWindow(SW_HIDE) failed: {_e}')
                    try:
                        api._win.hide()
                    except Exception:
                        pass
                api._hidden = True
                api._tray.set_tooltip(
                    f'MusiCenter  ♪ {api._track_title}' if api._track_title != 'MusiCenter'
                    else 'MusiCenter')
                _closing_guard['active'] = False
                return False
            log.info('[Window] on_closing() → allowing close (bg_mode=False)')
            api._tray.destroy()
            return True
        except Exception as _closing_err:
            log.error(f'[Window] on_closing() crashed: {_closing_err}')
            _closing_guard['active'] = False
            try:
                api._tray.destroy()
            except Exception:
                pass
            return True
    window.events.closing += on_closing

    webview.start(debug=False)
    log.info('MusiCenter exited — webview loop returned, forcing clean exit')
    for handler in logging.getLogger().handlers:
        try: handler.flush()
        except Exception: pass
    WindowApi._kill_process_tree()


if __name__ == '__main__':
    main()
