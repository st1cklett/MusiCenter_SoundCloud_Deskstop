"""Этот скрипт больше не нужен.
MusiCenter v39 использует Web Audio API — Rust/MinGW/maturin не требуются.
Файл оставлен как заглушка для совместимости."""

print("tools_download.py: Rust audio удалён в v39 — MinGW не нужен.")
print("Аудио теперь работает через Web Audio API (браузерный движок).")
