

const App = {
  _initialized: false,
  _queueOpen: false,

  _port: 18923,  

  async init() {
    await Store.load();
    Player.init();

    const sessionId = Store.get('sessionId');
    if (sessionId) {
      
      let user = null;
      for (let attempt = 1; attempt <= 2; attempt++) {
        try {
          const controller = new AbortController();
          const timer = setTimeout(() => controller.abort(), 8000);
          const resp = await fetch('/api/me', {
            headers: { 'x-session-id': sessionId },
            signal: controller.signal,
          });
          clearTimeout(timer);
          if (resp.ok) {
            user = await resp.json();
          } else if (resp.status === 401) {
            
            Utils.log('info', '[App] Session expired (401) — showing login');
            Store.set({ sessionId: null });
            break;
          } else {
            Utils.log('warning', `[App] fetchUser attempt ${attempt}: HTTP ${resp.status}`);
          }
        } catch (e) {
          Utils.log('warning', `[App] fetchUser attempt ${attempt} failed: ${e.name === 'AbortError' ? 'TIMEOUT 8s' : e.message}`);
        }
        if (user) break;
        if (attempt < 2) await new Promise(r => setTimeout(r, 1500)); 
      }
      if (user && user.username) Store.set({ user, isAuthenticated: true });
      else Store.set({ isAuthenticated: false });
    }

    if (Store.get('isAuthenticated')) this._showApp();
    else this._showLogin();

    const overlay = document.getElementById('loading-overlay');
    if (overlay) {
      overlay.style.opacity = '0';
      overlay.style.transition = 'opacity 0.4s ease';
      setTimeout(() => overlay.style.display = 'none', 400);
    }

    this._initialized = true;

    Store.on('isAuthenticated', (auth) => {
      if (auth) this._showApp();
      else this._showLogin();
    });

    this._setupQueue();
    this._setupKeys();

    
    if (typeof VisibilityManager !== 'undefined') {
      VisibilityManager.onChange((visible) => {
        
        const bg = document.getElementById('app-background');
        if (bg) {
          if (visible) {
            
            if (bg._savedUrl) {
              bg.style.backgroundImage = `url(${bg._savedUrl})`;
              bg._savedUrl = null;
            }
          } else {
            
            const url = bg.style.backgroundImage;
            if (url && url.includes('.gif')) {
              bg._savedUrl = url.replace(/^url\(["']?|["']?\)$/g, '');
              // Replace with empty = GPU stops decoding GIF frames
              bg.style.backgroundImage = 'none';
            }
          }
        }

        // Sidebar timer text: skip updates when hidden
        // (NowPlayingComponent polls and updates DOM text every 100ms)
        if (typeof NowPlayingComponent !== 'undefined') {
          NowPlayingComponent._hidden = !visible;
        }
      });
    }
  },

  _showLogin() {
    ['main-layout', 'now-playing-bar', 'sidebar'].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.style.display = 'none';
    });
    const old = document.getElementById('login-container');
    if (old) old.remove();
    const loginDiv = document.createElement('div');
    loginDiv.id = 'login-container';
    loginDiv.innerHTML = LoginPage.render();
    document.getElementById('app').insertBefore(loginDiv, document.getElementById('loading-overlay'));
  },

  _showApp() {
    const loginDiv = document.getElementById('login-container');
    if (loginDiv) loginDiv.remove();
    ['main-layout', 'now-playing-bar', 'sidebar'].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.style.display = '';
    });
    SidebarComponent.init();
    NowPlayingComponent.init();
    CommentsComponent.init();
    SettingsComponent.init();
    CrossfadeEngine.init();
    SoundWave.init();
    EqualizerComponent.init();
    LyricsComponent.init();
    // Push saved EQ state to Web Audio engine after Player initialised
    setTimeout(() => EqualizerEngine.pushToAudio(), 500);
    this.navigate(Store.get('currentPage') || 'home', false);

    // Check if SoundCloud CDN images are accessible
    Utils.checkImageAccess();

    // Start bypass timeout watch
    BypassEngine.startTimeoutWatch();

    // ★ Check if there are not-found YM import tracks for sidebar tab
    YandexImport._refreshNotFound();


  },

  navigate(page, pushState = true) {
    Store.set({ currentPage: page });
    document.querySelectorAll('.nav-item').forEach(el => {
      el.classList.toggle('active', el.dataset.page === page);
    });

    // FIX: close any open home overlay before switching pages
    const openOverlay = document.getElementById('home-all-overlay');
    if (openOverlay) {
      openOverlay.remove();
      const content = document.getElementById('content');
      if (content) content.classList.remove('overlay-locked');
    }

    const container = document.getElementById('page-container');
    if (container) {
      container.style.opacity = '0';
      container.style.transform = 'translateY(8px)';
      container.style.transition = 'opacity 0.2s ease, transform 0.2s ease';

      setTimeout(() => {
        switch (page) {
          case 'home':      HomePage.render();     break;
          case 'search':    SearchPage.render();   break;
          case 'library':   LibraryPage.render();  break;
          case 'playlists': PlaylistsPage.render(); break;
          case 'liked':     CollectionPage.render('liked'); break;
          case 'recent':    CollectionPage.render('recent'); break;
          case 'ym-import': YandexImport._openNotFoundPage(); break;
          default:          HomePage.render();
        }
        const content = document.getElementById('content');
        if (content) content.scrollTop = 0;
        requestAnimationFrame(() => {
          container.style.opacity = '1';
          container.style.transform = 'translateY(0)';
        });
      }, 180);
    }

    if (pushState) {
      const hash = page === 'home' ? '#/' : `#/${page}`;
      if (window.location.hash !== hash) window.location.hash = hash;
    }
  },

  _setupQueue() {
    // ── EQ button ────────────────────────────────────────────
    const btnEq = document.getElementById('btn-eq');
    if (btnEq) btnEq.addEventListener('click', () => EqualizerComponent.toggle());

    // ── Lyrics button ────────────────────────────────────────
    const btnLyrics = document.getElementById('btn-lyrics');
    if (btnLyrics) btnLyrics.addEventListener('click', () => LyricsComponent.toggle());
  },

  toggleQueue(open) {
    const panel    = document.getElementById('queue-panel');
    const backdrop = document.getElementById('queue-backdrop');
    if (!panel || !backdrop) return;
    this._queueOpen = open != null ? open : !this._queueOpen;

    if (this._queueOpen) {
      panel.classList.remove('hidden');
      backdrop.classList.remove('hidden');
      requestAnimationFrame(() => { panel.classList.add('open'); backdrop.classList.add('open'); });
      this._renderQueue();
    } else {
      panel.classList.remove('open');
      backdrop.classList.remove('open');
      setTimeout(() => { panel.classList.add('hidden'); backdrop.classList.add('hidden'); }, 300);
    }
  },

  _renderQueue() {
    const nowPlaying = document.getElementById('queue-now-playing');
    const queueList  = document.getElementById('queue-list');
    if (!nowPlaying || !queueList) return;

    const current = Store.get('currentTrack');
    const queue   = Store.get('queue') || [];
    const idx     = Store.get('queueIndex');

    if (current) {
      const art = Utils.art(current.artwork_url, 't120x120');
      nowPlaying.innerHTML = `
        <div class="queue-now-label">Сейчас играет</div>
        <div class="queue-item current">
          <div class="queue-item-art">
            ${art ? `<img src="${Utils.esc(art)}" alt="">` : '<div class="queue-item-no-art"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.2)" stroke-width="1.5"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg></div>'}
          </div>
          <div class="queue-item-info">
            <div class="queue-item-title">${Utils.esc(current.title)}</div>
            <div class="queue-item-artist">${Utils.esc(current.user?.username || '')}</div>
          </div>
          <div class="queue-item-dur">${Utils.dur(current.duration)}</div>
        </div>
      `;
    } else {
      nowPlaying.innerHTML = '';
    }

    const upcoming = queue.slice(idx + 1);
    if (upcoming.length === 0) {
      queueList.innerHTML = '<div class="queue-empty">Очередь пуста</div>';
      return;
    }

    queueList.innerHTML = upcoming.map((track, i) => {
      const art = Utils.art(track.artwork_url, 't120x120');
      const realIdx = idx + 1 + i;
      return `
        <div class="queue-item" onclick="Store.play(Store.get('queue')[${realIdx}], Store.get('queue'))">
          <div class="queue-item-art">
            ${art ? `<img src="${Utils.esc(art)}" alt="">` : '<div class="queue-item-no-art"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.2)" stroke-width="1.5"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg></div>'}
          </div>
          <div class="queue-item-info">
            <div class="queue-item-title">${Utils.esc(track.title)}</div>
            <div class="queue-item-artist">${Utils.esc(track.user?.username || '')}</div>
          </div>
          <div class="queue-item-dur">${Utils.dur(track.duration)}</div>
          <button class="queue-item-remove" onclick="event.stopPropagation(); Store.removeFromQueue(${realIdx}); App._renderQueue();">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>
          </button>
        </div>
      `;
    }).join('');
  },

  _setupKeys() {
    document.addEventListener('keydown', (e) => {
      // F11 fullscreen works even from input fields
      if (e.code === 'F11') {
        e.preventDefault();
        this._toggleFullscreen();
        return;
      }
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
      switch (e.code) {
        case 'Space': e.preventDefault(); Store.togglePlay(); break;
        case 'ArrowRight': if (e.ctrlKey || e.metaKey) { Store.next(); e.preventDefault(); } break;
        case 'ArrowLeft':  if (e.ctrlKey || e.metaKey) { Player.handlePrev(); e.preventDefault(); } break;
        case 'ArrowUp':    if (e.ctrlKey || e.metaKey) { Store.setVolume(Store.get('volume') + 5); e.preventDefault(); } break;
        case 'ArrowDown':  if (e.ctrlKey || e.metaKey) { Store.setVolume(Store.get('volume') - 5); e.preventDefault(); } break;
        case 'KeyM': if (e.ctrlKey || e.metaKey) { Store.setVolume(Store.get('volume') > 0 ? 0 : 50); e.preventDefault(); } break;
        case 'KeyQ': this.toggleQueue(); break;
      }
    });
  },

  _isFullscreen: false,
  _toggleFullscreen() {
    this._isFullscreen = !this._isFullscreen;
    const api = window.pywebview?.api;
    if (this._isFullscreen) {
      document.getElementById('titlebar').style.display = 'none';
      document.documentElement.classList.add('fullscreen-mode');
      document.body.classList.add('fullscreen-mode');
      if (api) api.toggle_fullscreen();
      // ★ Force layout recalc after pywebview changes window size
      setTimeout(() => {
        window.dispatchEvent(new Event('resize'));
      }, 100);
    } else {
      document.getElementById('titlebar').style.display = '';
      document.documentElement.classList.remove('fullscreen-mode');
      document.body.classList.remove('fullscreen-mode');
      if (api) api.toggle_fullscreen();
      setTimeout(() => {
        window.dispatchEvent(new Event('resize'));
      }, 100);
    }
    Utils.log('info', `[App] Fullscreen: ${this._isFullscreen}`);
  },
};

window.addEventListener('DOMContentLoaded', () => {
  App.init().catch(err => console.error('[App] Init error:', err));
});

// Save track position on window close
window.addEventListener('beforeunload', () => {
  const pos = Player.getCurrentTime();
  if (pos > 0) {
    Store.set({ lastTrackTime: pos });
    Store._persist();
  }
});

window.addEventListener('hashchange', () => {
  if (!Store.get('isAuthenticated')) return;
  const hash = window.location.hash.replace('#/', '') || 'home';
  if (hash !== Store.get('currentPage')) App.navigate(hash, false);
});
