

const API = {
  async request(path, options = {}) {
    const headers = { ...options.headers };
    const sessionId = Store.get('sessionId');
    if (sessionId) headers['x-session-id'] = sessionId;
    if (options.body && !headers['Content-Type']) {
      headers['Content-Type'] = 'application/json';
    }
    const resp = await fetch(`/api${path}`, { ...options, headers });
    if (!resp.ok) {
      if (resp.status === 401) Store.logout();
      if (resp.status === 429) {
        
        const retryAfter = parseInt(resp.headers.get('Retry-After') || resp.headers.get('X-RateLimit-Reset') || '60', 10);
        const text = await resp.text();
        const err = new RateLimitError(retryAfter, text);
        Utils.log('warning', `[API] 429 Rate Limited on ${path}, retry after ${retryAfter}s`);
        throw err;
      }
      const text = await resp.text();
      throw new APIError(resp.status, text);
    }
    const ct = resp.headers.get('content-type');
    if (ct?.includes('application/json')) return resp.json();
    return resp.text();
  },

  async get(path, params = {}) {
    const qs = new URLSearchParams(
      Object.fromEntries(Object.entries(params).filter(([, v]) => v != null))
    ).toString();
    return this.request(`${path}${qs ? '?' + qs : ''}`);
  },

  async post(path, body) {
    return this.request(path, { method: 'POST', body: body ? JSON.stringify(body) : undefined });
  },

  async put(path, body) {
    return this.request(path, { method: 'PUT', body: body ? JSON.stringify(body) : undefined });
  },

  async del(path) {
    return this.request(path, { method: 'DELETE' });
  },

  
  async initiateLogin() { return this.get('/auth/login'); },
  async fetchUser()     { return this.get('/me'); },

  
  async searchTracks(query, limit = 30, offset = 0) {
    return this._smartSearch(query, 'tracks', limit, offset);
  },
  async searchUsers(query, limit = 20, offset = 0) {
    return this._smartSearch(query, 'users', limit, offset);
  },
  async searchPlaylists(query, limit = 20, offset = 0) {
    return this._smartSearch(query, 'playlists', limit, offset);
  },

  async _smartSearch(query, type, limit, offset) {
    const sessionId = Store.get('sessionId');
    const headers = sessionId ? { 'x-session-id': sessionId } : {};
    const params = new URLSearchParams({ q: query, type, limit, offset });
    const resp = await fetch(`/api/search_smart?${params}`, { headers });
    if (!resp.ok) return { collection: [] };
    return resp.json();
  },

  
  async getTrack(urn)              { return this.get(`/tracks/${encodeURIComponent(urn)}`); },
  async getTrackComments(urn, limit = 200) {
    return this.get(`/tracks/${encodeURIComponent(urn)}/comments`, { limit });
  },
  async getRelatedTracks(urn, limit = 20) {
    return this.get(`/tracks/${encodeURIComponent(urn)}/related`, { limit });
  },
  async getRecommended(urn, limit = 20) {
    return this.get(`/tracks/${encodeURIComponent(urn)}/related`, { limit });
  },

  streamUrl(urn, format = 'http_mp3_128') {
    const sessionId = Store.get('sessionId');
    return `/stream/tracks/${encodeURIComponent(urn)}/stream?format=${format}${sessionId ? `&session_id=${sessionId}` : ''}`;
  },

  
  async getLikedTracks(limit = 50, offset = 0) {
    return this.get('/me/likes/tracks', { limit, offset, linked_partitioning: 1 });
  },
  async getMyPlaylists(limit = 50, offset = 0)   { return this.get('/me/playlists',  { limit, offset }); },
  async getMyFollowings(limit = 50, offset = 0)  { return this.get('/me/followings', { limit, offset }); },
  async getFeed(limit = 20, offset = 0)           { return this.get('/me/activities/tracks', { limit, offset }); },

  
  async likeTrack(urn)   { return this.post(`/likes/tracks/${encodeURIComponent(urn)}`); },
  async unlikeTrack(urn) { return this.del(`/likes/tracks/${encodeURIComponent(urn)}`); },

  
  async getUser(urn)           { return this.get(`/users/${encodeURIComponent(urn)}`); },
  async getUserTracks(urn, limit = 30) {
    return this.get(`/users/${encodeURIComponent(urn)}/tracks`, { limit });
  },

  
  async getPlaylist(urn) { return this.get(`/playlists/${encodeURIComponent(urn)}`); },

  async resolve(url) { return this.get('/resolve', { url }); },

  
  async getMixedSelections() { return this.get('/mixed-selections', { limit: 10 }); },

  
  async getSystemPlaylist(id) { return this.get(`/system-playlists/${encodeURIComponent(id)}`); },
};

class APIError extends Error {
  constructor(status, body) {
    super(`API ${status}: ${body}`);
    this.status = status; this.body = body;
  }
}

class RateLimitError extends Error {
  constructor(retryAfter, body) {
    super(`Rate limited, retry after ${retryAfter}s`);
    this.status = 429;
    this.retryAfter = retryAfter || 60;
    this.body = body;
  }
}


const LikeQueue = {
  _queue: [],        
  _processing: false,
  _rateLimitUntil: 0,
  _minDelay: 350,    

  
  enqueue(urn, action) {
    return new Promise((resolve, reject) => {
      
      const existing = this._queue.findIndex(q => q.urn === urn);
      if (existing !== -1) {
        
        this._queue[existing] = { urn, action, resolve, reject };
        Utils.log('info', `[LikeQueue] Replaced pending ${action} for ${urn}`);
      } else {
        this._queue.push({ urn, action, resolve, reject });
      }
      this._process();
    });
  },

  
  isPendingLike(urn) { return false; },
  addPendingLike(track) {},
  removePendingLike(urn) {},
  async retryPendingLikes() {},

  async _process() {
    if (this._processing) return;
    this._processing = true;

    while (this._queue.length > 0) {
      
      const now = Date.now();
      if (now < this._rateLimitUntil) {
        const item = this._queue.shift();
        if (item) {
          this._showRateLimitToast(0);
          item.reject(new RateLimitError(Math.ceil((this._rateLimitUntil - now) / 1000)));
        }
        continue;
      }

      const item = this._queue.shift();
      if (!item) break;

      try {
        if (item.action === 'like') {
          await API.likeTrack(item.urn);
        } else {
          await API.unlikeTrack(item.urn);
        }
        Utils.log('info', `[LikeQueue] ✓ ${item.action} ${item.urn}`);
        if (item.action === 'like') this.removePendingLike(item.urn);
        
        if (item.action === 'like' && typeof LocalLikes !== 'undefined') {
          LocalLikes.removeTrack(item.urn);
        }
        item.resolve();
      } catch (err) {
        if (err instanceof RateLimitError) {
          this._rateLimitUntil = Date.now() + (err.retryAfter * 1000);
          Utils.log('warning', `[LikeQueue] 429 — rate limited, rejecting, ${this._queue.length} items remaining`);
          
          const trackObj = (typeof TrackRegistry !== 'undefined') ? TrackRegistry.get(item.urn) : null;
          this._showRateLimitToast(err.retryAfter, trackObj);
          item.reject(err);
          continue;
        } else {
          
          Utils.log('error', `[LikeQueue] Error ${item.action} ${item.urn}: ${err.message}`);
          item.reject(err);
        }
      }

      
      if (this._queue.length > 0) {
        await new Promise(r => setTimeout(r, this._minDelay));
      }
    }

    this._processing = false;
  },

  _toastTimer: null,
  _lastToastTime: 0,
  _importRateLimited: false,  

  
  setImportRateLimit() { this._importRateLimited = true; },

  _rateLimitToastShown: false,  

  _showRateLimitToast(seconds, track) {
    if (track && typeof LocalLikes !== 'undefined') {
      
      if (LocalLikes.hasTrack(track.urn)) {
        
        Utils.toast('Лайк всё ещё недоступен! Ограничение SoundCloud.', 4000, 'local-like-fail');
      } else {
        
        LocalLikes.addTrack(track);
        Utils.toast('Лайк не удалось! Но мы добавили его в «Локально Нравится»!', 5000);
      }
    }
    
    if (!this._rateLimitToastShown) {
      this._rateLimitToastShown = true;
      Utils.toast('ЭТО ОГРАНИЧЕНИЕ САМОГО SOUNDCLOUD! Слишком много лайков за короткое время.', 8000, 'ratelimit-like-once');
    }
    Utils.log('warning', '[LikeQueue] Rate limit — track handled');
  },
};
