

const CollectionPage = {
  _mode: 'liked',
  _viewMode: 'cards',
  _tracks: [],
  _allTracks: [],
  _filterQuery: '',
  _sortMode: 'default',
  _loading: false,
  _batchSize: 40,
  _rendered: 0,
  _apiLimit: 50,     
  _apiOffset: 0,
  _hasMore: true,    
  _maxCardsCount: 200,

  render(mode) {
    this._mode = mode || this._mode;
    this._filterQuery = '';
    this._sortMode = 'default';
    this._rendered = 0;
    this._apiOffset = 0;
    this._hasMore = true;
    this._allTracks = [];

    const settings = Store.get('settings') || {};
    this._viewMode = settings['viewMode_' + this._mode] || 'cards';

    const container = document.getElementById('page-container');
    const isLiked = this._mode === 'liked';

    container.innerHTML = `
      <div class="page">
        <div class="page-sections">
          <section class="animate-in">
            <div class="collection-header">
              <div class="collection-header-left">
                <div class="collection-icon">
                  ${isLiked
                    ? '<svg width="22" height="22" viewBox="0 0 24 24" fill="var(--accent)" stroke="var(--accent)" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>'
                    : '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.5)" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>'}
                </div>
                <h1 class="collection-title">${isLiked ? 'Любимые треки' : 'Недавно прослушанные'}</h1>
                <span class="collection-count" id="collection-count">...</span>
              </div>
              <div class="collection-actions">
                ${!isLiked ? '<button class="collection-clear-btn" onclick="CollectionPage._clearHistory()">Очистить</button>' : ''}
              </div>
            </div>

            <div class="collection-toolbar animate-in" style="animation-delay:80ms">
              <div class="collection-filters">
                <div class="collection-search-wrap">
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                  <input type="text" class="collection-search" id="collection-search" placeholder="Поиск..." autocomplete="off">
                </div>
                <div class="collection-sort-btns">
                  <button class="collection-sort-btn active" data-sort="default" onclick="CollectionPage._setSort('default')">По умолчанию</button>
                  <button class="collection-sort-btn" data-sort="plays" onclick="CollectionPage._setSort('plays')"><svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 18v-6a9 9 0 0 1 18 0v6"/><path d="M21 19a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3zM3 19a2 2 0 0 0 2 2h1a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2H3z"/></svg> Популярные</button>
                  <button class="collection-sort-btn" data-sort="likes" onclick="CollectionPage._setSort('likes')"><svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg> Залайканные</button>
                </div>
              </div>
              <div class="collection-view-toggle">
                <button class="view-toggle-btn ${this._viewMode === 'cards' ? 'active' : ''}" data-view="cards" onclick="CollectionPage._setView('cards')" title="Карточки">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
                </button>
                <button class="view-toggle-btn ${this._viewMode === 'list' ? 'active' : ''}" data-view="list" onclick="CollectionPage._setView('list')" title="Список">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>
                </button>
              </div>
            </div>

            <div id="collection-content" class="animate-in" style="animation-delay:140ms">
              <div class="flex-center" style="padding:60px 0"><div class="spinner-inline"></div></div>
            </div>
          </section>
        </div>
      </div>
    `;

    const searchInput = document.getElementById('collection-search');
    if (searchInput) {
      searchInput.addEventListener('input', Utils.debounce((e) => {
        this._filterQuery = e.target.value.toLowerCase().trim();
        this._renderTracks();
      }, 250));
    }

    const content = document.getElementById('content');
    if (content) {
      content._collectionScroll = Utils.throttle(() => {
        if (content.scrollTop + content.clientHeight >= content.scrollHeight - 500) {
          this._loadMoreBatch();
        }
      }, 150);
      content.addEventListener('scroll', content._collectionScroll);
    }

    this._loadTracks();
  },

  async _loadTracks() {
    this._loading = true;
    try {
      if (this._mode === 'liked') {
        
        const data = await API.getLikedTracks(this._apiLimit, 0);
        this._allTracks = data.collection || [];
        this._apiOffset = this._allTracks.length;
        this._hasMore = this._allTracks.length >= this._apiLimit;

        
        if (typeof LocalLikes !== 'undefined') {
          const localTracks = LocalLikes.getTracks();
          if (localTracks.length > 0) {
            const likedUrns = new Set(this._allTracks.map(t => t.urn));
            const extra = localTracks.filter(t => t.urn && !likedUrns.has(t.urn))
              .map(t => ({ ...t, _isLocalLike: true }));
            this._allTracks = [...extra, ...this._allTracks];
          }
        }
      } else {
        const all = Store.get('recentlyPlayed') || [];
        this._allTracks = all.slice(0, this._apiLimit);
        this._apiOffset = this._allTracks.length;
        this._hasMore = all.length > this._apiLimit;
      }
      this._allTracks.forEach(t => TrackRegistry.reg(t));
      TrackCardComponent.setQueue(this._allTracks, 'collection');

      this._updateCount();
      this._checkCardLimit();
      this._renderTracks();
      Utils.log('info', '[Collection] Loaded ' + this._allTracks.length + ' tracks (' + this._mode + ')');
    } catch (e) {
      const contentEl = document.getElementById('collection-content');
      if (contentEl) contentEl.innerHTML = '<div class="empty-state"><p>Ошибка загрузки</p></div>';
    }
    this._loading = false;
  },

  
  async _loadMoreFromAPI() {
    if (this._loading || !this._hasMore) return;
    this._loading = true;
    const btn = document.getElementById('collection-load-more');
    if (btn) { btn.textContent = 'Загрузка...'; btn.disabled = true; }

    try {
      if (this._mode === 'liked') {
        const data = await API.getLikedTracks(this._apiLimit, this._apiOffset);
        const newTracks = data.collection || [];
        this._allTracks.push(...newTracks);
        this._apiOffset += newTracks.length;
        this._hasMore = newTracks.length >= this._apiLimit;
      } else {
        const all = Store.get('recentlyPlayed') || [];
        const newTracks = all.slice(this._apiOffset, this._apiOffset + this._apiLimit);
        this._allTracks.push(...newTracks);
        this._apiOffset += newTracks.length;
        this._hasMore = this._apiOffset < all.length;
      }
      this._allTracks.forEach(t => TrackRegistry.reg(t));
      TrackCardComponent.setQueue(this._allTracks, 'collection');
      this._updateCount();
      this._checkCardLimit();
      this._renderTracks();
      Utils.log('info', '[Collection] Loaded more: ' + this._allTracks.length + ' total');
    } catch (e) {
      Utils.toast('Ошибка загрузки');
    }
    this._loading = false;
  },

  _updateCount() {
    const countEl = document.getElementById('collection-count');
    if (countEl) countEl.textContent = this._allTracks.length + (this._hasMore ? '+' : '') + ' треков';
  },

  
  _checkCardLimit() {
    if (this._allTracks.length > this._maxCardsCount && this._viewMode === 'cards') {
      this._viewMode = 'list';
      const settings = Store.get('settings') || {};
      settings['viewMode_' + this._mode] = 'list';
      Store.set({ settings });
      document.querySelectorAll('.view-toggle-btn').forEach(btn => {
        btn.classList.toggle('active', btn.dataset.view === 'list');
      });
      InAppModal.confirm({
        title: 'Слишком много треков!', hideCancel: true,
        message: 'Могут быть проблемы с оптимизацией, и в связи с этим вам доступен только компактный режим.',
        confirmText: 'ОК',
        danger: false,
        onConfirm: () => {},
      });
    }
  },

  _getSorted() {
    let tracks = [...this._allTracks];
    if (this._filterQuery) {
      const q = this._filterQuery;
      tracks = tracks.filter(t =>
        (t.title || '').toLowerCase().includes(q) ||
        (t.user?.username || '').toLowerCase().includes(q)
      );
    }
    if (this._sortMode === 'plays') tracks.sort((a, b) => (b.playback_count || 0) - (a.playback_count || 0));
    else if (this._sortMode === 'likes') tracks.sort((a, b) => (b.favoritings_count ?? b.likes_count ?? 0) - (a.favoritings_count ?? a.likes_count ?? 0));
    return tracks;
  },

  _renderTracks() {
    const contentEl = document.getElementById('collection-content');
    if (!contentEl) return;

    const tracks = this._getSorted();
    this._rendered = tracks.length;
    this._tracks = tracks;
    TrackCardComponent.setQueue(tracks, 'collection');

    if (tracks.length === 0) {
      contentEl.innerHTML = '<div class="empty-state" style="padding:60px 0"><p>Ничего не найдено</p></div>';
      return;
    }

    let html;
    if (this._viewMode === 'list') {
      html = '<div class="collection-list">' + tracks.map((t, i) => this._listRow(t, i, tracks)).join('') + '</div>';
    } else {
      html = '<div class="collection-grid">' + tracks.map(t => '<div class="collection-grid-item">' + TrackCardComponent.card(t, tracks) + '</div>').join('') + '</div>';
    }

    if (this._hasMore) {
      html += '<div style="display:flex;justify-content:center;padding:24px 0"><button class="search-load-more" id="collection-load-more" onclick="CollectionPage._loadMoreFromAPI()">Загрузить ещё</button></div>';
    }

    contentEl.innerHTML = html;
  },

  _loadMoreBatch() {
    if (this._loading) return;
    const contentEl = document.getElementById('collection-content');
    if (!contentEl) return;

    const tracks = this._tracks;
    if (this._rendered >= tracks.length) return;

    const nextBatch = tracks.slice(this._rendered, this._rendered + this._batchSize);
    this._rendered += nextBatch.length;

    const container = this._viewMode === 'list'
      ? contentEl.querySelector('.collection-list')
      : contentEl.querySelector('.collection-grid');
    if (!container) return;

    const fragment = document.createDocumentFragment();
    nextBatch.forEach((t, i) => {
      const div = document.createElement('div');
      if (this._viewMode === 'list') {
        div.innerHTML = this._listRow(t, this._rendered - nextBatch.length + i, tracks);
        fragment.appendChild(div.firstElementChild);
      } else {
        div.className = 'collection-grid-item';
        div.innerHTML = TrackCardComponent.card(t, tracks);
        fragment.appendChild(div);
      }
    });
    container.appendChild(fragment);
  },

  _listRow(track, index, queue) {
    TrackRegistry.reg(track);
    const art = Utils.art(track.artwork_url, 't200x200');
    const current = Store.get('currentTrack');
    const isThis = current?.urn === track.urn;
    const isPlaying = isThis && Store.get('isPlaying');
    const isLiked = NowPlayingComponent._likedTracks.has(track.urn);
    const urn = Utils.esc(track.urn);
    const isLocalLike = track._isLocalLike || (typeof LocalLikes !== 'undefined' && LocalLikes.hasTrack(track.urn));
    const llIcon = isLocalLike ? '<div class="ll-row-icon" title="Локально на устройстве" onclick="event.stopPropagation(); PlaylistsPage.openPlaylist(LocalLikes.getPlaylist().id)"><svg viewBox="0 0 32 32" fill="var(--accent)"><path d="M0 16q0 2.912 1.824 5.088t4.576 2.752q0.032 0 0.032-0.032v-0.064t0.032-0.032q0.544-1.344 1.344-2.176t2.208-1.184v-2.336q0-2.496 1.728-4.256t4.256-1.76 4.256 1.76 1.76 4.256v2.336q1.376 0.384 2.176 1.216t1.344 2.144l0.096 0.288h0.384q2.464 0 4.224-1.76t1.76-4.224v-2.016q0-2.464-1.76-4.224t-4.224-1.76q-0.096 0-0.32 0.032 0.32-1.152 0.32-2.048 0-3.296-2.368-5.632t-5.632-2.368q-2.88 0-5.056 1.824t-2.784 4.544q-1.152-0.352-2.176-0.352-3.296 0-5.664 2.336t-2.336 5.664v1.984zM10.016 25.824q-0.096 0.928 0.576 1.6l4 4q0.576 0.576 1.408 0.576t1.408-0.576l4-4q0.672-0.672 0.608-1.6-0.064-0.32-0.16-0.576-0.224-0.576-0.736-0.896t-1.12-0.352h-1.984v-5.984q0-0.832-0.608-1.408t-1.408-0.608-1.408 0.608-0.576 1.408v5.984h-2.016q-0.608 0-1.12 0.352t-0.736 0.896q-0.096 0.288-0.128 0.576z"/></svg></div>' : '';
    return `
      <div class="search-track-row ${isThis ? 'active' : ''}" data-urn="${urn}"
           onclick="TrackCardComponent.play('${urn}')"
           oncontextmenu="ContextMenu.showByUrn(event,'${urn}')">
        <div class="search-row-index-wrap">
          <div class="search-row-index">${index + 1}</div>
          <div class="search-row-play">
            ${isPlaying
              ? '<svg width="16" height="16" viewBox="0 0 24 24" fill="white"><path d="M6 4h4v16H6zM14 4h4v16h-4z"/></svg>'
              : '<svg width="16" height="16" viewBox="0 0 24 24" fill="white"><path d="M8 5v14l11-7z"/></svg>'}
          </div>
        </div>
        <div class="search-row-art" style="position:relative">
          ${art ? '<img src="' + Utils.esc(art) + '" alt="" loading="lazy">' : '<div style="width:100%;height:100%;background:rgba(255,255,255,0.04)"></div>'}
          ${isLocalLike ? '<div class="ll-row-art-dot"></div>' : ''}
        </div>
        <div class="search-row-info">
          <div class="search-row-title">${llIcon}${Utils.esc(track.title)}</div>
          <div class="search-row-artist" onclick="event.stopPropagation(); ArtistPage.openFromUrn('${Utils.esc(track.user?.urn || '')}','${Utils.esc(track.user?.username || '')}')">${Utils.esc(track.user?.username || '')}</div>
        </div>
        <div class="search-row-right">
          ${track.playback_count != null && track.playback_count > 0 ? `<span class="search-row-plays"><svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 18v-6a9 9 0 0 1 18 0v6"/><path d="M21 19a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3zM3 19a2 2 0 0 0 2 2h1a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2H3z"/></svg> ${Utils.fc(track.playback_count)}</span>` : ''}
          ${(track.favoritings_count ?? track.likes_count) > 0 ? `<span class="search-row-plays"><svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg> ${Utils.fc(track.favoritings_count ?? track.likes_count)}</span>` : ''}
          <button class="search-like-btn ${isLiked ? 'active' : ''}"
                  onclick="event.stopPropagation(); SearchPage._toggleLike(this, '${urn}')" title="${isLiked ? 'Убрать' : 'Лайк'}">
            <svg width="15" height="15" viewBox="0 0 24 24"
                 fill="${isLiked ? 'var(--accent)' : 'none'}"
                 stroke="${isLiked ? 'var(--accent)' : 'currentColor'}" stroke-width="2">
              <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
            </svg>
          </button>
          <span class="search-row-dur">${Utils.dur(track.duration)}</span>
        </div>
      </div>`;
  },

  _setSort(mode) {
    this._sortMode = mode;
    document.querySelectorAll('.collection-sort-btn').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.sort === mode);
    });
    this._renderTracks();
  },

  _setView(mode) {
    
    if (mode === 'cards' && this._allTracks.length > this._maxCardsCount) {
      InAppModal.confirm({
        title: 'Слишком много треков!', hideCancel: true,
        message: 'Могут быть проблемы с оптимизацией, и в связи с этим вам доступен только компактный режим.',
        confirmText: 'ОК',
        danger: false,
        onConfirm: () => {},
      });
      return;
    }
    if (mode === this._viewMode) return;
    this._viewMode = mode;
    const settings = Store.get('settings') || {};
    settings['viewMode_' + this._mode] = mode;
    Store.set({ settings });
    document.querySelectorAll('.view-toggle-btn').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.view === mode);
    });
    const contentEl = document.getElementById('collection-content');
    if (contentEl) {
      contentEl.style.opacity = '0';
      contentEl.style.transform = 'translateY(6px)';
      contentEl.style.transition = 'opacity 0.2s ease, transform 0.2s ease';
      setTimeout(() => {
        this._renderTracks();
        requestAnimationFrame(() => { contentEl.style.opacity = '1'; contentEl.style.transform = 'translateY(0)'; });
      }, 180);
    }
  },

  _clearHistory() {
    InAppModal.confirm({
      title: 'Очистить историю',
      message: 'Вы уверены? Все недавно прослушанные треки будут удалены.',
      confirmText: 'Очистить',
      danger: true,
      onConfirm: () => {
        Store.set({ recentlyPlayed: [] });
        this._allTracks = [];
        this._renderTracks();
        Utils.toast('История очищена');
      },
    });
  },
};
