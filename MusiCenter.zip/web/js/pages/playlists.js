

const PlaylistsPage = {
  
  _currentPl: null,
  _viewMode: 'list',    
  _shownCount: 50,

  render() {
    
    const pendingId = this._pendingOpenId;
    this._pendingOpenId = null;

    if (pendingId) {
      const pl = (Store.get('playlists') || []).find(p => p.id === pendingId);
      if (pl) {
        
        const container = document.getElementById('page-container');
        container.innerHTML = '<div class="page"><div class="page-sections"></div></div>';
        
        this.openPlaylist(pendingId);
        Store.on('playlists', () => { if (this._currentPl) this._renderGrid(); });
        return;
      }
    }

    const container = document.getElementById('page-container');
    container.innerHTML = `
      <div class="page">
        <div class="page-sections">
          <section class="animate-in">
            <div class="section-header">
              <div class="section-header-left">
                <div class="section-icon">
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.5)" stroke-width="2">
                    <line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/>
                    <line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/>
                    <line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/>
                  </svg>
                </div>
                <h2 class="section-title">Мои плейлисты</h2>
              </div>
            </div>
            <div id="playlists-grid" class="playlists-grid"></div>
          </section>
        </div>
      </div>
    `;
    this._renderGrid();
    Store.on('playlists', () => this._renderGrid());
  },

  _renderGrid() {
    const grid = document.getElementById('playlists-grid');
    if (!grid) return;
    const playlists = Store.get('playlists') || [];
    grid.innerHTML = `
      <div class="create-playlist-card" onclick="PlaylistsPage._showCreate()">
        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
          <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
        </svg>
        <span>Создать плейлист</span>
      </div>
      ${playlists.map((pl, i) => this._playlistCard(pl, i)).join('')}
    `;
  },

  _playlistCard(pl, index) {
    const tracks = pl.tracks || [];
    const isYm = pl.isYandex === true || pl.title === 'Яндекс Музыка';
    const isLocalLikes = pl.isLocalLikes === true;

    
    let artHtml;
    if (isLocalLikes) {
      artHtml = '<div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,#1a0a1e,#0d050f);grid-column:1/-1;border-radius:inherit"><svg width="44" height="44" viewBox="0 0 32 32" fill="var(--accent)"><path d="M0 16q0 2.912 1.824 5.088t4.576 2.752q0.032 0 0.032-0.032v-0.064t0.032-0.032q0.544-1.344 1.344-2.176t2.208-1.184v-2.336q0-2.496 1.728-4.256t4.256-1.76 4.256 1.76 1.76 4.256v2.336q1.376 0.384 2.176 1.216t1.344 2.144l0.096 0.288h0.384q2.464 0 4.224-1.76t1.76-4.224v-2.016q0-2.464-1.76-4.224t-4.224-1.76q-0.096 0-0.32 0.032 0.32-1.152 0.32-2.048 0-3.296-2.368-5.632t-5.632-2.368q-2.88 0-5.056 1.824t-2.784 4.544q-1.152-0.352-2.176-0.352-3.296 0-5.664 2.336t-2.336 5.664v1.984zM10.016 25.824q-0.096 0.928 0.576 1.6l4 4q0.576 0.576 1.408 0.576t1.408-0.576l4-4q0.672-0.672 0.608-1.6-0.064-0.32-0.16-0.576-0.224-0.576-0.736-0.896t-1.12-0.352h-1.984v-5.984q0-0.832-0.608-1.408t-1.408-0.608-1.408 0.608-0.576 1.408v5.984h-2.016q-0.608 0-1.12 0.352t-0.736 0.896q-0.096 0.288-0.128 0.576z"/></svg></div>';
    } else if (isYm) {
      artHtml = `<div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,#1a1610,#0d0a05);grid-column:1/-1;border-radius:inherit">
        <svg width="44" height="44" viewBox="0 0 1000 999.9941406" fill="none">
          <path fill="#FED42B" d="M990.5,381.2l-3.9-19.4l-164.9-28.8l95.8-129.6l-11.1-12.2l-141,67.6l17.8-179.5l-14.5-8.3L683,216.1L586.6,0h-16.7l22.8,208.9L350.4,15l-20.6,6.1l186.6,234.3L147.1,132.4l-16.7,18.8l329.8,187.8L5,376.7L0,405l473,51.5L78.5,782.8l16.7,22.7l469.6-255.4l-93,449.9h28.4l179.9-423.3l109.7,331.3l19.5-15l-45.1-336.8l171,193.9l11.1-17.7L815.6,492l182.7,67.6L1000,539.1l-163.8-120.8l154.3-37.1L990.5,381.2z"/>
        </svg>
      </div>`;
    } else if (pl.coverUrl) {
      artHtml = `<img src="${Utils.esc(pl.coverUrl)}" alt="" loading="lazy" style="width:100%;height:100%;object-fit:cover;grid-column:1/-1">`;
    } else {
      const artUrls = tracks.slice(0, 4).map(t => Utils.art(t.artwork_url, 't120x120')).filter(Boolean);
      artHtml = artUrls.length > 0
        ? artUrls.map(u => `<img src="${Utils.esc(u)}" alt="" loading="lazy">`).join('')
        : `<div style="grid-column:1/-1;display:flex;align-items:center;justify-content:center;width:100%;height:100%">
             <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.15)" stroke-width="1.5"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/></svg>
           </div>`;
    }
    return `
      <div class="playlist-item-card" data-pl-id="${Utils.esc(pl.id)}" data-pl-index="${index}"
           onclick="PlaylistsPage.openPlaylist('${Utils.esc(pl.id)}')"
           oncontextmenu="PlaylistsPage._playlistContextMenu(event, '${Utils.esc(pl.id)}', '${Utils.esc(pl.title)}')"
           draggable="true"
           ondragstart="PlaylistsPage._dragStart(event, ${index})"
           ondragend="PlaylistsPage._dragEnd(event)"
           ondragover="PlaylistsPage._dragOver(event)"
           ondrop="PlaylistsPage._dragDrop(event, ${index})">
        <div class="playlist-item-art">${artHtml}</div>
        <div class="playlist-item-info">
          <div class="playlist-item-title">${Utils.esc(pl.title)}</div>
          <div class="playlist-item-count">${tracks.length} ${this._tw(tracks.length)}</div>
        </div>
        <button class="playlist-item-play" onclick="event.stopPropagation(); PlaylistsPage.playPlaylist('${Utils.esc(pl.id)}')">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>
        </button>
      </div>
    `;
  },

  _tw(n) {
    if (n === 1) return 'трек';
    if (n >= 2 && n <= 4) return 'трека';
    return 'треков';
  },

  openPlaylist(id) {
    const pl = (Store.get('playlists') || []).find(p => p.id === id);
    if (!pl) return;

    this._currentPl = pl;
    const tracks = pl.tracks || [];
    
    const isYm = pl.isYandex === true || pl.title === 'Яндекс Музыка';
    const isLocalLikes = pl.isLocalLikes === true;
    
    const settings = Store.get('settings') || {};
    this._viewMode = settings['plViewMode_' + id] || 'cards';
    
    this._shownCount = 50;
    this._filterQuery = '';
    this._sortMode = 'default';

    TrackCardComponent.setQueue(tracks, 'playlist');

    
    if (isYm) {
      const missingStats = tracks.filter(t => !t.playback_count && !t.favoritings_count && t.urn);
      if (missingStats.length > 0) {
        Utils.log('info', `[Playlists] Enriching ${missingStats.length} YM tracks with fresh stats`);
        this._enrichTracksStats(pl.id, missingStats.slice(0, 50)); 
      }
    }

    
    let artHtml;
    if (isLocalLikes) {
      artHtml = `<div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,#1a0a1e,#0d050f);grid-column:1/-1;border-radius:inherit">
        <svg width="68" height="68" viewBox="0 0 32 32" fill="var(--accent)"><path d="M0 16q0 2.912 1.824 5.088t4.576 2.752q0.032 0 0.032-0.032v-0.064t0.032-0.032q0.544-1.344 1.344-2.176t2.208-1.184v-2.336q0-2.496 1.728-4.256t4.256-1.76 4.256 1.76 1.76 4.256v2.336q1.376 0.384 2.176 1.216t1.344 2.144l0.096 0.288h0.384q2.464 0 4.224-1.76t1.76-4.224v-2.016q0-2.464-1.76-4.224t-4.224-1.76q-0.096 0-0.32 0.032 0.32-1.152 0.32-2.048 0-3.296-2.368-5.632t-5.632-2.368q-2.88 0-5.056 1.824t-2.784 4.544q-1.152-0.352-2.176-0.352-3.296 0-5.664 2.336t-2.336 5.664v1.984zM10.016 25.824q-0.096 0.928 0.576 1.6l4 4q0.576 0.576 1.408 0.576t1.408-0.576l4-4q0.672-0.672 0.608-1.6-0.064-0.32-0.16-0.576-0.224-0.576-0.736-0.896t-1.12-0.352h-1.984v-5.984q0-0.832-0.608-1.408t-1.408-0.608-1.408 0.608-0.576 1.408v5.984h-2.016q-0.608 0-1.12 0.352t-0.736 0.896q-0.096 0.288-0.128 0.576z"/></svg>
      </div>`;
    } else if (isYm) {
      
      artHtml = `<div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,#1a1610,#0d0a05);grid-column:1/-1;border-radius:inherit">
        <svg width="68" height="68" viewBox="0 0 1000 999.9941406" fill="none">
          <path fill="#FED42B" d="M990.5,381.2l-3.9-19.4l-164.9-28.8l95.8-129.6l-11.1-12.2l-141,67.6l17.8-179.5l-14.5-8.3L683,216.1L586.6,0h-16.7l22.8,208.9L350.4,15l-20.6,6.1l186.6,234.3L147.1,132.4l-16.7,18.8l329.8,187.8L5,376.7L0,405l473,51.5L78.5,782.8l16.7,22.7l469.6-255.4l-93,449.9h28.4l179.9-423.3l109.7,331.3l19.5-15l-45.1-336.8l171,193.9l11.1-17.7L815.6,492l182.7,67.6L1000,539.1l-163.8-120.8l154.3-37.1L990.5,381.2z"/>
        </svg>
      </div>`;
    } else if (pl.coverUrl) {
      artHtml = `<img src="${Utils.esc(pl.coverUrl)}" alt="" style="width:100%;height:100%;object-fit:cover;grid-column:1/-1">`;
    } else {
      const artUrls = tracks.slice(0, 4).map(t => Utils.art(t.artwork_url, 't120x120')).filter(Boolean);
      artHtml = artUrls.length > 0
        ? artUrls.map(u => `<img src="${Utils.esc(u)}" alt="">`).join('')
        : `<div style="display:flex;align-items:center;justify-content:center;width:100%;height:100%;grid-column:1/-1"><svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.1)" stroke-width="1.5"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/></svg></div>`;
    }

    
    const coverClickAttr = (isYm || isLocalLikes) ? '' : `onclick="PlaylistsPage._changeCover('${Utils.esc(pl.id)}')" title="Изменить обложку" style="cursor:pointer;position:relative"`;
    const coverHoverHtml = (isYm || isLocalLikes) ? '' : `<div class="playlist-cover-hover"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg><span>Обложка</span></div>`;

    
    let actionsHtml;
    if (isLocalLikes) {
      
      actionsHtml = tracks.length > 0
        ? `<button class="playlist-detail-play-btn" onclick="PlaylistsPage.playPlaylist('${Utils.esc(pl.id)}')"><svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg> Слушать</button>
           <button class="ll-try-all-btn" id="ll-try-all-btn" onclick="LocalLikes.bulkTryLike()">
             <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
             Попробовать лайкнуть все
           </button>`
        : '';
    } else if (isYm) {
      actionsHtml = `<button class="playlist-delete-btn" onclick="PlaylistsPage._confirmDelete('${Utils.esc(pl.id)}')">Удалить</button>`;
    } else {
      actionsHtml = `${tracks.length > 0 ? `<button class="playlist-detail-play-btn" onclick="PlaylistsPage.playPlaylist('${Utils.esc(pl.id)}')"><svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg> Слушать</button>` : ''}
         <button class="playlist-edit-btn" onclick="PlaylistsPage._showRename('${Utils.esc(pl.id)}','${Utils.esc(pl.title)}')">Переименовать</button>
         <button class="playlist-delete-btn" onclick="PlaylistsPage._confirmDelete('${Utils.esc(pl.id)}')">Удалить</button>`;
    }

    
    const cardsActive = this._viewMode === 'cards' ? ' active' : '';
    const listActive = this._viewMode === 'list' ? ' active' : '';
    const viewToggleHtml = `
      <div class="collection-view-toggle" style="margin-top:10px;width:fit-content">
        <button class="view-toggle-btn${cardsActive}" data-view="cards" onclick="PlaylistsPage._setView('cards')" title="Карточки">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
        </button>
        <button class="view-toggle-btn${listActive}" data-view="list" onclick="PlaylistsPage._setView('list')" title="Список">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>
        </button>
      </div>`;

    
    const toolbarHtml = tracks.length > 5 ? `
      <div class="collection-toolbar animate-in" style="animation-delay:80ms;margin-top:12px">
        <div class="collection-filters">
          <div class="collection-search-wrap">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
            <input type="text" class="collection-search" id="pl-search" placeholder="Поиск..." autocomplete="off">
          </div>
          <div class="collection-sort-btns">
            <button class="collection-sort-btn active" data-sort="default" onclick="PlaylistsPage._setSort('default')">По умолчанию</button>
            <button class="collection-sort-btn" data-sort="plays" onclick="PlaylistsPage._setSort('plays')"><svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 18v-6a9 9 0 0 1 18 0v6"/><path d="M21 19a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3zM3 19a2 2 0 0 0 2 2h1a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2H3z"/></svg> Популярные</button>
            <button class="collection-sort-btn" data-sort="likes" onclick="PlaylistsPage._setSort('likes')"><svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg> Залайканные</button>
          </div>
        </div>
      </div>` : '';

    document.getElementById('page-container').innerHTML = `
      <div class="page">
        <div class="page-sections">
          <section class="animate-in">
            <button onclick="PlaylistsPage.render()" style="background:none;border:none;color:rgba(255,255,255,0.4);cursor:pointer;display:flex;align-items:center;gap:6px;font-size:12px;margin-bottom:16px;padding:4px 0">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"/></svg>
              Все плейлисты
            </button>
            <div class="playlist-detail-header">
              <div class="playlist-detail-art" ${coverClickAttr}>
                ${artHtml}
                ${coverHoverHtml}
              </div>
              <div>
                <div class="playlist-detail-title">${Utils.esc(pl.title)}</div>
                <div class="playlist-detail-meta">${tracks.length} ${this._tw(tracks.length)}</div>
                <div class="playlist-detail-actions">${actionsHtml}</div>
                ${viewToggleHtml}
              </div>
            </div>
            ${toolbarHtml}
            <div id="playlist-tracks-container">
              ${this._renderTracksHtml(pl, this._getPlaylistSorted(tracks))}
            </div>
          </section>
        </div>
      </div>
    `;

    
    const searchInput = document.getElementById('pl-search');
    if (searchInput) {
      searchInput.addEventListener('input', Utils.debounce((e) => {
        this._filterQuery = e.target.value.toLowerCase().trim();
        const container = document.getElementById('playlist-tracks-container');
        if (container) {
          container.innerHTML = this._renderTracksHtml(pl, this._getPlaylistSorted(pl.tracks || []));
        }
      }, 250));
    }
  },

  
  _renderTracksHtml(pl, tracks) {
    const isYm = pl.isYandex === true || pl.title === 'Яндекс Музыка';
    const isLocalLikes = pl.isLocalLikes === true;
    if (tracks.length === 0) {
      if (isLocalLikes) return '<div class="empty-state" style="padding:60px 0"><p style="color:rgba(255,255,255,0.4)">Здесь пока пусто — треки появятся, если SoundCloud ограничит лайки</p></div>';
      if (isYm) return '<div class="empty-state" style="padding:60px 0"><p>Треки из импорта появятся здесь</p></div>';
      return '<div class="empty-state" style="padding:60px 0"><p>Добавьте треки через ПКМ на любом треке</p></div>';
    }

    const shown = tracks.slice(0, this._shownCount);
    let html;

    if (this._viewMode === 'cards') {
      html = '<div class="collection-grid">' + shown.map(t =>
        '<div class="collection-grid-item">' + TrackCardComponent.card(t, tracks) + '</div>'
      ).join('') + '</div>';
    } else {
      
      html = '<div style="display:flex;flex-direction:column;gap:2px">' + shown.map((t, i) => {
        const row = TrackCardComponent.row(t, i, tracks);
        if (isYm) {
          
          return row;
        }
        return `<div class="pl-track-row-wrap">${row}<button class="pl-remove-track-btn" onclick="event.stopPropagation(); PlaylistsPage.removeTrack('${Utils.esc(pl.id)}','${Utils.esc(t.urn)}')" title="Убрать из плейлиста"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg></button></div>`;
      }).join('') + '</div>';
    }

    if (tracks.length > this._shownCount) {
      const remaining = tracks.length - this._shownCount;
      html += `<div style="display:flex;justify-content:center;padding:24px 0"><button class="search-load-more" onclick="PlaylistsPage._loadMoreTracks('${Utils.esc(pl.id)}')">Загрузить ещё (${remaining})</button></div>`;
    }
    return html;
  },

  
  _loadMoreTracks(id) {
    if (!this._currentPl || this._currentPl.id !== id) return;
    this._shownCount += 50;

    
    if (this._shownCount > 200 && this._viewMode === 'cards') {
      this._viewMode = 'list';
      const settings = Store.get('settings') || {};
      settings['plViewMode_' + id] = 'list';
      Store.set({ settings });
      document.querySelectorAll('.collection-view-toggle .view-toggle-btn').forEach(btn => {
        btn.classList.toggle('active', btn.dataset.view === 'list');
      });
      InAppModal.confirm({
        title: 'Компактный режим', hideCancel: true,
        message: 'Загружено много треков — для лучшей производительности включён компактный режим.',
        confirmText: 'ОК', danger: false, onConfirm: () => {},
      });
    }

    const container = document.getElementById('playlist-tracks-container');
    if (container) {
      container.style.opacity = '0';
      requestAnimationFrame(() => {
        container.innerHTML = this._renderTracksHtml(this._currentPl, this._getPlaylistSorted(this._currentPl.tracks || []));
        container.style.transition = 'opacity 0.2s';
        container.style.opacity = '1';
      });
    }
  },

  
  _setView(mode) {
    if (!this._currentPl) return;
    
    if (mode === 'cards' && this._shownCount > 200) {
      InAppModal.confirm({
        title: 'Слишком много треков!', hideCancel: true,
        message: 'Загружено больше 200 треков — для лучшей производительности доступен только компактный режим.',
        confirmText: 'ОК', danger: false, onConfirm: () => {},
      });
      return;
    }
    if (mode === this._viewMode) return;
    this._viewMode = mode;
    const settings = Store.get('settings') || {};
    settings['plViewMode_' + this._currentPl.id] = mode;
    Store.set({ settings });
    document.querySelectorAll('.playlist-detail-header .view-toggle-btn, .collection-view-toggle .view-toggle-btn').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.view === mode);
    });
    const container = document.getElementById('playlist-tracks-container');
    if (container) {
      container.style.opacity = '0';
      container.style.transform = 'translateY(4px)';
      container.style.transition = 'opacity 0.18s ease, transform 0.18s ease';
      setTimeout(() => {
        container.innerHTML = this._renderTracksHtml(this._currentPl, this._getPlaylistSorted(this._currentPl.tracks || []));
        requestAnimationFrame(() => { container.style.opacity = '1'; container.style.transform = 'translateY(0)'; });
      }, 160);
    }
  },

  
  _filterQuery: '',
  _sortMode: 'default',

  _getPlaylistSorted(tracks) {
    let result = [...tracks];
    if (this._filterQuery) {
      const q = this._filterQuery;
      result = result.filter(t =>
        (t.title || '').toLowerCase().includes(q) ||
        (t.user?.username || '').toLowerCase().includes(q)
      );
    }
    if (this._sortMode === 'plays') result.sort((a, b) => (b.playback_count || 0) - (a.playback_count || 0));
    else if (this._sortMode === 'likes') result.sort((a, b) => (b.favoritings_count ?? b.likes_count ?? 0) - (a.favoritings_count ?? a.likes_count ?? 0));
    return result;
  },

  _setSort(mode) {
    if (!this._currentPl) return;
    this._sortMode = mode;
    document.querySelectorAll('.collection-sort-btn').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.sort === mode);
    });
    const container = document.getElementById('playlist-tracks-container');
    if (container) {
      container.innerHTML = this._renderTracksHtml(this._currentPl, this._getPlaylistSorted(this._currentPl.tracks || []));
    }
  },

  playPlaylist(id) {
    const pl = (Store.get('playlists') || []).find(p => p.id === id);
    if (!pl || !pl.tracks.length) return;
    Store.play(pl.tracks[0], pl.tracks);
  },

  removeTrack(playlistId, urn) {
    Store.removeTrackFromPlaylist(playlistId, urn);
    this.openPlaylist(playlistId);
  },

  
  _playlistContextMenu(e, id, title) {
    e.preventDefault();
    e.stopPropagation();
    document.querySelectorAll('.pl-ctx-menu').forEach(m => m.remove());

    
    const pl = (Store.get('playlists') || []).find(p => p.id === id);
    const isYm = pl && (pl.isYandex === true || pl.title === 'Яндекс Музыка');
    const isLocalLikes = pl && pl.isLocalLikes === true;

    
    if (isLocalLikes) return;

    const menu = document.createElement('div');
    menu.className = 'pl-ctx-menu ctx-menu';
    menu.style.cssText = 'left:' + Math.min(e.clientX, window.innerWidth - 200) + 'px;top:' + Math.min(e.clientY, window.innerHeight - 100) + 'px';
    menu.innerHTML = `
      ${isYm ? '' : '<div class="ctx-item" data-action="rename"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg> Переименовать</div><div class="ctx-sep"></div>'}
      <div class="ctx-item ctx-danger" data-action="delete"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg> Удалить плейлист</div>
    `;
    menu.addEventListener('click', (ev) => {
      const action = ev.target.closest('[data-action]')?.dataset.action;
      menu.remove();
      if (action === 'rename') this._showRename(id, title);
      else if (action === 'delete') this._confirmDelete(id);
    });
    document.body.appendChild(menu);
    requestAnimationFrame(() => menu.classList.add('open'));
    setTimeout(() => document.addEventListener('click', () => { menu.classList.remove('open'); setTimeout(() => menu.remove(), 200); }, { once: true }), 10);
    Utils.log('info', '[Playlists] Context menu opened for: ' + title);
  },

  
  _dragIdx: -1,
  _dragStart(e, idx) {
    this._dragIdx = idx;
    e.dataTransfer.effectAllowed = 'move';
    e.target.classList.add('dragging');
    Utils.log('info', '[Playlists] Drag started: index=' + idx);
  },
  _dragEnd(e) {
    e.target.classList.remove('dragging');
    document.querySelectorAll('.playlist-item-card.dragging').forEach(el => el.classList.remove('dragging'));
  },
  _dragOver(e) {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  },
  _dragDrop(e, targetIdx) {
    e.preventDefault();
    const fromIdx = this._dragIdx;
    if (fromIdx < 0 || fromIdx === targetIdx) return;
    const playlists = [...(Store.get('playlists') || [])];
    const [moved] = playlists.splice(fromIdx, 1);
    playlists.splice(targetIdx, 0, moved);
    Store.set({ playlists });
    this._renderGrid();
    document.querySelectorAll('.playlist-item-card.dragging').forEach(el => el.classList.remove('dragging'));
    Utils.log('info', '[Playlists] Reordered: ' + fromIdx + ' → ' + targetIdx);
  },

  
  _showCreate() {
    InAppModal.prompt({
      title: 'Новый плейлист',
      placeholder: 'Название плейлиста',
      confirmText: 'Создать',
      onConfirm: (title) => {
        if (!title.trim()) return;
        
        const reserved = Store.RESERVED_PLAYLIST_NAMES || ['Локально Нравится', 'Яндекс Музыка', 'YM'];
        if (reserved.some(n => title.trim().toLowerCase() === n.toLowerCase())) {
          Utils.toast('Это название зарезервировано системой');
          return;
        }
        Store.createPlaylist(title);
        this._renderGrid();
      },
    });
  },

  _showRename(id, currentTitle) {
    
    const plCheck = (Store.get('playlists') || []).find(p => p.id === id);
    if (plCheck && (plCheck.isLocalLikes || plCheck.isYandex)) {
      Utils.toast('Этот плейлист нельзя переименовать');
      return;
    }
    InAppModal.prompt({
      title: 'Переименовать плейлист',
      placeholder: 'Новое название',
      initialValue: currentTitle,
      confirmText: 'Сохранить',
      onConfirm: (title) => {
        if (!title.trim()) return;
        
        const reserved = Store.RESERVED_PLAYLIST_NAMES || ['Локально Нравится', 'Яндекс Музыка', 'YM'];
        if (reserved.some(n => title.trim().toLowerCase() === n.toLowerCase())) {
          Utils.toast('Это название зарезервировано системой');
          return;
        }
        Store.renamePlaylist(id, title);
        this.openPlaylist(id);
      },
    });
  },

  _confirmDelete(id) {
    const pl = (Store.get('playlists') || []).find(p => p.id === id);
    if (!pl) return;
    InAppModal.confirm({
      title: 'Удалить плейлист',
      message: `Удалить «${pl.title}»? Треки из плейлиста не удалятся.`,
      confirmText: 'Удалить',
      danger: true,
      onConfirm: () => { Store.deletePlaylist(id); this.render(); },
    });
  },

  
  _changeCover(id) {
    const input = document.createElement('input');
    input.type   = 'file';
    input.accept = 'image/*';
    input.style.display = 'none';
    document.body.appendChild(input);
    input.click();
    input.addEventListener('change', () => {
      const file = input.files[0];
      if (!file) { input.remove(); return; }
      const reader = new FileReader();
      reader.onload = (ev) => {
        Store.setPlaylistCover(id, ev.target.result);
        this.openPlaylist(id);
        Utils.toast('Обложка обновлена');
      };
      reader.readAsDataURL(file);
      input.remove();
    });
  },
  
  async _enrichTracksStats(playlistId, tracks) {
    const HP_SVG = '<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 18v-6a9 9 0 0 1 18 0v6"/><path d="M21 19a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3zM3 19a2 2 0 0 0 2 2h1a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2H3z"/></svg>';
    const HT_SVG = '<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>';
    const BATCH = 5;
    for (let i = 0; i < tracks.length; i += BATCH) {
      const batch = tracks.slice(i, i + BATCH);
      await Promise.all(batch.map(async function(t) {
        try {
          const fresh = await API.getTrack(t.urn);
          if (!fresh) return;
          
          const updated = Store.get('playlists').map(function(pl) {
            if (pl.id !== playlistId) return pl;
            return Object.assign({}, pl, {
              tracks: pl.tracks.map(function(st) {
                if (st.urn !== t.urn) return st;
                return Object.assign({}, st, {
                  playback_count: fresh.playback_count ?? st.playback_count,
                  favoritings_count: fresh.favoritings_count ?? fresh.likes_count ?? st.favoritings_count,
                  likes_count: fresh.likes_count ?? fresh.favoritings_count ?? st.likes_count,
                });
              })
            });
          });
          Store.set({ playlists: updated });
          
          const escaped = CSS.escape(t.urn);
          const row = document.querySelector('[data-urn="' + escaped + '"] .track-row-stats');
          if (row && fresh.playback_count > 0) {
            const hp = '<span class="track-row-stat">' + HP_SVG + Utils.fc(fresh.playback_count) + '</span>';
            const lc = fresh.favoritings_count ?? fresh.likes_count;
            const ht = lc > 0 ? '<span class="track-row-stat">' + HT_SVG + Utils.fc(lc) + '</span>' : '';
            row.innerHTML = hp + ht;
          }
        } catch (e) {  }
      }));
      await new Promise(function(r) { setTimeout(r, 200); });
    }
  },

};


const InAppModal = {
  _el: null,

  prompt({ title, placeholder = '', initialValue = '', confirmText = 'OK', onConfirm }) {
    this._close();
    const modal = document.createElement('div');
    modal.className = 'in-app-modal-wrap';
    modal.innerHTML = `
      <div class="in-app-modal-backdrop"></div>
      <div class="in-app-modal">
        <div class="in-app-modal-title">${Utils.esc(title)}</div>
        <input class="in-app-modal-input" type="text" placeholder="${Utils.esc(placeholder)}" value="${Utils.esc(initialValue)}" autocomplete="off" spellcheck="false">
        <div class="in-app-modal-actions">
          <button class="in-app-modal-cancel">Отмена</button>
          <button class="in-app-modal-confirm">${Utils.esc(confirmText)}</button>
        </div>
      </div>
    `;
    document.body.appendChild(modal);
    this._el = modal;

    const input = modal.querySelector('.in-app-modal-input');
    input.focus();
    input.select();

    const confirm = () => {
      const val = input.value;
      this._close();
      onConfirm(val);
    };
    modal.querySelector('.in-app-modal-confirm').addEventListener('click', confirm);
    modal.querySelector('.in-app-modal-cancel').addEventListener('click', () => this._close());
    modal.querySelector('.in-app-modal-backdrop').addEventListener('click', () => this._close());
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') confirm();
      if (e.key === 'Escape') this._close();
    });

    requestAnimationFrame(() => modal.classList.add('open'));
  },

  confirm({ title, message = '', confirmText = 'OK', danger = false, hideCancel = false, onConfirm }) {
    this._close();
    const modal = document.createElement('div');
    modal.className = 'in-app-modal-wrap';
    modal.innerHTML = `
      <div class="in-app-modal-backdrop"></div>
      <div class="in-app-modal">
        <div class="in-app-modal-title">${Utils.esc(title)}</div>
        ${message ? `<div class="in-app-modal-msg">${Utils.esc(message)}</div>` : ''}
        <div class="in-app-modal-actions">
          ${hideCancel ? '' : '<button class="in-app-modal-cancel">Отмена</button>'}
          <button class="in-app-modal-confirm ${danger ? 'danger' : ''}">${Utils.esc(confirmText)}</button>
        </div>
      </div>
    `;
    document.body.appendChild(modal);
    this._el = modal;

    modal.querySelector('.in-app-modal-confirm').addEventListener('click', () => { this._close(); onConfirm(); });
    const cancelBtn = modal.querySelector('.in-app-modal-cancel');
    if (cancelBtn) cancelBtn.addEventListener('click', () => this._close());
    modal.querySelector('.in-app-modal-backdrop').addEventListener('click', () => this._close());

    requestAnimationFrame(() => modal.classList.add('open'));
  },

  _close() {
    if (!this._el) return;
    this._el.classList.remove('open');
    const el = this._el;
    this._el = null;
    setTimeout(() => el?.remove(), 250);
  },
  
  async _enrichTracksStats(playlistId, tracks) {
    const HP_SVG = '<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 18v-6a9 9 0 0 1 18 0v6"/><path d="M21 19a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3zM3 19a2 2 0 0 0 2 2h1a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2H3z"/></svg>';
    const HT_SVG = '<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>';
    const BATCH = 5;
    for (let i = 0; i < tracks.length; i += BATCH) {
      const batch = tracks.slice(i, i + BATCH);
      await Promise.all(batch.map(async function(t) {
        try {
          const fresh = await API.getTrack(t.urn);
          if (!fresh) return;
          
          const updated = Store.get('playlists').map(function(pl) {
            if (pl.id !== playlistId) return pl;
            return Object.assign({}, pl, {
              tracks: pl.tracks.map(function(st) {
                if (st.urn !== t.urn) return st;
                return Object.assign({}, st, {
                  playback_count: fresh.playback_count ?? st.playback_count,
                  favoritings_count: fresh.favoritings_count ?? fresh.likes_count ?? st.favoritings_count,
                  likes_count: fresh.likes_count ?? fresh.favoritings_count ?? st.likes_count,
                });
              })
            });
          });
          Store.set({ playlists: updated });
          
          const escaped = CSS.escape(t.urn);
          const row = document.querySelector('[data-urn="' + escaped + '"] .track-row-stats');
          if (row && fresh.playback_count > 0) {
            const hp = '<span class="track-row-stat">' + HP_SVG + Utils.fc(fresh.playback_count) + '</span>';
            const lc = fresh.favoritings_count ?? fresh.likes_count;
            const ht = lc > 0 ? '<span class="track-row-stat">' + HT_SVG + Utils.fc(lc) + '</span>' : '';
            row.innerHTML = hp + ht;
          }
        } catch (e) {  }
      }));
      await new Promise(function(r) { setTimeout(r, 200); });
    }
  },

};


const PlaylistPickerModal = {
  _track: null,

  open(track) {
    this._track = track;
    this._render();
  },

  _render() {
    let el = document.getElementById('playlist-picker-modal');
    if (!el) { el = document.createElement('div'); el.id = 'playlist-picker-modal'; document.body.appendChild(el); }

    
    const playlists = (Store.get('playlists') || []).filter(pl =>
      !pl.isYandex && pl.title !== 'Яндекс Музыка' && !pl.isLocalLikes
    );
    const track = this._track;

    el.innerHTML = `
      <div class="modal-backdrop" onclick="PlaylistPickerModal.close()"></div>
      <div class="playlist-picker-panel">
        <div class="playlist-picker-title">Добавить в плейлист</div>
        <button class="playlist-picker-create" onclick="PlaylistPickerModal._createNew()">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
          Создать новый плейлист
        </button>
        ${playlists.length > 0 ? `
          <div style="height:1px;background:rgba(255,255,255,0.07);margin:8px 0"></div>
          ${playlists.map(pl => `
            <div class="playlist-picker-item" onclick="PlaylistPickerModal._addTo('${Utils.esc(pl.id)}')">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.4)" stroke-width="2"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/></svg>
              <span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${Utils.esc(pl.title)}</span>
              <span style="font-size:11px;color:rgba(255,255,255,0.3)">${pl.tracks.length}</span>
            </div>
          `).join('')}
        ` : '<div style="font-size:12px;color:rgba(255,255,255,0.3);padding:8px;text-align:center">Нет плейлистов</div>'}
      </div>
    `;
    requestAnimationFrame(() => el.classList.add('open'));
    setTimeout(() => document.addEventListener('click', (e) => {
      if (!el.querySelector('.playlist-picker-panel')?.contains(e.target)) this.close();
    }, { once: true }), 60);
  },

  _addTo(playlistId) {
    if (this._track) {
      Store.addTrackToPlaylist(playlistId, this._track);
      this._toast('Добавлено в плейлист');
    }
    this.close();
  },

  _createNew() {
    this.close();
    setTimeout(() => {
      InAppModal.prompt({
        title: 'Новый плейлист',
        placeholder: 'Название плейлиста',
        confirmText: 'Создать',
        onConfirm: (title) => {
          if (!title.trim()) return;
          
          const reserved = Store.RESERVED_PLAYLIST_NAMES || ['Локально Нравится', 'Яндекс Музыка', 'YM'];
          if (reserved.some(n => title.trim().toLowerCase() === n.toLowerCase())) {
            Utils.toast('Это название зарезервировано системой');
            return;
          }
          const pl = Store.createPlaylist(title);
          if (this._track) {
            Store.addTrackToPlaylist(pl.id, this._track);
            this._toast('Плейлист создан и трек добавлен');
          } else {
            this._toast('Плейлист создан');
          }
        },
      });
    }, 150);
  },

  _toast(msg) {
    const t = document.createElement('div');
    t.textContent = msg;
    t.style.cssText = 'position:fixed;bottom:90px;left:50%;transform:translateX(-50%) translateY(10px);background:rgba(28,28,28,0.95);backdrop-filter:blur(20px);border:1px solid rgba(255,255,255,0.1);border-radius:20px;padding:8px 18px;font-size:13px;color:white;z-index:99999;transition:all 0.3s ease;opacity:0;pointer-events:none;';
    document.body.appendChild(t);
    requestAnimationFrame(() => requestAnimationFrame(() => {
      t.style.opacity = '1'; t.style.transform = 'translateX(-50%) translateY(0)';
    }));
    setTimeout(() => { t.style.opacity = '0'; t.style.transform = 'translateX(-50%) translateY(10px)'; setTimeout(() => t.remove(), 300); }, 2000);
  },

  close() {
    const el = document.getElementById('playlist-picker-modal');
    if (!el) return;
    el.classList.remove('open');
    setTimeout(() => el.remove(), 250);
    this._track = null;
  },
  
  async _enrichTracksStats(playlistId, tracks) {
    const HP_SVG = '<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 18v-6a9 9 0 0 1 18 0v6"/><path d="M21 19a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3zM3 19a2 2 0 0 0 2 2h1a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2H3z"/></svg>';
    const HT_SVG = '<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>';
    const BATCH = 5;
    for (let i = 0; i < tracks.length; i += BATCH) {
      const batch = tracks.slice(i, i + BATCH);
      await Promise.all(batch.map(async function(t) {
        try {
          const fresh = await API.getTrack(t.urn);
          if (!fresh) return;
          
          const updated = Store.get('playlists').map(function(pl) {
            if (pl.id !== playlistId) return pl;
            return Object.assign({}, pl, {
              tracks: pl.tracks.map(function(st) {
                if (st.urn !== t.urn) return st;
                return Object.assign({}, st, {
                  playback_count: fresh.playback_count ?? st.playback_count,
                  favoritings_count: fresh.favoritings_count ?? fresh.likes_count ?? st.favoritings_count,
                  likes_count: fresh.likes_count ?? fresh.favoritings_count ?? st.likes_count,
                });
              })
            });
          });
          Store.set({ playlists: updated });
          
          const escaped = CSS.escape(t.urn);
          const row = document.querySelector('[data-urn="' + escaped + '"] .track-row-stats');
          if (row && fresh.playback_count > 0) {
            const hp = '<span class="track-row-stat">' + HP_SVG + Utils.fc(fresh.playback_count) + '</span>';
            const lc = fresh.favoritings_count ?? fresh.likes_count;
            const ht = lc > 0 ? '<span class="track-row-stat">' + HT_SVG + Utils.fc(lc) + '</span>' : '';
            row.innerHTML = hp + ht;
          }
        } catch (e) {  }
      }));
      await new Promise(function(r) { setTimeout(r, 200); });
    }
  },

};
