

const ArtistPage = {
  _allTracks:   [],
  _filterQuery: '',
  _sortMode:    'default',  

  open(user) {
    this._allTracks   = [];
    this._filterQuery = '';
    this._sortMode    = 'default';
    this._render(user);
    this._loadTracks(user.urn);
  },

  openFromUrn(urn, username) {
    if (!urn) return;
    this._allTracks   = [];
    this._filterQuery = '';
    this._sortMode    = 'default';
    this._render({ urn, username, avatar_url: null });
    API.getUser(urn).then(u => {
      
      const existingCache = SessionCache.getArtist(urn);
      SessionCache.setArtist(urn, { user: u, tracks: existingCache?.tracks || [] });
      const modal = document.getElementById('artist-modal');
      if (!modal || modal.dataset.urn !== urn) return;
      const avatar = Utils.art(u.avatar_url, 't300x300');
      const avatarWrap = modal.querySelector('.artist-modal-avatar');
      if (avatarWrap && avatar) {
        avatarWrap.innerHTML = `<img src="${Utils.esc(avatar)}" alt="" class="artist-avatar-clickable" data-avatar-url="${Utils.esc(u.avatar_url || '')}" data-username="${Utils.esc(u.username || '')}" style="cursor:pointer">`;
        
        ArtistPage._attachAvatarHandlers();
      }
      modal.querySelector('.artist-modal-name').textContent = u.username || username;
      modal.querySelector('.artist-modal-stats').innerHTML = this._statsHtml(u);
    }).catch(() => {});
    this._loadTracks(urn);
  },

  _render(user) {
    const avatar = Utils.art(user.avatar_url, 't300x300');
    let el = document.getElementById('artist-modal');
    if (!el) { el = document.createElement('div'); el.id = 'artist-modal'; document.body.appendChild(el); }
    el.dataset.urn = user.urn || '';
    el.innerHTML = `
      <div class="modal-backdrop" onclick="ArtistPage.close()"></div>
      <div class="modal-panel artist-modal-panel">
        <button class="modal-close" onclick="ArtistPage.close()">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>
        </button>
        <div class="artist-modal-header">
          <div class="artist-modal-avatar">
            ${avatar ? `<img src="${Utils.esc(avatar)}" alt="" class="artist-avatar-clickable" data-avatar-url="${Utils.esc(user.avatar_url || '')}" data-username="${Utils.esc(user.username || '')}" style="cursor:pointer">` : '<div class="artist-modal-avatar-ph"></div>'}
          </div>
          <div class="artist-modal-meta">
            <div class="artist-modal-name">${Utils.esc(user.username || '')}</div>
            <div class="artist-modal-stats">${this._statsHtml(user)}</div>
          </div>
        </div>
        <div class="artist-search-wrap">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
          <input id="artist-filter-input" class="artist-filter-input" type="text" placeholder="Фильтр по названию..." autocomplete="off">
        </div>
        <!-- Sort / filter bar -->
        <div class="artist-sort-bar" id="artist-sort-bar">
          <button class="artist-sort-btn active" data-sort="default" onclick="ArtistPage._setSort('default')">
            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/></svg>
            По умолчанию
          </button>
          <button class="artist-sort-btn" data-sort="plays" onclick="ArtistPage._setSort('plays')">
            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 18v-6a9 9 0 0 1 18 0v6"/><path d="M21 19a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3zM3 19a2 2 0 0 0 2 2h1a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2H3z"/></svg>
            Популярные
          </button>
          <button class="artist-sort-btn" data-sort="likes" onclick="ArtistPage._setSort('likes')">
            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
            Залайканные
          </button>
        </div>
        <div id="artist-tracks" class="artist-modal-tracks">
          <div class="flex-center" style="padding:40px"><div class="spinner-inline"></div></div>
        </div>
      </div>
    `;

    requestAnimationFrame(() => el.classList.add('open'));

    
    this._attachAvatarHandlers();

    const filterInput = document.getElementById('artist-filter-input');
    if (filterInput) {
      filterInput.addEventListener('input', (e) => {
        this._filterQuery = e.target.value.toLowerCase().trim();
        this._renderTracks();
      });
    }
  },

  _setSort(mode) {
    this._sortMode = mode;
    
    document.querySelectorAll('.artist-sort-btn').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.sort === mode);
    });
    this._renderTracks();
  },

  _statsHtml(u) {
    const parts = [];
    if (u.followers_count != null) parts.push(`${Utils.fc(u.followers_count)} подписчиков`);
    if (u.track_count      != null) parts.push(`${u.track_count} треков`);
    if (u.city)                     parts.push(u.city);
    return parts.join(' · ');
  },

  
  _attachAvatarHandlers() {
    const el = document.getElementById('artist-modal');
    if (!el) return;
    const img = el.querySelector('.artist-avatar-clickable');
    if (!img || img._mc_handlers) return;
    img._mc_handlers = true;
    img.addEventListener('click', () => {
      FullscreenArt.open({ avatar_url: img.dataset.avatarUrl, username: img.dataset.username });
    });
    img.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      TrackPage._artContextMenu(e, { artwork_url: img.dataset.avatarUrl, title: img.dataset.username });
    });
  },

  async _loadTracks(urn) {
    if (!urn) return;
    const container = document.getElementById('artist-tracks');
    if (!container) return;
    try {
      
      const cached = SessionCache.getArtist(urn);
      let tracks;
      if (cached && cached.tracks && cached.tracks.length > 0) {
        tracks = cached.tracks;
        Utils.log('info', '[ArtistPage] Using cached tracks: ' + tracks.length);
        
        if (cached.user) {
          const modal = document.getElementById('artist-modal');
          if (modal && modal.dataset.urn === urn) {
            const avatar = Utils.art(cached.user.avatar_url, 't300x300');
            const avatarWrap = modal.querySelector('.artist-modal-avatar');
            if (avatarWrap && avatar) avatarWrap.innerHTML = `<img src="${Utils.esc(avatar)}" alt="" class="artist-avatar-clickable" data-avatar-url="${Utils.esc(cached.user.avatar_url || '')}" data-username="${Utils.esc(cached.user.username || '')}" style="cursor:pointer">`;
            this._attachAvatarHandlers();
            const nameEl = modal.querySelector('.artist-modal-name');
            if (nameEl) nameEl.textContent = cached.user.username || '';
            const statsEl = modal.querySelector('.artist-modal-stats');
            if (statsEl) statsEl.innerHTML = this._statsHtml(cached.user);
          }
        }
      } else {
        const data = await API.getUserTracks(urn, 200);
        if (!document.getElementById('artist-modal') ||
            document.getElementById('artist-modal').dataset.urn !== urn) return;
        tracks = data.collection || [];
        
        const existingCache = SessionCache.getArtist(urn);
        SessionCache.setArtist(urn, { user: existingCache?.user || null, tracks });
      }

      this._allTracks = tracks;
      if (!this._allTracks.length) {
        container.innerHTML = '<div class="empty-state"><p>Нет треков</p></div>';
        return;
      }
      TrackCardComponent.setQueue(this._allTracks, 'artist');
      this._renderTracks();
    } catch {
      const c = document.getElementById('artist-tracks');
      if (c) c.innerHTML = '<div class="empty-state"><p>Ошибка загрузки</p></div>';
    }
  },

  _getSortedFiltered() {
    const q = this._filterQuery;
    let tracks = this._allTracks.slice();

    
    if (q) {
      tracks = tracks.filter(t =>
        t.title.toLowerCase().includes(q) ||
        (t.user?.username || '').toLowerCase().includes(q)
      );
    }

    
    if (this._sortMode === 'plays') {
      tracks.sort((a, b) => (b.playback_count || 0) - (a.playback_count || 0));
    } else if (this._sortMode === 'likes') {
      tracks.sort((a, b) =>
        (b.favoritings_count ?? b.likes_count ?? 0) -
        (a.favoritings_count ?? a.likes_count ?? 0)
      );
    }
    

    return tracks;
  },

  _renderTracks() {
    const container = document.getElementById('artist-tracks');
    if (!container) return;

    const visible = this._getSortedFiltered();
    TrackCardComponent.setQueue(this._allTracks, 'artist'); 

    if (visible.length === 0) {
      container.innerHTML = '<div class="empty-state"><p>Треков не найдено</p></div>';
      return;
    }

    container.innerHTML = `
      <div style="display:flex;flex-direction:column;gap:4px">
        ${visible.map((t, i) => TrackCardComponent.row(t, i, this._allTracks)).join('')}
      </div>`;
  },

  close() {
    const el = document.getElementById('artist-modal');
    if (!el) return;
    el.classList.remove('open');
    setTimeout(() => el.remove(), 300);
    this._allTracks   = [];
    this._filterQuery = '';
    this._sortMode    = 'default';
  },
};


const FullscreenArt = {
  open(trackOrJson) {
    const track = (typeof trackOrJson === 'string') ? JSON.parse(trackOrJson) : trackOrJson;
    const art = Utils.art(track.artwork_url || track.avatar_url, 't500x500');
    if (!art) return;
    let el = document.getElementById('fullscreen-art');
    if (!el) { el = document.createElement('div'); el.id = 'fullscreen-art'; }
    
    document.body.appendChild(el);
    el.innerHTML = `
      <div class="modal-backdrop" onclick="FullscreenArt.close()"></div>
      <div class="fullscreen-art-inner">
        <img src="${Utils.esc(art)}" alt="${Utils.esc(track.title || track.username || '')}" crossorigin="anonymous"
             oncontextmenu="FullscreenArt._imgContextMenu(event, '${Utils.esc(art)}')">
        ${track.title ? `<div class="fullscreen-art-title">${Utils.esc(track.title)}</div>` : ''}
        ${track.user?.username ? `<div class="fullscreen-art-artist" onclick="FullscreenArt.close();ArtistPage.openFromUrn('${Utils.esc(track.user?.urn || '')}','${Utils.esc(track.user?.username || '')}')" style="cursor:pointer">${Utils.esc(track.user?.username || '')}</div>` : ''}
        ${track.username && !track.title ? `<div class="fullscreen-art-title">${Utils.esc(track.username)}</div>` : ''}
        <div class="fullscreen-art-status" id="fs-art-status"></div>
      </div>`;
    requestAnimationFrame(() => el.classList.add('open'));
    Utils.log('info', '[FullscreenArt] Opened: ' + (track.title || track.username || ''));
  },

  
  _showStatus(msg, isError = false) {
    const el = document.getElementById('fs-art-status');
    if (!el) { Utils.toast(msg); return; }
    el.textContent = msg;
    el.style.color = isError ? 'rgba(255,100,100,0.8)' : 'rgba(255,255,255,0.5)';
    el.style.opacity = '1';
    setTimeout(() => { if (el) el.style.opacity = '0'; }, 2500);
  },

  
  _imgContextMenu(e, artUrl) {
    e.preventDefault();
    document.querySelectorAll('.fs-art-ctx').forEach(m => m.remove());
    const menu = document.createElement('div');
    menu.className = 'fs-art-ctx ctx-menu';
    menu.style.cssText = 'left:' + Math.min(e.clientX, window.innerWidth - 200) + 'px;top:' + Math.min(e.clientY, window.innerHeight - 50) + 'px';
    menu.innerHTML = '<div class="ctx-item">Копировать изображение</div>';
    menu.querySelector('.ctx-item').addEventListener('click', async () => {
      menu.remove();
      try {
        
        const img = document.querySelector('#fullscreen-art .fullscreen-art-inner img');
        if (!img || !img.complete) throw new Error('img not loaded');
        const canvas = document.createElement('canvas');
        canvas.width = img.naturalWidth || img.width || 500;
        canvas.height = img.naturalHeight || img.height || 500;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0);
        const blob = await new Promise((r, rej) => {
          try { canvas.toBlob(b => b ? r(b) : rej(new Error('toBlob null')), 'image/png'); }
          catch(e) { rej(e); }
        });
        await navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })]);
        FullscreenArt._showStatus('Изображение скопировано');
        Utils.log('info', '[Art] Image copied via canvas');
      } catch (err1) {
        
        try {
          const resp = await fetch(artUrl);
          const srcBlob = await resp.blob();
          const bmp = await createImageBitmap(srcBlob);
          const canvas = document.createElement('canvas');
          canvas.width = bmp.width; canvas.height = bmp.height;
          canvas.getContext('2d').drawImage(bmp, 0, 0);
          const pngBlob = await new Promise(r => canvas.toBlob(r, 'image/png'));
          await navigator.clipboard.write([new ClipboardItem({ 'image/png': pngBlob })]);
          FullscreenArt._showStatus('Изображение скопировано');
          Utils.log('info', '[Art] Image copied via fetch+canvas fallback');
        } catch (err2) {
          Utils.log('warning', '[Art] Copy failed: ' + err1.message + ' / ' + err2.message);
          FullscreenArt._showStatus('Не удалось скопировать', true);
        }
      }
    });
    document.body.appendChild(menu);
    requestAnimationFrame(() => menu.classList.add('open'));
    setTimeout(() => document.addEventListener('click', () => { menu.classList.remove('open'); setTimeout(() => menu.remove(), 200); }, { once: true }), 10);
  },

  close() {
    const el = document.getElementById('fullscreen-art');
    if (!el) return;
    el.classList.remove('open');
    setTimeout(() => el.remove(), 300);
  },
};


const TrackPage = {
  _pendingHighlight: null,

  open(track) {
    let el = document.getElementById('track-modal');
    if (!el) { el = document.createElement('div'); el.id = 'track-modal'; document.body.appendChild(el); }
    const art    = Utils.art(track.artwork_url, 't500x500');
    const avatar = Utils.art(track.user?.avatar_url, 'small');
    const isLiked = NowPlayingComponent._likedTracks.has(track.urn);
    TrackRegistry.reg(track);
    this._currentTrack = track;  

    el.innerHTML = `
      <div class="modal-backdrop" onclick="TrackPage.close()"></div>
      <div class="modal-panel track-modal-panel">
        <button class="modal-close" onclick="TrackPage.close()">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>
        </button>
        <div class="track-modal-hero">
          ${art ? `<img class="track-modal-art" src="${Utils.esc(art)}" alt="" id="track-modal-art-img" title="Открыть во весь экран" style="cursor:pointer">` : ''}
          <div class="track-modal-meta">
            <div class="track-modal-title">${Utils.esc(track.title)}</div>
            <div class="track-modal-artist-row" onclick="TrackPage.close();ArtistPage.openFromUrn('${Utils.esc(track.user?.urn || '')}','${Utils.esc(track.user?.username || '')}')" style="cursor:pointer">
              ${avatar ? `<img class="track-modal-avatar" src="${Utils.esc(avatar)}" alt="">` : ''}
              <span>${Utils.esc(track.user?.username || '')}</span>
            </div>
            <div class="track-modal-stats">
              ${track.playback_count != null ? `<span>${Utils.fc(track.playback_count)} Прослушиваний</span>` : ''}
              ${track.favoritings_count != null ? `<span>♥ ${Utils.fc(track.favoritings_count)}</span>` : ''}
              <span>${Utils.dur(track.duration)}</span>
              ${track.genre ? `<span>#${Utils.esc(track.genre)}</span>` : ''}
              ${track.created_at ? `<span>${new Date(track.created_at).toLocaleDateString('ru-RU',{day:'numeric',month:'short',year:'numeric'})}</span>` : ''}
            </div>
            ${(track.tag_list||'').trim() ? `<div class="track-modal-tags">${Utils.parseTags(track.tag_list).slice(0,8).map(t=>`<span class="track-modal-tag">#${Utils.esc(t)}</span>`).join('')}</div>` : ''}
            ${track.description ? (() => {
              const desc = track.description;
              const isLong = desc.length > 180;
              const shortDesc = isLong ? desc.substring(0, 180) + '...' : desc;
              return `<div class="track-modal-desc" id="track-desc-container">
                <div class="track-desc-text" id="track-desc-text">${Utils.linkify(shortDesc)}</div>
                ${isLong ? '<button class="track-desc-toggle" id="track-desc-toggle" onclick="TrackPage._toggleDesc()">Открыть полностью</button>' : ''}
              </div>`;
            })() : ''}
            <div class="track-modal-actions" style="display:flex;align-items:center;gap:10px;margin-top:auto">
              <button class="track-modal-play" onclick="TrackPage._playCurrentTrack()">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg> Слушать
              </button>
              <button id="track-modal-like-btn" class="track-modal-like-btn ${isLiked ? 'active' : ''}"
                      onclick="TrackPage._toggleLike('${Utils.esc(track.urn)}')"
                      title="${isLiked ? 'Убрать из любимых' : 'В любимые'}">
                <svg width="16" height="16" viewBox="0 0 24 24"
                     fill="${isLiked ? 'var(--accent)' : 'none'}"
                     stroke="${isLiked ? 'var(--accent)' : 'currentColor'}" stroke-width="2">
                  <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
                </svg>
              </button>
            </div>
          </div>
        </div>
        <div class="track-modal-comments-section">
          <h3>Комментарии</h3>
          <div id="track-modal-comments">
            <div class="flex-center" style="padding:30px"><div class="spinner-inline"></div></div>
          </div>
        </div>
      </div>`;
    requestAnimationFrame(() => el.classList.add('open'));

    
    const artImg = document.getElementById('track-modal-art-img');

    
    el._fullDesc = track.description || '';
    el._shortDesc = el._fullDesc.length > 180 ? el._fullDesc.substring(0, 180) + '...' : el._fullDesc;
    el._descExpanded = false;
    if (artImg) {
      artImg.addEventListener('click', () => FullscreenArt.open(track));
      artImg.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        TrackPage._artContextMenu(e, track);
      });
    }

    this._loadComments(track);
    Utils.log('info', '[TrackPage] Opened: ' + (track.title || ''));
  },

  openAndHighlight(track, commentId, commentTs) {
    this._pendingHighlight = { commentId, commentTs };
    this.open(track);
  },

  async _toggleLike(urn) {
    const btn = document.getElementById('track-modal-like-btn');
    if (!btn) return;
    const isLiked = NowPlayingComponent._likedTracks.has(urn);
    if (isLiked) {
      NowPlayingComponent._likedTracks.delete(urn);
      btn.classList.remove('active');
      btn.querySelector('svg').setAttribute('fill', 'none');
      btn.querySelector('svg').setAttribute('stroke', 'currentColor');
      try { await API.unlikeTrack(urn); NowPlayingComponent._removeFromLikedSection(urn); }
      catch { NowPlayingComponent._likedTracks.add(urn); btn.classList.add('active'); }
    } else {
      NowPlayingComponent._likedTracks.add(urn);
      btn.classList.add('active');
      btn.querySelector('svg').setAttribute('fill', 'var(--accent)');
      btn.querySelector('svg').setAttribute('stroke', 'var(--accent)');
      const track = TrackRegistry.get(urn);
      if (track) NowPlayingComponent._animateLike(track);
      try { await API.likeTrack(urn); }
      catch { NowPlayingComponent._likedTracks.delete(urn); btn.classList.remove('active'); }
    }
  },

  async _loadComments(track) {
    const container = document.getElementById('track-modal-comments');
    if (!container) return;
    try {
      
      let comments;
      const cached = SessionCache.getComments(track.urn);
      if (cached) {
        comments = cached;
        Utils.log('info', '[TrackPage] Using cached comments: ' + cached.length);
      } else {
        const data = await API.getTrackComments(track.urn, 200);
        comments = (data.collection || []).sort((a, b) => a.timestamp - b.timestamp);
        SessionCache.setComments(track.urn, comments);
      }
      if (!comments.length) { container.innerHTML = '<div class="empty-state"><p>Нет комментариев</p></div>'; this._pendingHighlight = null; return; }
      container.innerHTML = `
        <div class="track-comments-list">
          ${comments.map(c => {
            const av = Utils.art(c.user?.avatar_url, 'small');
            const userUrn = c.user?.urn || '';
            const userName = Utils.esc(c.user?.username || '');
            return `
              <div class="track-comment-row" data-cid="${c.id}" oncontextmenu="TrackPage._commentContextMenu(event, '${Utils.esc(c.body)}')">
                <div class="track-comment-ts" onclick="TrackPage._seekTo(${c.timestamp})" title="Перейти к ${Utils.dur(c.timestamp)}">${Utils.dur(c.timestamp)}</div>
                <div class="track-comment-avatar" onclick="TrackPage._seekTo(${c.timestamp})">
                  ${av ? `<img src="${Utils.esc(av)}" alt="">` : '<div class="track-comment-avatar-ph"></div>'}
                </div>
                <div class="track-comment-body">
                  <span class="track-comment-user comment-username-link" onclick="event.stopPropagation(); ArtistPage.openFromUrn('${Utils.esc(userUrn)}','${userName}')" title="Открыть профиль ${userName}">${userName}</span>
                  <span class="track-comment-text selectable-text">${Utils.esc(c.body)}</span>
                </div>
              </div>`;
          }).join('')}
        </div>`;
      if (this._pendingHighlight) {
        const { commentId } = this._pendingHighlight;
        this._pendingHighlight = null;
        setTimeout(() => {
          const row = container.querySelector(`[data-cid="${commentId}"]`);
          if (row) { row.scrollIntoView({ behavior: 'smooth', block: 'center' }); row.classList.add('comment-highlight'); setTimeout(() => row.classList.remove('comment-highlight'), 3000); }
        }, 120);
      }
    } catch {
      container.innerHTML = '<div class="empty-state"><p>Ошибка загрузки</p></div>';
      this._pendingHighlight = null;
    }
  },

  _seekTo(ts) { Player.seek(ts / 1000); },

  _currentTrack: null,

  
  _playCurrentTrack() {
    const t = this._currentTrack;
    if (t) Store.play(t, [t]);
  },

  
  _toggleDesc() {
    const el = document.getElementById('track-modal');
    if (!el) return;
    const textEl = document.getElementById('track-desc-text');
    const btn = document.getElementById('track-desc-toggle');
    if (!textEl || !btn) return;
    el._descExpanded = !el._descExpanded;
    textEl.innerHTML = Utils.linkify(el._descExpanded ? el._fullDesc : el._shortDesc);
    btn.textContent = el._descExpanded ? 'Свернуть' : 'Открыть полностью';
  },

  
  _commentContextMenu(e, text) {
    e.preventDefault();
    e.stopPropagation();
    document.querySelectorAll('.comment-ctx-menu').forEach(m => m.remove());
    const menu = document.createElement('div');
    menu.className = 'comment-ctx-menu ctx-menu';
    menu.style.cssText = 'left:' + Math.min(e.clientX, window.innerWidth - 180) + 'px;top:' + Math.min(e.clientY, window.innerHeight - 50) + 'px';
    menu.innerHTML = '<div class="ctx-item"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg> Копировать текст</div>';
    menu.querySelector('.ctx-item').addEventListener('click', () => {
      navigator.clipboard.writeText(text).then(() => Utils.toast('Текст скопирован')).catch(() => {});
      menu.remove();
    });
    document.body.appendChild(menu);
    requestAnimationFrame(() => menu.classList.add('open'));
    setTimeout(() => document.addEventListener('click', () => { menu.classList.remove('open'); setTimeout(() => menu.remove(), 200); }, { once: true }), 10);
  },

  
  _artContextMenu(e, trackOrObj) {
    e.preventDefault();
    e.stopPropagation();
    const artUrl = Utils.art(trackOrObj.artwork_url || trackOrObj.avatar_url, 't500x500');
    if (!artUrl) return;

    document.querySelectorAll('.art-ctx-menu').forEach(m => m.remove());
    const menu = document.createElement('div');
    menu.className = 'art-ctx-menu ctx-menu';
    menu.style.cssText = 'left:' + Math.min(e.clientX, window.innerWidth - 200) + 'px;top:' + Math.min(e.clientY, window.innerHeight - 60) + 'px';
    menu.innerHTML = '<div class="ctx-item"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg> Копировать изображение</div>';
    menu.querySelector('.ctx-item').addEventListener('click', async () => {
      menu.remove();
      try {
        const resp = await fetch(artUrl);
        const srcBlob = await resp.blob();
        const bmp = await createImageBitmap(srcBlob);
        const canvas = document.createElement('canvas');
        canvas.width = bmp.width; canvas.height = bmp.height;
        canvas.getContext('2d').drawImage(bmp, 0, 0);
        const pngBlob = await new Promise(r => canvas.toBlob(r, 'image/png'));
        await navigator.clipboard.write([new ClipboardItem({ 'image/png': pngBlob })]);
        Utils.toast('Изображение скопировано');
      } catch (err) {
        Utils.toast('Не удалось скопировать');
        Utils.log('warning', '[Art] Copy failed: ' + err.message);
      }
    });
    document.body.appendChild(menu);
    requestAnimationFrame(() => menu.classList.add('open'));
    setTimeout(() => document.addEventListener('click', () => { menu.classList.remove('open'); setTimeout(() => menu.remove(), 200); }, { once: true }), 10);
  },

  close() {
    const el = document.getElementById('track-modal');
    if (!el) return;
    el.classList.remove('open');
    setTimeout(() => el.remove(), 300);
  },
};
