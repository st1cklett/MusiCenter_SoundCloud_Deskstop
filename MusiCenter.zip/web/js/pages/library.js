

const LibraryPage = {
  _activeTab: 'playlists',
  _likedCount: 0,
  _followingCount: 0,

  async render() {
    const user = Store.get('user');
    if (!user) return;

    const container = document.getElementById('page-container');

    
    this._followingCount = user.followings_count || 0;

    container.innerHTML = `
      <div class="page">
        <div class="page-sections">

          <!-- ── Full-width profile banner ──────────────── -->
          <div class="lib-banner animate-in">
            <div class="lib-banner-bg"></div>
            <div class="lib-banner-noise"></div>
            <div class="lib-banner-content">
              <div class="lib-banner-left">
                <div class="lib-banner-avatar">
                  <img src="${Utils.art(user.avatar_url, 't200x200') || ''}" alt="">
                </div>
                <div class="lib-banner-info">
                  <div class="lib-banner-greeting">Моя библиотека</div>
                  <div class="lib-banner-name">${Utils.esc(user.username)}</div>
                </div>
              </div>
              <div class="lib-banner-stats">
                <div class="lib-stat-pill" onclick="LibraryPage.switchTab('likes')">
                  <div class="lib-stat-icon likes-icon">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
                  </div>
                  <div class="lib-stat-data">
                    <span class="lib-stat-num" id="lib-likes-count">…</span>
                    <span class="lib-stat-label">треков</span>
                  </div>
                </div>
                <div class="lib-stat-pill" onclick="LibraryPage.switchTab('following')">
                  <div class="lib-stat-icon follow-icon">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                  </div>
                  <div class="lib-stat-data">
                    <span class="lib-stat-num">${Utils.fc(this._followingCount)}</span>
                    <span class="lib-stat-label">подписок</span>
                  </div>
                </div>
                <button class="lib-shuffle-btn" onclick="LibraryPage.shuffleLikes()" title="Перемешать">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="16 3 21 3 21 8"/><line x1="4" y1="20" x2="21" y2="3"/><polyline points="21 16 21 21 16 21"/><line x1="15" y1="15" x2="21" y2="21"/><line x1="4" y1="4" x2="9" y2="9"/></svg>
                  Перемешать всё
                </button>
              </div>
            </div>
          </div>

          <!-- ── Tab navigation ────────────────────────── -->
          <div class="lib-tabs animate-in" style="animation-delay:80ms">
            <button class="lib-tab ${this._activeTab === 'playlists' ? 'active' : ''}" onclick="LibraryPage.switchTab('playlists')">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>
              Плейлисты
            </button>
            <button class="lib-tab ${this._activeTab === 'likes' ? 'active' : ''}" onclick="LibraryPage.switchTab('likes')">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
              Любимые треки
            </button>
            <button class="lib-tab ${this._activeTab === 'following' ? 'active' : ''}" onclick="LibraryPage.switchTab('following')">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>
              Подписки
            </button>
          </div>

          <!-- ── Content area ──────────────────────────── -->
          <div id="library-content" class="animate-in" style="animation-delay:140ms"></div>

        </div>
      </div>
    `;

    this._loadTab();
    this._fetchRealLikedCount();
    Store.on('playlists', () => { if (this._activeTab === 'playlists') this._loadTab(); });
  },

  async _fetchRealLikedCount() {
    try {
      const data = await API.getLikedTracks(1, 0);
      
      if (data.total != null) {
        this._likedCount = data.total;
      } else {
        
        const full = await API.getLikedTracks(200, 0);
        this._likedCount = (full.collection || []).length;
      }
    } catch {
      this._likedCount = 0;
    }
    const el = document.getElementById('lib-likes-count');
    if (el) el.textContent = Utils.fc(this._likedCount);
  },

  switchTab(tab) {
    this._activeTab = tab;
    document.querySelectorAll('.lib-tab').forEach(btn => {
      const t = btn.textContent.trim();
      const id = t === 'Плейлисты' ? 'playlists' : t === 'Любимые треки' ? 'likes' : 'following';
      btn.classList.toggle('active', id === tab);
    });
    this._loadTab();
  },

  async _loadTab() {
    const content = document.getElementById('library-content');
    if (!content) return;
    content.innerHTML = '<div class="flex-center" style="padding:80px 0"><div class="spinner-inline"></div></div>';
    try {
      if      (this._activeTab === 'likes')     await this._loadLikes(content);
      else if (this._activeTab === 'following')  await this._loadFollowing(content);
      else if (this._activeTab === 'playlists')  this._loadPlaylists(content);
    } catch (e) {
      content.innerHTML = '<div class="empty-state"><p>Ошибка загрузки</p></div>';
    }
  },

  async _loadLikes(container) {
    const data = await API.getLikedTracks(50);
    const tracks = data.collection || [];
    if (!tracks.length) { container.innerHTML = '<div class="empty-state"><p>Нет понравившихся треков</p></div>'; return; }
    
    this._likedCount = tracks.length;
    const el = document.getElementById('lib-likes-count');
    if (el) el.textContent = Utils.fc(this._likedCount);

    TrackCardComponent.setQueue(tracks, 'library');
    container.innerHTML = `<div style="display:flex;flex-direction:column;gap:4px">${tracks.map((t, i) => TrackCardComponent.row(t, i, tracks)).join('')}</div>`;
  },

  async _loadFollowing(container) {
    const data = await API.getMyFollowings(50);
    const users = data.collection || [];
    if (!users.length) { container.innerHTML = '<div class="empty-state"><p>Нет подписок</p></div>'; return; }
    container.innerHTML = `<div class="grid-5">${users.map(u => SearchPage._userCard(u)).join('')}</div>`;
  },

  _loadPlaylists(container) {
    const playlists = Store.get('playlists') || [];
    const createCard = `
      <div class="playlist-card" onclick="LibraryPage._createPlaylist()" style="cursor:pointer">
        <div class="playlist-card-art" style="display:flex;align-items:center;justify-content:center;background:rgba(255,255,255,0.03);border:2px dashed rgba(255,255,255,0.1)">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.3)" stroke-width="1.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
        </div>
        <div class="playlist-card-title" style="color:rgba(255,255,255,0.5)">Создать плейлист</div>
      </div>`;

    container.innerHTML = `
      <div class="grid-5">
        ${createCard}
        ${playlists.map(pl => {
          const art = pl.coverUrl || (pl.tracks?.[0] ? Utils.art(pl.tracks[0].artwork_url, 't300x300') : null);
          return `
            <div class="playlist-card" onclick="App.navigate('playlists'); setTimeout(() => PlaylistsPage.openPlaylist('${Utils.esc(pl.id)}'), 220)" style="cursor:pointer">
              <div class="playlist-card-art">
                ${art ? `<img src="${Utils.esc(art)}" alt="" loading="lazy" style="width:100%;height:100%;object-fit:cover">` :
                  '<div class="flex-center" style="width:100%;height:100%;background:rgba(255,255,255,0.04)"><svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.15)" stroke-width="1.5"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/></svg></div>'}
                <div class="playlist-card-count"><svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/></svg>${pl.tracks.length}</div>
              </div>
              <div class="playlist-card-title">${Utils.esc(pl.title)}</div>
              <div class="playlist-card-artist">${pl.tracks.length} треков</div>
            </div>`;
        }).join('')}
      </div>`;
  },

  async shuffleLikes() {
    try {
      const data = await API.getLikedTracks(200);
      const tracks = data.collection || [];
      if (!tracks.length) return;
      const shuffled = [...tracks].sort(() => Math.random() - 0.5);
      Store.play(shuffled[0], shuffled);
    } catch {}
  },

  _createPlaylist() {
    InAppModal.prompt({
      title: 'Новый плейлист',
      placeholder: 'Название плейлиста',
      confirmText: 'Создать',
      onConfirm: (title) => {
        if (!title.trim()) return;
        Store.createPlaylist(title);
      },
    });
  },
};
