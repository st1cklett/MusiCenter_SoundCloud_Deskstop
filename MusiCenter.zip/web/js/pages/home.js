

const HomePage = {
  _cache: {},

  async render() {
    const user  = Store.get('user');
    const greeting = Utils.greeting();

    const container = document.getElementById('page-container');
    container.innerHTML = `
      <div class="page">
        <div class="page-sections">
          <section class="greeting animate-in">
            <h1>${greeting}${user?.username ? `, ${Utils.esc(user.username)}` : ''}</h1>
            <div class="greeting-divider"></div>
          </section>
          <section id="home-featured"     class="animate-in" style="animation-delay:100ms">
            ${typeof SoundWave !== 'undefined' ? SoundWave.renderHero() : ''}
          </section>
          <section id="home-liked"        class="animate-in" style="animation-delay:200ms"></section>
          <section id="home-recent"       class="animate-in" style="animation-delay:250ms"></section>
          <section id="home-mixes"        class="animate-in" style="animation-delay:280ms"></section>
          <section id="home-recommended"  class="animate-in" style="animation-delay:300ms"></section>
          <section id="home-feed"         class="animate-in" style="animation-delay:350ms"></section>
        </div>
      </div>
    `;

    this._loadLikedTracks();
    this._loadRecentlyPlayed();
    this._loadMixedSelections();
    this._loadFeed();

    const settings = Store.get('settings') || {};
    const theme = Themes[settings.theme || 'soundcloud'];
    if (theme) {
      const greetingH1 = document.querySelector('.greeting h1');
      if (greetingH1) greetingH1.style.backgroundImage = theme.greetingGrad;
    }
  },

  
  _overlayAllTracks: [],   
  _overlayFilter: '',
  _overlaySort: 'default', 

  _overlayBatchSize: 30,
  _overlayRendered: 0,

  openAllTracks(title, tracks, showClearHistory = false) {
    const old = document.getElementById('home-all-overlay');
    if (old) old.remove();

    this._overlayAllTracks = tracks;
    this._overlayFilter    = '';
    this._overlaySort      = 'default';
    this._overlayRendered  = 0;

    TrackCardComponent.setQueue(tracks, 'home-overlay');
    tracks.forEach(t => TrackRegistry.reg(t));

    
    const firstBatch = tracks.slice(0, this._overlayBatchSize);
    this._overlayRendered = firstBatch.length;

    const overlay = document.createElement('div');
    overlay.id = 'home-all-overlay';

    overlay.innerHTML = `
      <div class="all-overlay-inner">
        <div class="all-overlay-header">
          <button class="all-overlay-back" onclick="HomePage._closeOverlay()">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
              <path d="M19 12H5M5 12l7-7M5 12l7 7"/>
            </svg>
          </button>
          <h2 class="all-overlay-title">${Utils.esc(title)}</h2>
          <span class="all-overlay-count" id="all-overlay-count">${tracks.length} треков</span>
          ${showClearHistory ? '<button class="all-overlay-clear-btn" onclick="HomePage._clearHistory()">Очистить историю</button>' : ''}
          <div class="all-overlay-filter-wrap">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
            <input id="all-overlay-search" class="all-overlay-search" type="text" placeholder="Поиск по названию..." autocomplete="off">
          </div>
        </div>
        <div class="all-overlay-sort-bar">
          <button class="all-overlay-sort-btn active" data-sort="default" onclick="HomePage._overlaySetSort('default')">
            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/></svg>
            По умолчанию
          </button>
          <button class="all-overlay-sort-btn" data-sort="plays" onclick="HomePage._overlaySetSort('plays')">
            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 18v-6a9 9 0 0 1 18 0v6"/><path d="M21 19a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3zM3 19a2 2 0 0 0 2 2h1a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2H3z"/></svg>
            По прослушкам
          </button>
          <button class="all-overlay-sort-btn" data-sort="likes" onclick="HomePage._overlaySetSort('likes')">
            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
            По лайкам
          </button>
        </div>
        <div class="all-overlay-grid" id="all-overlay-grid">
          ${firstBatch.map(t => `<div class="overlay-item">${TrackCardComponent.card(t, tracks)}</div>`).join('')}
        </div>
      </div>
    `;

    const content = document.getElementById('content');
    content.scrollTop = 0;
    content.appendChild(overlay);
    content.classList.add('overlay-locked');
    requestAnimationFrame(() => overlay.classList.add('open'));

    
    const innerEl = overlay.querySelector('.all-overlay-inner');
    if (innerEl && tracks.length > this._overlayBatchSize) {
      innerEl.addEventListener('scroll', Utils.throttle(() => {
        if (innerEl.scrollTop + innerEl.clientHeight >= innerEl.scrollHeight - 400) {
          this._overlayLoadMore();
        }
      }, 150));
    }

    const searchInput = overlay.querySelector('#all-overlay-search');
    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        this._overlayFilter = e.target.value.toLowerCase().trim();
        this._overlayRender();
      });
    }
  },

  
  _overlayLoadMore() {
    const grid = document.getElementById('all-overlay-grid');
    if (!grid) return;
    const tracks = this._getOverlaySortedFiltered();
    if (this._overlayRendered >= tracks.length) return;

    const nextBatch = tracks.slice(this._overlayRendered, this._overlayRendered + this._overlayBatchSize);
    this._overlayRendered += nextBatch.length;

    const fragment = document.createDocumentFragment();
    nextBatch.forEach(t => {
      const div = document.createElement('div');
      div.className = 'overlay-item';
      div.innerHTML = TrackCardComponent.card(t, tracks);
      fragment.appendChild(div);
    });
    grid.appendChild(fragment);
  },

  
  _getOverlaySortedFiltered() {
    let tracks = [...this._overlayAllTracks];
    if (this._overlayFilter) {
      const q = this._overlayFilter;
      tracks = tracks.filter(t =>
        (t.title || '').toLowerCase().includes(q) ||
        (t.user?.username || '').toLowerCase().includes(q)
      );
    }
    if (this._overlaySort === 'plays') {
      tracks.sort((a, b) => (b.playback_count || 0) - (a.playback_count || 0));
    } else if (this._overlaySort === 'likes') {
      tracks.sort((a, b) =>
        (b.favoritings_count ?? b.likes_count ?? 0) -
        (a.favoritings_count ?? a.likes_count ?? 0)
      );
    }
    return tracks;
  },

  _closeOverlay() {
    const ov = document.getElementById('home-all-overlay');
    if (!ov) return;
    ov.classList.remove('open');
    const content = document.getElementById('content');
    if (content) content.classList.remove('overlay-locked');
    setTimeout(() => ov.remove(), 250);
  },

  _overlaySetSort(mode) {
    this._overlaySort = mode;
    document.querySelectorAll('.all-overlay-sort-btn').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.sort === mode);
    });
    this._overlayRender();
  },

  _overlayRender() {
    const grid  = document.getElementById('all-overlay-grid');
    const count = document.getElementById('all-overlay-count');
    if (!grid) return;

    const tracks = this._getOverlaySortedFiltered();
    const batch = tracks.slice(0, this._overlayBatchSize);
    this._overlayRendered = batch.length;

    TrackCardComponent.setQueue(tracks, 'home-overlay-filter');
    grid.innerHTML = tracks.length
      ? batch.map(t => `<div class="overlay-item">${TrackCardComponent.card(t, tracks)}</div>`).join('')
      : '<div class="empty-state" style="grid-column:1/-1"><p>Ничего не найдено</p></div>';

    if (count) count.textContent = `${tracks.length} треков`;
  },

  
  async _loadLikedTracks() {
    const section = document.getElementById('home-liked');
    if (!section) return;
    section.innerHTML = this._sectionSkeleton('Любимые треки');

    try {
      const data = await API.getLikedTracks(20);
      let tracks = data.collection || [];

      
      if (typeof LocalLikes !== 'undefined') {
        const localTracks = LocalLikes.getTracks();
        if (localTracks.length > 0) {
          const likedUrns = new Set(tracks.map(t => t.urn));
          const extra = localTracks.filter(t => t.urn && !likedUrns.has(t.urn))
            .map(t => ({ ...t, _isLocalLike: true }));
          tracks = [...extra, ...tracks];
        }
      }

      if (tracks.length === 0) { section.innerHTML = ''; return; }

      if (typeof BypassEngine !== 'undefined') BypassEngine.cancelTimeoutWatch();

      TrackCardComponent.setQueue(tracks, 'home-liked');
      tracks.forEach(t => TrackRegistry.reg(t));
      this._cache.likedTracks = tracks;

      section.innerHTML = `
        ${this._sectionHeader('Любимые треки',
          '<svg width="15" height="15" viewBox="0 0 24 24" fill="var(--accent)" stroke="var(--accent)" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>',
          "App.navigate('liked')")}
        <div class="h-scroll home-h-scroll">
          ${tracks.map(t => `<div class="h-scroll-item">${TrackCardComponent.card(t, tracks)}</div>`).join('')}
        </div>
      `;
      this._attachWheelScroll(section.querySelector('.h-scroll'));

      if (tracks.length > 0) {
        this._loadFeatured(tracks[0]);
        this._loadRecommended(tracks);
      }
    } catch (e) {
      console.warn('Failed to load liked tracks:', e);
      Utils.log('warning', '[Home] Failed to load liked tracks: ' + e.message);
      
      setTimeout(() => {
        if (document.getElementById('home-liked')) {
          this._loadLikedTracks();
        }
      }, 3000);
    }
  },

  async _showAllLiked() {
    
    let tracks = this._cache.likedTracks || [];
    this.openAllTracks('Любимые треки', tracks);
    if (tracks.length <= 20) {
      try {
        const data = await API.getLikedTracks(200);
        const newTracks = data.collection || [];
        if (newTracks.length > tracks.length) {
          this._cache.likedTracks = newTracks;
          this._overlayAllTracks = newTracks;
          this._overlayRender();
          Utils.log('info', '[Home] Loaded full liked tracks: ' + newTracks.length);
        }
      } catch {}
    }
  },

  
  _loadFeatured(track) {
    
    if (typeof SoundWave !== 'undefined') SoundWave.initCanvas();
  },

  
  _loadRecentlyPlayed() {
    const section = document.getElementById('home-recent');
    if (!section) return;

    const recent = Store.get('recentlyPlayed') || [];
    if (recent.length === 0) { section.innerHTML = ''; return; }

    const allTracks = recent.slice(0, 100);
    const visible   = allTracks.slice(0, 20);
    TrackCardComponent.setQueue(visible, 'home-recent');
    allTracks.forEach(t => TrackRegistry.reg(t));
    this._cache.recentTracks = allTracks;

    section.innerHTML = `
      ${this._sectionHeader('Недавно прослушанные',
        '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.5)" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>',
        allTracks.length > 6 ? "App.navigate('recent')" : null)}
      <div class="h-scroll home-h-scroll">
        ${visible.map(t => `<div class="h-scroll-item">${TrackCardComponent.card(t, visible)}</div>`).join('')}
      </div>
    `;
    this._attachWheelScroll(section.querySelector('.h-scroll'));
  },

  _showAllRecent() {
    
    const tracks = this._cache.recentTracks || Store.get('recentlyPlayed') || [];
    this.openAllTracks('Недавно прослушанные', tracks, true);
  },

  
  _clearHistory() {
    InAppModal.confirm({
      title: 'Очистить историю',
      message: 'Вы уверены? Все недавно прослушанные треки будут удалены из истории.',
      confirmText: 'Очистить',
      danger: true,
      onConfirm: () => {
        Store.set({ recentlyPlayed: [] });
        this._cache.recentTracks = [];
        this._closeOverlay();
        
        if (Store.get('currentPage') === 'home') this.render();
        Utils.toast('История очищена');
        Utils.log('info', '[Home] Recently played history cleared');
      },
    });
  },

  
  _attachWheelScroll(el) {
    if (!el) return;
    el.addEventListener('wheel', (e) => {
      
      if (Math.abs(e.deltaX) > Math.abs(e.deltaY)) return;
      e.preventDefault();
      el.scrollLeft += e.deltaY * 3;
    }, { passive: false });
  },

  
  async _loadRecommended(likedTracks) {
    const section = document.getElementById('home-recommended');
    if (!section || !likedTracks?.length) return;
    section.innerHTML = this._sectionSkeleton('Рекомендации для вас');

    try {
      const seed = likedTracks[Math.floor(Math.random() * Math.min(likedTracks.length, 10))];
      const data = await API.getRecommended(seed.urn, 20);
      const tracks = data.collection || [];
      if (tracks.length === 0) { section.innerHTML = ''; return; }

      TrackCardComponent.setQueue(tracks, 'home-recommended');

      section.innerHTML = `
        ${this._sectionHeader('Рекомендации для вас',
          '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="rgba(251,191,36,0.7)" stroke-width="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>')}
        <div class="h-scroll home-h-scroll">
          ${tracks.map(t => `<div class="h-scroll-item">${TrackCardComponent.card(t, tracks)}</div>`).join('')}
        </div>
      `;
      this._attachWheelScroll(section.querySelector('.h-scroll'));
    } catch {
      section.innerHTML = '';
    }
  },

  
  async _loadMixedSelections() {
    const section = document.getElementById('home-mixes');
    if (!section) return;
    section.innerHTML = this._sectionSkeleton('Микс для вас');

    try {
      const data = await API.getMixedSelections();
      const sels = data?.collection || [];
      if (sels.length === 0) { section.innerHTML = ''; return; }

      const colors = ['#FF5500','#3B82F6','#8B5CF6','#EF4444','#F59E0B','#10B981','#EC4899','#6366F1'];
      const mixes = [];
      for (const sel of sels) {
        for (const item of (sel.items?.collection || [])) {
          if (item.kind === 'system-playlist' || item.kind === 'playlist') {
            const art = Utils.art(item.artwork_url || item.calculated_artwork_url || (item.tracks||[])[0]?.artwork_url, 't300x300') || '';
            const artists = (item.tracks||[]).slice(0,3).map(t=>t.user?.username).filter(Boolean).join(', ');
            mixes.push({
              title: item.title || sel.title || 'Микс',
              sub: artists || `${item.track_count||(item.tracks||[]).length} треков`,
              art, color: colors[mixes.length % colors.length],
              tracks: item.tracks || [],
              urn: item.urn || item.id,
              isSystem: item.kind === 'system-playlist',
            });
          }
        }
      }

      if (mixes.length === 0) { section.innerHTML = ''; return; }
      this._generatedMixes = mixes;

      const mixCards = mixes.map((m, i) => `
        <div class="mix-card" onclick="HomePage._playGeneratedMix(${i})"
             onmousedown="TrackCardComponent._tilt3D(this,event)"
             onmousemove="TrackCardComponent._tiltMove(this,event)"
             onmouseleave="TrackCardComponent._tiltReset(this)">
          <div class="mix-card-art" style="${m.art ? "background-image:url('"+m.art+"')" : 'background:linear-gradient(135deg,'+m.color+',#1a1a2e)'}">
            <div class="mix-card-overlay"><span class="mix-card-label" style="background:${m.color}">MIX ${i+1}</span></div>
            <button class="mix-card-play" onclick="event.stopPropagation();HomePage._playGeneratedMix(${i})">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>
            </button>
          </div>
          <div class="mix-card-info">
            <div class="mix-card-title">${Utils.esc(m.title)}</div>
            <div class="mix-card-sub">${Utils.esc(m.sub)}</div>
          </div>
        </div>
      `);

      section.innerHTML = `
        ${this._sectionHeader('Микс для вас',
          '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="rgba(255,85,0,0.8)" stroke-width="2"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>')}
        <div class="h-scroll home-h-scroll mix-scroll">
          ${mixCards.map(c => `<div class="h-scroll-item mix-scroll-item">${c}</div>`).join('')}
        </div>
      `;
      this._attachWheelScroll(section.querySelector('.h-scroll'));
    } catch (e) {
      
      section.innerHTML = '';
    }
  },

  _generatedMixes: [],

  async _playGeneratedMix(idx) {
    const mix = this._generatedMixes[idx];
    if (!mix) return;
    let tracks = mix.tracks || [];
    if (tracks.length === 0 && mix.urn) {
      try {
        Utils.toast('Загрузка микса...');
        const data = mix.isSystem ? await API.getSystemPlaylist(mix.urn) : await API.getPlaylist(mix.urn);
        tracks = data.tracks || [];
      } catch { Utils.toast('Не удалось загрузить микс'); return; }
    }
    if (tracks.length > 0) {
      tracks.forEach(t => TrackRegistry.reg(t));
      TrackCardComponent.setQueue(tracks, 'home-mix-play');
      Store.play(tracks[0], tracks);
    }
  },

  
  async _loadFeed() {
    const section = document.getElementById('home-feed');
    if (!section) return;
    section.innerHTML = this._sectionSkeleton('Ваша лента');

    try {
      const data = await API.getFeed(20);
      const items = data.collection || [];
      const tracks = items
        .filter(i => i.origin && (i.type?.includes('track') || i.origin.title))
        .map(i => i.origin)
        .filter(t => t.urn && t.title);

      if (tracks.length === 0) { section.innerHTML = ''; return; }

      TrackCardComponent.setQueue(tracks, 'home-feed');

      section.innerHTML = `
        ${this._sectionHeader('Ваша лента',
          '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.5)" stroke-width="2"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>')}
        <div class="feed-grid">
          ${tracks.slice(0, 12).map(t => TrackCardComponent.feedCard(t, tracks)).join('')}
        </div>
      `;
    } catch (e) {
      Utils.log('warning', '[Home] Failed to load recommended: ' + (e?.message || 'unknown'));
      section.innerHTML = '';
    }
  },

  
  _sectionHeader(title, icon, onclick) {
    return `
      <div class="section-header">
        <div class="section-header-left">
          <div class="section-icon">${icon}</div>
          <h2 class="section-title">${title}</h2>
        </div>
        ${onclick ? `<button class="section-see-all" onclick="${onclick}">Показать все <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg></button>` : ''}
      </div>
    `;
  },

  _sectionSkeleton(title) {
    return `
      <div class="section-header">
        <div class="section-header-left">
          <div class="section-icon"><div class="skeleton" style="width:15px;height:15px;border-radius:4px"></div></div>
          <h2 class="section-title">${title}</h2>
        </div>
      </div>
      <div class="h-scroll">
        ${Array(6).fill('').map(() => `
          <div class="h-scroll-item">
            <div class="skeleton round" style="aspect-ratio:1;width:100%"></div>
            <div class="skeleton" style="height:16px;width:75%;margin-top:10px"></div>
            <div class="skeleton" style="height:12px;width:50%;margin-top:6px"></div>
          </div>
        `).join('')}
      </div>
    `;
  },
};
