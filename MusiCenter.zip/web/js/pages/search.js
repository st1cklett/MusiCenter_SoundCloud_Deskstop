

const SearchPage = {
  _query: '',
  _debounceTimer: null,
  _cachedResults: null,   
  _cachedQuery:   '',     
  _searching:     false,  

  render() {
    const container = document.getElementById('page-container');
    container.innerHTML = `
      <div class="page">
        <div class="page-sections">
          <div class="search-input-wrap animate-in">
            <div class="search-icon">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
            </div>
            <input type="text" class="search-input" id="search-input"
                   placeholder="Поиск треков и артистов..."
                   value="${Utils.esc(this._query)}" autofocus>
            <button class="search-clear ${this._query ? 'visible' : ''}" id="search-clear"
                    onclick="SearchPage.clear()">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>
            </button>
          </div>

          <div id="search-results" class="animate-in" style="animation-delay:100ms"></div>
        </div>
      </div>
    `;

    const input = document.getElementById('search-input');
    input.addEventListener('input', (e) => {
      this._query = e.target.value;
      document.getElementById('search-clear').classList.toggle('visible', !!this._query);
      this._debounceSearch();
    });

    
    if (this._query && this._cachedQuery === this._query && this._cachedResults) {
      this._renderResults(this._cachedResults);
    } else if (this._query) {
      this._search();
    } else {
      this._showEmpty();
    }
  },

  clear() {
    this._query = '';
    this._cachedQuery = '';
    this._cachedResults = null;
    const input = document.getElementById('search-input');
    if (input) { input.value = ''; input.focus(); }
    document.getElementById('search-clear')?.classList.remove('visible');
    this._showEmpty();
  },

  _debounceSearch() {
    clearTimeout(this._debounceTimer);
    this._debounceTimer = setTimeout(() => {
      if (this._query.trim()) {
        Store.addRecentSearch(this._query.trim());
        this._search();
      } else {
        this._showEmpty();
      }
    }, 380);
  },

  async _search() {
    const query = this._query.trim();
    if (!query) return;
    this._searching = true;
    this._loadMoreOffset = 0;

    const results = document.getElementById('search-results');
    
    if (!this._cachedResults || this._cachedQuery !== query) {
      if (results) results.innerHTML = '<div class="flex-center" style="padding:80px 0"><div class="spinner-inline"></div></div>';
    }

    try {
      const data   = await API.searchTracks(query, 50);
      const tracks = (data.collection || []).filter(t => t.urn && t.title);

      this._cachedQuery   = query;
      this._cachedResults = tracks;

      
      if (this._query.trim() !== query) return;
      this._renderResults(tracks);
    } catch (e) {
      console.error('Search error:', e);
      if (document.getElementById('search-results'))
        document.getElementById('search-results').innerHTML = '<div class="empty-state"><p>Ошибка поиска</p></div>';
    } finally {
      this._searching = false;
    }
  },

  _searchViewMode: 'list',
  _maxSearchCards: 200,

  _renderResults(tracks) {
    const results = document.getElementById('search-results');
    if (!results) return;

    if (tracks.length === 0) {
      results.innerHTML = '<div class="empty-state"><p>Ничего не найдено</p></div>';
      return;
    }

    
    if (tracks.length > this._maxSearchCards && this._searchViewMode === 'cards') {
      this._searchViewMode = 'list';
      InAppModal.confirm({
        title: 'Слишком много треков!', hideCancel: true,
        message: 'Могут быть проблемы с оптимизацией, и в связи с этим вам доступен только компактный режим.',
        confirmText: 'ОК', danger: false, onConfirm: () => {},
      });
    }

    TrackCardComponent.setQueue(tracks, 'search');
    const showLoadMore = tracks.length >= 50 && tracks.length % 50 === 0;

    
    const toggleHtml = `
      <div style="display:flex;justify-content:flex-end;padding:8px 0">
        <div class="collection-view-toggle">
          <button class="view-toggle-btn ${this._searchViewMode === 'cards' ? 'active' : ''}" onclick="SearchPage._setSearchView('cards')" title="Карточки">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
          </button>
          <button class="view-toggle-btn ${this._searchViewMode === 'list' ? 'active' : ''}" onclick="SearchPage._setSearchView('list')" title="Список">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>
          </button>
        </div>
      </div>
    `;

    let contentHtml;
    if (this._searchViewMode === 'cards') {
      contentHtml = '<div class="collection-grid">' + tracks.map(t => '<div class="collection-grid-item">' + TrackCardComponent.card(t, tracks) + '</div>').join('') + '</div>';
    } else {
      contentHtml = '<div style="display:flex;flex-direction:column;gap:2px">' + tracks.map((t, i) => this._searchRow(t, i, tracks)).join('') + '</div>';
    }

    results.innerHTML = toggleHtml + contentHtml + (showLoadMore ? `
      <div style="display:flex;justify-content:center;padding:24px 0">
        <button class="load-more-btn" id="search-load-more" onclick="SearchPage._loadMore()">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="7 13 12 18 17 13"/><polyline points="7 6 12 11 17 6"/></svg>
          Загрузить ещё
        </button>
      </div>
    ` : '');
  },

  _setSearchView(mode) {
    if (mode === 'cards' && this._cachedResults && this._cachedResults.length > this._maxSearchCards) {
      InAppModal.confirm({
        title: 'Слишком много треков!', hideCancel: true,
        message: 'Могут быть проблемы с оптимизацией, и в связи с этим вам доступен только компактный режим.',
        confirmText: 'ОК', danger: false, onConfirm: () => {},
      });
      return;
    }
    this._searchViewMode = mode;
    if (this._cachedResults) this._renderResults(this._cachedResults);
  },

  _loadMoreOffset: 0,
  _allLoadedTracks: [],

  async _loadMore() {
    const btn = document.getElementById('search-load-more');
    if (!btn) return;
    btn.disabled = true;
    btn.innerHTML = '<div class="spinner-inline" style="width:16px;height:16px"></div> Загрузка...';

    this._loadMoreOffset += 50;
    try {
      const data = await API.searchTracks(this._query.trim(), 50, this._loadMoreOffset);
      const newTracks = (data.collection || []).filter(t => t.urn && t.title);

      if (newTracks.length === 0) {
        btn.textContent = 'Больше нет результатов';
        btn.disabled = true;
        return;
      }

      
      this._cachedResults = [...(this._cachedResults || []), ...newTracks];
      this._renderResults(this._cachedResults);
    } catch (e) {
      btn.textContent = 'Ошибка загрузки';
    }
  },

  
  _searchRow(track, index, queue) {
    TrackRegistry.reg(track);
    const art = Utils.art(track.artwork_url, 't200x200');
    const current   = Store.get('currentTrack');
    const isThis    = current?.urn === track.urn;
    const isPlaying = isThis && Store.get('isPlaying');
    const isLiked   = NowPlayingComponent._likedTracks.has(track.urn);
    const urn = Utils.esc(track.urn);
    return `
      <div class="search-track-row ${isThis ? 'active' : ''}" data-urn="${urn}"
           onclick="TrackCardComponent.play('${urn}')"
           oncontextmenu="ContextMenu.showByUrn(event,'${urn}')">
        <div class="search-row-index-wrap">
          <div class="search-row-index">${index + 1}</div>
          <div class="search-row-play">
            ${isPlaying
              ? '<svg width="16" height="16" viewBox="0 0 24 24" fill="white"><path d="M6 4h4v16H6zM14 4h4v16h-4z"/></svg>'
              : '<svg width="16" height="16" viewBox="0 0 24 24" fill="white"><path d="M8 5v14l11-7z"/></svg>'}
          </div>
        </div>
        <div class="search-row-art">
          ${art ? `<img src="${Utils.esc(art)}" alt="" loading="lazy">` : '<div style="width:100%;height:100%;background:rgba(255,255,255,0.04)"></div>'}
        </div>
        <div class="search-row-info">
          <div class="search-row-title">${Utils.esc(track.title)}</div>
          <div class="search-row-artist" onclick="event.stopPropagation(); ArtistPage.openFromUrn('${Utils.esc(track.user?.urn || '')}','${Utils.esc(track.user?.username || '')}')">${Utils.esc(track.user?.username || '')}</div>
        </div>
        <div class="search-row-right">
          ${track.playback_count != null && track.playback_count > 0 ? `<span class="search-row-plays"><svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 18v-6a9 9 0 0 1 18 0v6"/><path d="M21 19a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3zM3 19a2 2 0 0 0 2 2h1a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2H3z"/></svg> ${Utils.fc(track.playback_count)}</span>` : ''}
          ${(track.favoritings_count ?? track.likes_count) > 0 ? `<span class="search-row-plays"><svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg> ${Utils.fc(track.favoritings_count ?? track.likes_count)}</span>` : ''}
          <button class="search-like-btn ${isLiked ? 'active' : ''}"
                  onclick="event.stopPropagation(); SearchPage._toggleLike(this, '${urn}')"
                  title="${isLiked ? 'Убрать из любимых' : 'В любимые'}">
            <svg width="15" height="15" viewBox="0 0 24 24"
                 fill="${isLiked ? 'var(--accent)' : 'none'}"
                 stroke="${isLiked ? 'var(--accent)' : 'currentColor'}" stroke-width="2">
              <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
            </svg>
          </button>
          <span class="search-row-dur">${Utils.dur(track.duration)}</span>
        </div>
      </div>`;
  },

  async _toggleLike(btn, urn) {
    
    if (typeof LocalLikes !== 'undefined' && LocalLikes.hasTrack(urn)) {
      btn.style.transform = 'scale(1.3)';
      setTimeout(() => { btn.style.transform = ''; }, 300);
      const ok = await LocalLikes.tryLikeAndRemove(urn);
      if (ok) {
        NowPlayingComponent._likedTracks.add(urn);
        const svg = btn.querySelector('svg');
        btn.classList.add('active');
        svg.setAttribute('fill', 'var(--accent)');
        svg.setAttribute('stroke', 'var(--accent)');
        const cur = Store.get('currentTrack');
        if (cur && cur.urn === urn) NowPlayingComponent._updateTrackInfo();
      }
      return;
    }

    const isLiked = NowPlayingComponent._likedTracks.has(urn);
    const svg = btn.querySelector('svg');
    
    if (isLiked) {
      NowPlayingComponent._likedTracks.delete(urn);
      btn.classList.remove('active');
      svg.setAttribute('fill', 'none');
      svg.setAttribute('stroke', 'currentColor');
    } else {
      NowPlayingComponent._likedTracks.add(urn);
      btn.classList.add('active');
      svg.setAttribute('fill', 'var(--accent)');
      svg.setAttribute('stroke', 'var(--accent)');
      const track = TrackRegistry.get(urn);
      if (track) NowPlayingComponent._animateLike(track);
    }
    try {
      await LikeQueue.enqueue(urn, isLiked ? 'unlike' : 'like');
    } catch (err) {
      
      if (isLiked) {
        NowPlayingComponent._likedTracks.add(urn);
        btn.classList.add('active');
        svg.setAttribute('fill', 'var(--accent)');
        svg.setAttribute('stroke', 'var(--accent)');
      } else {
        NowPlayingComponent._likedTracks.delete(urn);
        btn.classList.remove('active');
        svg.setAttribute('fill', 'none');
        svg.setAttribute('stroke', 'currentColor');
      }
    }
    const cur = Store.get('currentTrack');
    if (cur && cur.urn === urn) NowPlayingComponent._updateTrackInfo();
  },

  _showEmpty() {
    const results = document.getElementById('search-results');
    if (!results) return;
    const recentSearches = Store.get('recentSearches') || [];
    results.innerHTML = `
      <div class="empty-state">
        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
        <p>Поиск артистов и треков</p>
      </div>
      ${recentSearches.length > 0 ? `
        <div style="max-width:640px;margin:0 auto">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px">
            <div style="font-size:11px;color:rgba(255,255,255,0.3);text-transform:uppercase;letter-spacing:.06em">Недавние</div>
            <button style="font-size:11px;color:rgba(255,255,255,0.35);background:none;border:none;cursor:pointer;padding:4px 8px;border-radius:6px;transition:all .2s"
              onmouseover="this.style.color='rgba(255,255,255,0.7)';this.style.background='rgba(255,255,255,0.06)'"
              onmouseout="this.style.color='rgba(255,255,255,0.35)';this.style.background='none'"
              onclick="SearchPage._clearHistory()">Очистить историю</button>
          </div>
          <div style="display:flex;flex-wrap:wrap;gap:8px">
            ${recentSearches.slice(0, 10).map(q => `
              <button class="genre-pill default" onclick="SearchPage.quickSearch('${Utils.esc(q)}')">${Utils.esc(q)}</button>
            `).join('')}
          </div>
        </div>
      ` : ''}
    `;
  },

  quickSearch(query) {
    this._query = query;
    const input = document.getElementById('search-input');
    if (input) input.value = query;
    document.getElementById('search-clear')?.classList.add('visible');
    this._search();
  },

  _clearHistory() {
    if (typeof InAppModal !== 'undefined') {
      InAppModal.confirm({
        title: 'Очистить историю',
        message: 'Вы уверены, что хотите удалить все недавние запросы?',
        confirmText: 'Очистить',
        danger: true,
        onConfirm: () => {
          Store.set({ recentSearches: [] });
          Utils.toast('История поиска очищена', 2000);
          
          const results = document.getElementById('search-results');
          if (results) {
            const pills = results.querySelectorAll('.genre-pill');
            const header = results.querySelector('[style*="max-width:640px"]');
            if (pills.length > 0) {
              pills.forEach((p, i) => {
                p.style.transition = `opacity 0.25s ease ${i * 0.03}s, transform 0.25s ease ${i * 0.03}s`;
                p.style.opacity = '0';
                p.style.transform = 'scale(0.85) translateY(-4px)';
              });
              
              if (header) {
                header.style.transition = 'opacity 0.3s ease 0.1s';
                header.style.opacity = '0';
              }
              setTimeout(() => this._showEmpty(), 320);
              return;
            }
          }
          this._showEmpty();
        },
      });
    } else {
      if (confirm('Удалить все недавние запросы?')) {
        Store.set({ recentSearches: [] });
        Utils.toast('История поиска очищена', 2000);
        this._showEmpty();
      }
    }
  },

  _userCard(user) {
    const avatar = Utils.art(user.avatar_url, 't300x300');
    return `
      <div class="user-card" onclick="ArtistPage.openFromUrn('${Utils.esc(user.urn || '')}','${Utils.esc(user.username || '')}')">
        <div class="user-card-avatar">
          ${avatar ? `<img src="${Utils.esc(avatar)}" alt="${Utils.esc(user.username)}" loading="lazy">` :
            '<div class="flex-center" style="width:100%;height:100%;background:rgba(255,255,255,0.05)"><svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.2)" stroke-width="1.5"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div>'}
        </div>
        <div class="user-card-name">${Utils.esc(user.username)}</div>
        <div class="user-card-followers">${Utils.fc(user.followers_count)} подписчиков</div>
      </div>`;
  },
};
