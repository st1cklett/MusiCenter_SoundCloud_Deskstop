

function jsLog(level, msg) {
  fetch('/local/log', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ level, message: msg }),
  }).catch(() => {});
}

const LoginPage = {
  _sessionId: null,
  _pollTimer: null,
  _attempts: 0,
  _active: false,

  render() {
    return `
      <div class="login-page">
        <div class="login-card scale-in">
          <div class="login-logo">MusiCenter</div>
          <p class="login-subtitle">Войдите через SoundCloud для начала</p>
          <button class="login-btn" id="login-btn" onclick="LoginPage.handleLogin()">
            Войти через SoundCloud
          </button>
          <div id="login-error" class="login-error" style="display:none"></div>
          <div id="login-waiting" style="display:none;margin-top:16px;text-align:center">
            <p style="font-size:13px;color:rgba(255,255,255,0.5);margin-bottom:12px">
              Авторизуйтесь в браузере, затем нажмите кнопку ниже
            </p>
            <button class="login-btn" id="check-btn" onclick="LoginPage.manualCheck()"
              style="background:rgba(255,255,255,0.08);font-size:13px;padding:10px 24px">
              ✓ Я авторизовался — проверить
            </button>
            <p style="margin-top:12px;font-size:11px;color:rgba(255,255,255,0.2)" id="poll-status">
              Автопроверка каждые 3 секунды...
            </p>
            <p style="margin-top:4px;font-size:11px;color:rgba(255,255,255,0.15)" id="poll-detail"></p>
          </div>
          <p style="margin-top:16px;font-size:11px;color:rgba(255,255,255,0.2)">
            Ваши данные в безопасности
          </p>
        </div>
      </div>
    `;
  },

  _setStatus(msg) {
    const el = document.getElementById('poll-status');
    if (el) el.textContent = msg;
  },

  _setDetail(msg) {
    const el = document.getElementById('poll-detail');
    if (el) el.textContent = msg;
  },

  async handleLogin() {
    const btn = document.getElementById('login-btn');
    const errEl = document.getElementById('login-error');
    btn.disabled = true;
    btn.textContent = 'Подключение...';
    errEl.style.display = 'none';
    jsLog('info', '[AUTH] handleLogin() started');

    try {
      const data = await API.initiateLogin();
      jsLog('info', `[AUTH] /auth/login response keys: ${Object.keys(data).join(', ')}`);
      jsLog('info', `[AUTH] sessionId: ${data.sessionId}`);

      if (data.url && data.sessionId) {
        this._sessionId = data.sessionId;
        this._active = true;
        this._attempts = 0;

        Store.set({ sessionId: data.sessionId });

        
        window.open(data.url, '_blank');
        jsLog('info', `[AUTH] Browser opened with URL`);

        
        btn.style.display = 'none';
        document.getElementById('login-waiting').style.display = 'block';

        
        this._startPoll();
      } else {
        jsLog('error', `[AUTH] Unexpected response: ${JSON.stringify(data)}`);
        errEl.textContent = `Неверный ответ: ${JSON.stringify(data)}`;
        errEl.style.display = 'block';
        btn.disabled = false;
        btn.textContent = 'Войти через SoundCloud';
      }
    } catch (e) {
      jsLog('error', `[AUTH] handleLogin error: ${e.message}`);
      errEl.textContent = `Ошибка: ${e.message}`;
      errEl.style.display = 'block';
      btn.disabled = false;
      btn.textContent = 'Войти через SoundCloud';
    }
  },

  _startPoll() {
    if (this._pollTimer) clearTimeout(this._pollTimer);
    
    this._doPoll();
  },

  async _doPoll() {
    if (!this._active || !this._sessionId) return;

    this._attempts++;
    const sid = this._sessionId;
    jsLog('debug', `[AUTH] Poll #${this._attempts} starting...`);
    this._setStatus(`Автопроверка #${this._attempts}...`);

    
    if (this._attempts > 400) {
      jsLog('warn', '[AUTH] Poll timeout (20 min)');
      this._stopPoll('Таймаут 20 минут. Попробуйте снова.');
      return;
    }

    
    const found = await this._tryAllEndpoints(sid);
    if (found) return; 

    
    this._pollTimer = setTimeout(() => this._doPoll(), 3000);
  },

  async _tryAllEndpoints(sid) {
    
    
    const endpoints = [
      { path: '/api/me',            method: 'GET', header: 'x-session-id' },
      { path: '/api/auth/token',    method: 'GET', header: 'x-session-id' },
      { path: '/api/auth/status',   method: 'GET', header: 'x-session-id' },
      { path: '/api/auth/session',  method: 'GET', header: 'x-session-id' },
      { path: `/api/auth/session/${sid}`, method: 'GET', header: null },
      { path: `/api/auth/token/${sid}`,   method: 'GET', header: null },
      { path: `/api/auth/status/${sid}`,  method: 'GET', header: null },
      { path: '/api/auth/me',       method: 'GET', header: 'x-session-id' },
    ];

    for (const ep of endpoints) {
      try {
        const headers = { 'Content-Type': 'application/json' };
        if (ep.header) headers[ep.header] = sid;

        
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 6000);
        const resp = await fetch(ep.path, { method: ep.method, headers, signal: controller.signal });
        clearTimeout(timer);
        const status = resp.status;

        let body = null;
        try { body = await resp.clone().json(); } catch { body = await resp.text(); }

        jsLog('info', `[AUTH] Poll #${this._attempts} ${ep.path} → ${status}: ${JSON.stringify(body).substring(0, 150)}`);

        if (status === 200 && body) {
          
          const user = this._extractUser(body);
          if (user) {
            jsLog('info', `[AUTH] SUCCESS via ${ep.path}! user=${user.username || user.id}`);
            this._onSuccess(user);
            return true;
          }
        }

        
        if (status !== 401 && ep.path !== '/api/me') {
          jsLog('info', `[AUTH] Endpoint ${ep.path} gave ${status} — logged for analysis`);
        }

      } catch (e) {
        jsLog('debug', `[AUTH] ${ep.path} error: ${e.message}`);
      }
    }

    return false;
  },

  _extractUser(body) {
    
    if (!body || typeof body !== 'object') return null;

    
    if (body.username || (body.id && body.urn)) return body;

    
    if (body.user && (body.user.username || body.user.id)) return body.user;

    
    if (body.accessToken && body.user) return body.user;

    
    if (body.session && body.user) return body.user;

    return null;
  },

  _onSuccess(user) {
    this._active = false;
    if (this._pollTimer) clearTimeout(this._pollTimer);
    this._setStatus('✓ Авторизация успешна!');
    Store.set({ user, isAuthenticated: true });
    jsLog('info', `[AUTH] Auth complete, user: ${JSON.stringify(user).substring(0, 100)}`);
  },

  _stopPoll(msg) {
    this._active = false;
    if (this._pollTimer) clearTimeout(this._pollTimer);
    this._setStatus(msg || 'Остановлено');

    
    const checkBtn = document.getElementById('check-btn');
    if (checkBtn) {
      checkBtn.textContent = '↺ Попробовать снова';
      checkBtn.onclick = () => {
        
        this._active = false;
        document.getElementById('login-waiting').style.display = 'none';
        const btn = document.getElementById('login-btn');
        if (btn) { btn.style.display = ''; btn.disabled = false; btn.textContent = 'Войти через SoundCloud'; }
      };
    }
  },

  
  async manualCheck() {
    if (!this._sessionId) return;
    jsLog('info', '[AUTH] Manual check triggered by user');
    this._setStatus('Проверяю авторизацию...');

    
    if (this._pollTimer) clearTimeout(this._pollTimer);
    await this._doPoll();
  },
};
