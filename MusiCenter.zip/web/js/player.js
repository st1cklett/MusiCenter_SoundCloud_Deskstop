

const Player = {
  
  _audio:       null,   
  _ctx:         null,   
  _sourceNode:  null,   
  _masterGain:  null,   

  
  _currentUrn:  null,
  _listeners:   new Set(),
  _loadGen:     0,
  _loading:     false,
  _audioLoaded: false,  
  _restorePending: null,
  _preloadTriggered: false,

  
  _rustReady: false,

  
  async init() {
    Utils.log('info', '[Player] Инициализация Web Audio API...');

    
    this._audio = new Audio();
    this._audio.preload     = 'none';
    this._audio.crossOrigin = 'anonymous'; 

    
    this._audio.addEventListener('canplay', () => {
      if (!this._audioLoaded) {
        this._audioLoaded = true;
        this._loading     = false;
        this._notifyLoading(false);
        this._notify();
        if (typeof NowPlayingComponent !== 'undefined') NowPlayingComponent._updatePlayButton();
        if (typeof Utils._refreshPlayingCards === 'function') Utils._refreshPlayingCards();
        if (typeof LyricsComponent       !== 'undefined') LyricsComponent._onTrackReady();
        if (typeof SessionCache          !== 'undefined') {
          const t = Store.get('currentTrack');
          if (t) SessionCache.preloadComments(t.urn);
        }
        Utils.log('info', '[Player] canplay — трек готов');
      }
    });

    this._audio.addEventListener('timeupdate', () => {
      this._notify();
      this._checkNearEnd();
    });

    this._audio.addEventListener('playing', () => {
      EqualizerEngine.ensureRunning();
      if (this._loading) { this._loading = false; this._notifyLoading(false); }
      this._notify();
    });

    this._audio.addEventListener('pause',   () => this._notify());
    this._audio.addEventListener('ended',   () => this._handleEnd());

    this._audio.addEventListener('error', () => {
      const msg = this._audio.error?.message || 'unknown error';
      Utils.log('error', '[Player] Audio error: ' + msg);
      this._loading     = false;
      this._audioLoaded = false;
      this._notifyLoading(false);
    });

    this._audio.addEventListener('waiting', () => {
      if (this._audioLoaded && !this._loading) {
        this._loading = true;
        this._notifyLoading(true);
      }
    });

    
    this._initListeners();
    this._setupMediaSession();

    const restoredTrack = Store.get('currentTrack');
    if (restoredTrack) this._restoreSession(restoredTrack);

    
    setInterval(() => {
      const pos = this.getCurrentTime();
      if (pos > 0) Store.set({ lastTrackTime: pos });
    }, 3000);

    Utils.log('info', '[Player] Web Audio API: АКТИВЕН (streaming, no Rust, no IPC polling)');
  },

  
  _initWebAudio() {
    if (this._ctx) return;
    try {
      this._ctx = new (window.AudioContext || window.webkitAudioContext)();

      
      this._sourceNode = this._ctx.createMediaElementSource(this._audio);

      
      this._masterGain = this._ctx.createGain();
      const vol = Store.get('volume') || 100;
      this._masterGain.gain.value = Math.min(2.0, vol / 100);

      
      EqualizerEngine.attachChain(this._sourceNode, this._masterGain, this._ctx);
      this._masterGain.connect(this._ctx.destination);

      
      if (typeof AudioAnalyser !== 'undefined') {
        AudioAnalyser.init(this._ctx, this._masterGain);
      }

      Utils.log('info', `[Player] AudioContext: ${this._ctx.sampleRate}Hz, EQ подключён`);
    } catch (e) {
      Utils.log('error', '[Player] AudioContext init failed: ' + e.message);
    }
  },

  _ensureWebAudio() {
    if (!this._ctx) this._initWebAudio();
    if (this._ctx?.state === 'suspended') this._ctx.resume().catch(() => {});
  },

  
  _initListeners() {
    Store.on('currentTrack', (track) => {
      if (track && track.urn !== this._currentUrn) this._loadTrack(track);
      else if (!track) this._stop();
    });

    Store.on('isPlaying', (playing) => {
      if (playing) {
        if (this._restorePending) {
          const cur = Store.get('currentTrack');
          if (cur?.urn === this._restorePending.track.urn) {
            const { track, savedTime } = this._restorePending;
            this._restorePending = null;
            Utils.log('info', `[Player] Загружаем отложенный трек: ${track.title}`);
            this._doRestoreLoad(track, savedTime);
            return;
          }
          this._restorePending = null;
        }

        if (this._audio.src && this._currentUrn) {
          this._ensureWebAudio();
          
          if (this._audioLoaded) {
            this._audio.play().catch(e => Utils.log('error', '[Player] play() error: ' + e.message));
          } else if (!this._loading) {
            
            const track = Store.get('currentTrack');
            if (track?.urn === this._currentUrn) this._loadTrack(track);
          }
          
        } else if (this._currentUrn && !this._loading) {
          const track = Store.get('currentTrack');
          if (track?.urn === this._currentUrn) this._loadTrack(track);
        }
      } else {
        this._audio.pause();
      }
      this._updateMediaSession(playing);
    });

    Store.on('volume', (vol) => this._applyVolume(vol));

    const vol = Store.get('volume');
    if (vol != null) this._applyVolume(vol);
  },

  _applyVolume(vol) {
    
    const raw = vol != null ? vol : 100;
    const clamped = Math.max(0, Math.min(200, raw));
    
    
    let normalized;
    if (clamped <= 100) {
      normalized = Math.pow(clamped / 100, 2.5); 
    } else {
      normalized = 1.0 + (clamped - 100) / 100; 
    }
    if (this._masterGain) {
      this._audio.volume = 1.0;
      this._masterGain.gain.value = normalized;
    } else {
      this._audio.volume = Math.min(1.0, normalized);
    }
  },

  
  _loadTrack(track) {
    if (!track) return;
    const gen = ++this._loadGen;

    this._restorePending = null;

    this._audio.pause();
    this._audio.removeAttribute('src');
    this._audio.load();

    this._currentUrn       = track.urn;
    this._loading          = true;
    this._audioLoaded      = false;
    this._preloadTriggered = false;
    this._notifyLoading(true);
    this._notify();
    this._updateMediaMetadata(track);

    Utils.log('info', `[Player] Загружаем: ${track.title} (${track.urn})`);

    
    if (typeof AudioAnalyser !== 'undefined') {
      AudioAnalyser.onTrackStart(track.urn);
    }
    
    const streamUrl = API.streamUrl(track.urn);
    this._audio.src = streamUrl;
    this._audio.load();

    this._ensureWebAudio();

    if (gen !== this._loadGen) return;

    
    if (Store.get('isPlaying')) {
      
      const playOnReady = () => {
        this._audio.removeEventListener('canplay', playOnReady);
        if (gen !== this._loadGen) return; 
        if (Store.get('isPlaying')) {
          this._audio.play().catch(e => {
            if (gen === this._loadGen) Utils.log('error', '[Player] play() failed: ' + e.message);
          });
        }
      };
      this._audio.addEventListener('canplay', playOnReady);
    }
  },

  _stop() {
    this._audio.pause();
    this._audio.removeAttribute('src');
    this._audio.load();
    this._currentUrn  = null;
    this._loading     = false;
    this._audioLoaded = false;
    this._notify();
    Utils.log('info', '[Player] Остановлен');
  },

  
  async _restoreSession(track) {
    this._currentUrn = track.urn;
    this._updateMediaMetadata(track);
    Utils.log('info', `[Player] Восстановление: ${track.title}`);

    const savedTime = Store.get('lastTrackTime') || 0;
    if (savedTime > 5) this._notify();

    if (Store.get('isPlaying')) {
      this._doRestoreLoad(track, savedTime);
    } else {
      this._restorePending = { track, savedTime };
      Utils.log('info', '[Player] Восстановление отложено — загрузим при Play');
    }
  },

  _doRestoreLoad(track, seekTo) {
    const streamUrl = API.streamUrl(track.urn);
    this._audio.src = streamUrl;
    this._audio.load();
    this._loading     = true;
    this._audioLoaded = false;
    this._notifyLoading(true);
    this._ensureWebAudio();

    if (typeof SessionCache !== 'undefined') SessionCache.preloadComments(track.urn);
    if (typeof CommentsComponent !== 'undefined') {
      CommentsComponent._currentTrackUrn = track.urn;
      CommentsComponent._trackTitle = track.title;
    }

    if (seekTo > 2) {
      const onCanPlay = () => {
        this._audio.removeEventListener('canplay', onCanPlay);
        this._audio.currentTime = seekTo;
        Utils.log('info', `[Player] Позиция восстановлена: ${seekTo.toFixed(1)}s`);
      };
      this._audio.addEventListener('canplay', onCanPlay);
    }
  },

  
  getCurrentTime() {
    if (!this._audio?.src && this._restorePending) {
      return Store.get('lastTrackTime') || 0;
    }
    return this._audio?.currentTime || 0;
  },

  getDuration() {
    
    
    const t = Store.get('currentTrack');
    const metaDur = t?.duration ? t.duration / 1000 : 0;
    const audioDur = this._audio?.duration;

    if (metaDur > 0) {
      
      if (!audioDur || !isFinite(audioDur) || audioDur < metaDur * 0.9) {
        return metaDur;
      }
    }
    
    if (audioDur && isFinite(audioDur)) return audioDur;
    return metaDur || 0;
  },

  isPlaying() {
    return !!(this._audio && !this._audio.paused && !this._audio.ended && this._audio.src);
  },

  seek(timeSec) {
    if (!this._audio?.src) {
      Utils.log('warning', `[Player] Seek(${timeSec.toFixed(1)}s) failed: no audio src`);
      return;
    }
    if (!this._audioLoaded) {
      Utils.log('warning', `[Player] Seek(${timeSec.toFixed(1)}s) failed: audio not loaded yet`);
      return;
    }
    try {
      this._audio.currentTime = timeSec;
      this._notify();
    } catch (e) {
      Utils.log('warning', `[Player] Seek(${timeSec.toFixed(1)}s) error: ${e.message}`);
    }
  },

  handlePrev() {
    if (this.getCurrentTime() > 3) this.seek(0);
    else Store.prev();
  },

  subscribe(fn)  { this._listeners.add(fn); return () => this._listeners.delete(fn); },
  _notify()      { for (const fn of this._listeners) try { fn(); } catch (_) {} },

  _notifyLoading(isLoading) {
    this._loading = isLoading;
    document.dispatchEvent(new CustomEvent('mc:loading', { detail: { loading: isLoading } }));
  },

  
  _checkNearEnd() {
    const dur = this.getDuration(), cur = this.getCurrentTime();
    if (!dur || dur < 10) return;
    const remaining = dur - cur;

    if (remaining < 20 && !this._preloadTriggered) {
      this._preloadTriggered = true;
      this._preloadNext();
    }
    if (remaining < 30 && typeof SoundWave !== 'undefined' && SoundWave.isActive()) {
      SoundWave.onTrackNearEnd();
    }
    if (typeof CrossfadeEngine !== 'undefined' && CrossfadeEngine._enabled && remaining < CrossfadeEngine._duration) {
      CrossfadeEngine.startCrossfade();
    }
  },

  _preloadNext() {
    const { queue, queueIndex } = Store._state;
    const nextIdx = queueIndex + 1;
    if (nextIdx >= queue.length) return;
    const nextTrack = queue[nextIdx];
    if (!nextTrack) return;
    if (typeof SessionCache !== 'undefined') SessionCache.preloadComments(nextTrack.urn);
    if (nextTrack.user?.urn && typeof SessionCache !== 'undefined') SessionCache.preloadArtist?.(nextTrack.user.urn);
  },

  
  _handleEnd() {
    if (typeof CrossfadeEngine !== 'undefined' && CrossfadeEngine._crossfading) return;
    Utils.log('info', '[Player] Трек завершён');
    const repeat = Store.get('repeat');
    if (repeat === 'one') {
      this.seek(0);
      this._audio.play().catch(() => {});
    } else {
      const { queue, queueIndex, shuffle } = Store._state;
      const isLast = !shuffle && queueIndex >= queue.length - 1;
      if (isLast && repeat === 'off') this._autoplayRelated();
      else Store.next();
    }
  },

  async _autoplayRelated() {
    if (typeof SoundWave !== 'undefined' && SoundWave.isActive()) {
      Utils.log('info', '[Player] Queue end — SoundWave active');
      await SoundWave._generateBatch();
      const { queue, queueIndex } = Store._state;
      if (queueIndex < queue.length - 1) Store.next();
      else Store.pause();
      return;
    }
    const track = Store.get('currentTrack');
    if (!track) return;
    try {
      const res = await API.getRelatedTracks(track.urn, 20);
      const existing = new Set(Store.get('queue').map(t => t.urn));
      const fresh = (res.collection || []).filter(t => !existing.has(t.urn));
      if (fresh.length > 0) { Store.addToQueue(fresh); Store.next(); }
      else Store.pause();
    } catch { Store.pause(); }
  },

  
  _setupMediaSession() {
    if (!('mediaSession' in navigator)) return;
    const ms = navigator.mediaSession;
    ms.setActionHandler('play',          () => Store.resume());
    ms.setActionHandler('pause',         () => Store.pause());
    ms.setActionHandler('nexttrack',     () => Store.next());
    ms.setActionHandler('previoustrack', () => this.handlePrev());
    ms.setActionHandler('seekto',        (d) => { if (d.seekTime != null) this.seek(d.seekTime); });
  },

  _updateMediaMetadata(track) {
    if (!('mediaSession' in navigator)) return;
    const art500 = Utils.art(track.artwork_url, 't500x500');
    const art128 = Utils.art(track.artwork_url, 't120x120');
    navigator.mediaSession.metadata = new MediaMetadata({
      title: track.title, artist: track.user.username,
      artwork: [
        ...(art128 ? [{ src: art128, sizes: '120x120', type: 'image/jpeg' }] : []),
        ...(art500 ? [{ src: art500, sizes: '500x500', type: 'image/jpeg' }] : []),
      ],
    });
  },

  _updateMediaSession(playing) {
    if (!('mediaSession' in navigator)) return;
    navigator.mediaSession.playbackState = playing ? 'playing' : 'paused';
  },

  
  _onRustReady()    {  },
  _onRustError(msg) { Utils.log('warning', '[Player] _onRustError (no-op): ' + msg); },
};
