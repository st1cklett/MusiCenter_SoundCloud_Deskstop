

const SidebarComponent = {
  init() {
    this._updateActiveNav();
    this._renderUser();
    this._renderPlaylistList();

    Store.on('user', () => this._renderUser());
    Store.on('currentPage', () => this._updateActiveNav());
    Store.on('playlists', () => this._renderPlaylistList());

    document.querySelectorAll('.nav-item').forEach(item => {
      item.addEventListener('click', (e) => {
        e.preventDefault();
        App.navigate(item.dataset.page);
      });
    });
  },

  _updateActiveNav() {
    const page = Store.get('currentPage');
    document.querySelectorAll('.nav-item').forEach(item => {
      item.classList.toggle('active', item.dataset.page === page);
    });
  },

  
  _renderPlaylistList() {
    
    let container = document.getElementById('sidebar-playlists');
    if (!container) {
      
      const navLinks = document.getElementById('nav-links');
      if (!navLinks) return;
      container = document.createElement('div');
      container.id = 'sidebar-playlists';
      container.className = 'sidebar-playlist-list';
      
      const playlistsNav = navLinks.querySelector('[data-page="playlists"]');
      if (playlistsNav && playlistsNav.nextElementSibling) {
        navLinks.insertBefore(container, playlistsNav.nextElementSibling);
      } else if (playlistsNav) {
        navLinks.appendChild(container);
      } else {
        return;
      }
    }

    const playlists = (Store.get('playlists') || []).filter(pl => !pl.isLocalLikes);
    if (playlists.length === 0) {
      container.innerHTML = '';
      return;
    }

    container.innerHTML = playlists.map(pl => {
      const isYm = pl.isYandex === true || pl.title === 'Яндекс Музыка';
      let coverHtml;
      if (isYm) {
        coverHtml = '<div class="sb-pl-cover sb-pl-ym"><svg width="14" height="14" viewBox="0 0 1000 1000" fill="none"><path fill="#FED42B" d="M990.5,381.2l-3.9-19.4l-164.9-28.8l95.8-129.6l-11.1-12.2l-141,67.6l17.8-179.5l-14.5-8.3L683,216.1L586.6,0h-16.7l22.8,208.9L350.4,15l-20.6,6.1l186.6,234.3L147.1,132.4l-16.7,18.8l329.8,187.8L5,376.7L0,405l473,51.5L78.5,782.8l16.7,22.7l469.6-255.4l-93,449.9h28.4l179.9-423.3l109.7,331.3l19.5-15l-45.1-336.8l171,193.9l11.1-17.7L815.6,492l182.7,67.6L1000,539.1l-163.8-120.8l154.3-37.1L990.5,381.2z"/></svg></div>';
      } else {
        const tracks = pl.tracks || [];
        const artUrl = pl.coverUrl || (tracks.length > 0 ? (Utils.art ? Utils.art(tracks[0].artwork_url, 't120x120') : '') : '');
        if (artUrl) {
          coverHtml = '<img class="sb-pl-cover" src="' + Utils.esc(artUrl) + '" alt="" onerror="this.style.display=\'none\'">';
        } else {
          coverHtml = '<div class="sb-pl-cover sb-pl-empty"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.25)" stroke-width="1.5"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg></div>';
        }
      }
      return '<a href="#" class="sb-pl-item" data-plid="' + Utils.esc(pl.id) + '" onclick="event.preventDefault(); PlaylistsPage._pendingOpenId=\'' + Utils.esc(pl.id) + '\'; App.navigate(\'playlists\')">' +
        coverHtml +
        '<span class="sb-pl-name">' + Utils.esc(pl.title) + '</span>' +
        '<span class="sb-pl-count">' + (pl.tracks || []).length + '</span>' +
      '</a>';
    }).join('');
  },

  _renderUser() {
    const user = Store.get('user');
    const el = document.getElementById('sidebar-user');
    if (!user) { el.innerHTML = ''; return; }
    const avatar = Utils.art(user.avatar_url, 'small') || '';
    el.innerHTML = `
      <div class="sidebar-settings-btn" onclick="SettingsComponent.toggle()" title="Настройки">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/>
        </svg>
      </div>
      <div class="sidebar-user-link" oncontextmenu="SidebarComponent._showUserMenu(event)" title="ПКМ — меню">
        <img class="sidebar-avatar" src="${Utils.esc(avatar)}" alt="" onerror="this.style.display='none'">
        <span class="sidebar-username">${Utils.esc(user.username)}</span>
      </div>
    `;
  },

  _showUserMenu(e) {
    e.preventDefault();
    e.stopPropagation();
    
    document.querySelectorAll('.user-ctx-menu').forEach(m => m.remove());

    const menu = document.createElement('div');
    menu.className = 'user-ctx-menu ctx-menu';

    menu.innerHTML = `
      <div class="ctx-item ctx-danger ctx-logout-item" id="ctx-logout-btn">
        <svg width="14" height="14" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" fill="#ff3b30">
          <path d="M12.207 9H5V7h7.136L11.05 5.914 12.464 4.5 16 8.036l-3.536 3.535-1.414-1.414L12.207 9zM10 4H8V2H2v12h6v-2h2v4H0V0h10v4z" fill-rule="evenodd"/>
        </svg>
        <span style="color:#ff3b30;font-weight:600">Выход</span>
      </div>
    `;

    
    const menuW = 180, menuH = 50;
    let x = e.clientX, y = e.clientY;
    if (x + menuW > window.innerWidth) x = window.innerWidth - menuW - 8;
    if (y + menuH > window.innerHeight) y = y - menuH - 8;
    menu.style.cssText = `left:${x}px;top:${y}px;min-width:${menuW}px`;
    document.body.appendChild(menu);
    requestAnimationFrame(() => menu.classList.add('open'));

    menu.querySelector('#ctx-logout-btn').addEventListener('click', () => {
      menu.remove();
      SidebarComponent._logout();
    });

    setTimeout(() => document.addEventListener('click', () => menu.remove(), { once: true }), 10);
  },

  _logout() {
    
    if (typeof InAppModal !== 'undefined') {
      InAppModal.confirm({
        title: 'Выход из аккаунта',
        message: 'Вы уверены, что хотите выйти из аккаунта SoundCloud?',
        confirmText: 'Выйти',
        danger: true,
        onConfirm: () => SidebarComponent._doLogout(),
      });
    } else {
      if (confirm('Выйти из аккаунта SoundCloud?')) SidebarComponent._doLogout();
    }
  },

  _doLogout() {
    
    if (typeof Store !== 'undefined') {
      Store.pause();
      Store.logout();
    }
    Utils.log('info', '[Sidebar] User logged out');
  },
};
