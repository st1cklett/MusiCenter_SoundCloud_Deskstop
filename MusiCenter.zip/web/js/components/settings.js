

const Themes = {
  soundcloud: {
    name: 'SoundCloud',
    accent: '#ff5500',
    accentHover: '#ff6a1a',
    accentGlow: 'rgba(255, 85, 0, 0.2)',
    accentSoft: 'rgba(255, 85, 0, 0.06)',
    accentContrast: '#ffffff',
    bgPrimary: '#08080a',
    bgTitlebar: 'rgba(12, 12, 14, 0.95)',
    selectionBg: 'rgba(255, 85, 0, 0.3)',
    greetingGrad: 'linear-gradient(to right, white, rgba(255,255,255,0.8), rgba(255,85,0,0.8))',
    heroLikes: 'linear-gradient(135deg, rgba(139,92,246,0.2), rgba(217,70,239,0.1), rgba(255,85,0,0.2))',
    heroFollow: 'linear-gradient(225deg, rgba(59,130,246,0.1), rgba(6,182,212,0.1), rgba(16,185,129,0.1))',
    loginGrad: 'linear-gradient(135deg, white, #ff5500)',
    preview: ['#ff5500', '#08080a', '#1a1a1e'],
    waveBars: 'rgba(255, 85, 0, 0.3)',
  },
  dark: {
    name: 'Тьма',
    accent: '#ffffff',
    accentHover: '#e0e0e0',
    accentGlow: 'rgba(255, 255, 255, 0.15)',
    accentSoft: 'rgba(255, 255, 255, 0.04)',
    accentContrast: '#000000',
    bgPrimary: '#000000',
    bgTitlebar: 'rgba(0, 0, 0, 0.95)',
    selectionBg: 'rgba(255, 255, 255, 0.25)',
    greetingGrad: 'linear-gradient(to right, white, rgba(255,255,255,0.6))',
    heroLikes: 'linear-gradient(135deg, rgba(255,255,255,0.06), rgba(255,255,255,0.03))',
    heroFollow: 'linear-gradient(225deg, rgba(255,255,255,0.04), rgba(255,255,255,0.02))',
    loginGrad: 'linear-gradient(135deg, #888, white)',
    preview: ['#ffffff', '#000000', '#111111'],
    waveBars: 'rgba(255, 255, 255, 0.35)',
  },
  neon: {
    name: 'Неон',
    accent: '#bf5af2',
    accentHover: '#d17ff5',
    accentGlow: 'rgba(191, 90, 242, 0.25)',
    accentSoft: 'rgba(191, 90, 242, 0.07)',
    accentContrast: '#ffffff',
    bgPrimary: '#08060f',
    bgTitlebar: 'rgba(10, 8, 20, 0.95)',
    selectionBg: 'rgba(191, 90, 242, 0.3)',
    greetingGrad: 'linear-gradient(to right, white, rgba(255,255,255,0.8), rgba(191,90,242,0.9))',
    heroLikes: 'linear-gradient(135deg, rgba(191,90,242,0.18), rgba(139,92,246,0.12), rgba(236,72,153,0.1))',
    heroFollow: 'linear-gradient(225deg, rgba(124,58,237,0.14), rgba(168,85,247,0.1), rgba(192,132,252,0.07))',
    loginGrad: 'linear-gradient(135deg, white, #bf5af2)',
    preview: ['#bf5af2', '#08060f', '#18102a'],
    waveBars: 'rgba(191, 90, 242, 0.35)',
  },
  forest: {
    name: 'Лес',
    accent: '#22c55e',
    accentHover: '#4ade80',
    accentGlow: 'rgba(34, 197, 94, 0.22)',
    accentSoft: 'rgba(34, 197, 94, 0.07)',
    accentContrast: '#ffffff',
    bgPrimary: '#050e08',
    bgTitlebar: 'rgba(6, 16, 10, 0.95)',
    selectionBg: 'rgba(34, 197, 94, 0.3)',
    greetingGrad: 'linear-gradient(to right, white, rgba(255,255,255,0.8), rgba(34,197,94,0.9))',
    heroLikes: 'linear-gradient(135deg, rgba(34,197,94,0.18), rgba(16,185,129,0.12), rgba(74,222,128,0.1))',
    heroFollow: 'linear-gradient(225deg, rgba(6,95,70,0.15), rgba(16,185,129,0.1), rgba(52,211,153,0.08))',
    loginGrad: 'linear-gradient(135deg, white, #22c55e)',
    preview: ['#22c55e', '#050e08', '#0a1f10'],
    waveBars: 'rgba(34, 197, 94, 0.35)',
  },
  crimson: {
    name: 'Кармин',
    accent: '#ff2d55',
    accentHover: '#ff4d6f',
    accentGlow: 'rgba(255, 45, 85, 0.22)',
    accentSoft: 'rgba(255, 45, 85, 0.07)',
    accentContrast: '#ffffff',
    bgPrimary: '#0c0507',
    bgTitlebar: 'rgba(16, 6, 10, 0.95)',
    selectionBg: 'rgba(255, 45, 85, 0.3)',
    greetingGrad: 'linear-gradient(to right, white, rgba(255,255,255,0.8), rgba(255,45,85,0.9))',
    heroLikes: 'linear-gradient(135deg, rgba(255,45,85,0.18), rgba(220,38,38,0.12), rgba(251,113,133,0.1))',
    heroFollow: 'linear-gradient(225deg, rgba(190,18,60,0.14), rgba(225,29,72,0.1), rgba(251,113,133,0.07))',
    loginGrad: 'linear-gradient(135deg, white, #ff2d55)',
    preview: ['#ff2d55', '#0c0507', '#1e0a10'],
    waveBars: 'rgba(255, 45, 85, 0.35)',
  },
};


function _hexToRgb(hex) {
  const r = parseInt(hex.slice(1,3),16), g = parseInt(hex.slice(3,5),16), b = parseInt(hex.slice(5,7),16);
  return {r,g,b};
}
function _buildCustomTheme(c) {
  const accent = c.accent || '#6366f1';
  const bg     = c.bgPrimary || '#0a0a0c';
  const {r,g,b} = _hexToRgb(accent);
  
  const hover = `rgba(${Math.min(r+30,255)},${Math.min(g+30,255)},${Math.min(b+30,255)},1)`;
  const lum   = (0.299*r + 0.587*g + 0.114*b);
  const contrast = lum > 140 ? '#000000' : '#ffffff';
  return {
    name: 'Custom',
    accent: accent,
    accentHover: hover,
    accentGlow: `rgba(${r},${g},${b},0.22)`,
    accentSoft: `rgba(${r},${g},${b},0.07)`,
    accentContrast: contrast,
    bgPrimary: bg,
    bgTitlebar: (bg && bg.length >= 7) ? `rgba(${parseInt(bg.slice(1,3),16)},${parseInt(bg.slice(3,5),16)},${parseInt(bg.slice(5,7),16)},0.95)` : 'rgba(10,10,12,0.95)',
    selectionBg: `rgba(${r},${g},${b},0.3)`,
    greetingGrad: `linear-gradient(to right, white, rgba(255,255,255,0.8), rgba(${r},${g},${b},0.9))`,
    heroLikes: `linear-gradient(135deg, rgba(${r},${g},${b},0.18), rgba(${r},${g},${b},0.08))`,
    heroFollow: `linear-gradient(225deg, rgba(${r},${g},${b},0.1), rgba(${r},${g},${b},0.05))`,
    loginGrad: `linear-gradient(135deg, white, ${accent})`,
    preview: [accent, bg, `#${Math.min(parseInt(bg.slice(1,3),16)+16,255).toString(16).padStart(2,'0')}${Math.min(parseInt(bg.slice(3,5),16)+16,255).toString(16).padStart(2,'0')}${Math.min(parseInt(bg.slice(5,7),16)+16,255).toString(16).padStart(2,'0')}`],
    waveBars: c.waveBars || `rgba(${r},${g},${b},0.35)`,
    _custom: true,
  };
}

function _getCustomColors() {
  const settings = Store.get('settings') || {};
  return settings.customTheme || { accent: '#6366f1', bgPrimary: '#0a0a0c', waveBars: '' };
}


(function() {
  const c = _getCustomColors();
  Themes.custom = _buildCustomTheme(c);
})();

const SettingsComponent = {
  _open: false,
  _el: null,
  _initialized: false,   

  init() {
    
    const saved = Store.get('settings') || {};
    if (!saved.theme) saved.theme = 'soundcloud';
    if (saved.crossfade == null) saved.crossfade = false;
    if (saved.crossfadeDuration == null) saved.crossfadeDuration = 6;
    if (saved.commentsEnabled == null) saved.commentsEnabled = true;
    if (saved.bypassEnabled == null) saved.bypassEnabled = false;
    if (saved.bypassMethod == null) saved.bypassMethod = null;
    if (saved.backgroundMode == null) saved.backgroundMode = false;
    if (saved.bgImageUrl == null) saved.bgImageUrl = '';
    if (saved.bgOpacity == null)  saved.bgOpacity  = 0.15;
    Store.set({ settings: saved });
    
    if (saved.bgImageUrl) SettingsComponent._applyBackground(saved.bgImageUrl, saved.bgOpacity);

    
    if (!this._initialized && saved.backgroundMode) {
      const api = window.pywebview?.api;
      
      if (api) setTimeout(() => api.set_background_mode(true), 300);
    }
    this._initialized = true;

    
    if (saved.customTheme) {
      Themes.custom = _buildCustomTheme(saved.customTheme);
    }
    this.applyTheme(saved.theme, false);

    
    CommentsComponent._enabled = saved.commentsEnabled;

    
    if (saved.bypassEnabled) {
      Utils._imgProxyEnabled = true;
      
      setTimeout(() => {
        if (typeof BypassEngine !== 'undefined') BypassEngine.restoreFromSettings(saved);
      }, 0);
    }
  },

  applyTheme(themeId, animate = true) {
    const theme = Themes[themeId];
    if (!theme) return;

    const root = document.documentElement;

    if (animate) {
      
      root.style.setProperty('--theme-transition', 'background-color 0.5s ease, color 0.3s ease, border-color 0.4s ease, box-shadow 0.4s ease');
      document.body.classList.add('theme-transitioning');
      setTimeout(() => {
        document.body.classList.remove('theme-transitioning');
      }, 600);
    }

    root.style.setProperty('--accent', theme.accent);
    root.style.setProperty('--accent-hover', theme.accentHover);
    root.style.setProperty('--accent-glow', theme.accentGlow);
    root.style.setProperty('--accent-soft', theme.accentSoft);
    root.style.setProperty('--accent-contrast', theme.accentContrast);
    root.style.setProperty('--bg-primary', theme.bgPrimary);

    
    document.body.style.background = theme.bgPrimary;
    const titlebar = document.getElementById('titlebar');
    if (titlebar) titlebar.style.background = theme.bgTitlebar;
    const loadingOv = document.getElementById('loading-overlay');
    if (loadingOv) loadingOv.style.background = theme.bgPrimary;

    
    const greeting = document.querySelector('.greeting h1');
    if (greeting) greeting.style.backgroundImage = theme.greetingGrad;

    
    root.style.setProperty('--hero-likes-bg', theme.heroLikes);
    root.style.setProperty('--hero-follow-bg', theme.heroFollow);

    
    root.style.setProperty('--selection-bg', theme.selectionBg);

    
    root.style.setProperty('--wave-bar-color', theme.waveBars || 'rgba(255,255,255,0.2)');

    
    const settings = Store.get('settings') || {};
    settings.theme = themeId;
    Store.set({ settings });

    
    if (typeof SoundWave !== 'undefined') {
      
      setTimeout(() => SoundWave.onThemeChange(), animate ? 50 : 0);
    }
  },

  toggle() {
    if (this._open) this.close();
    else this.open();
  },

  open() {
    if (this._open) return;
    this._open = true;

    const settings = Store.get('settings') || {};

    
    if (settings.customTheme) {
      Themes.custom = _buildCustomTheme(settings.customTheme);
    }

    let el = document.getElementById('settings-panel');
    if (!el) {
      el = document.createElement('div');
      el.id = 'settings-panel';
      document.body.appendChild(el);
    }
    this._el = el;

    el.innerHTML = `
      <div class="settings-backdrop" onclick="SettingsComponent.close()"></div>
      <div class="settings-card">
        <div class="settings-header">
          <h3>Настройки</h3>
          <button class="settings-close-btn" onclick="SettingsComponent.close()">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>
          </button>
        </div>
        <div class="settings-body">

          <!-- Themes -->
          <div class="settings-section">
            <div class="settings-section-title">Тема</div>
            <div class="settings-themes-grid">
              ${Object.entries(Themes).map(([id, t]) => `
                <div class="settings-theme-item ${settings.theme === id ? 'active' : ''}" data-theme="${id}" onclick="SettingsComponent._selectTheme('${id}')" oncontextmenu="SettingsComponent._themeContextMenu(event,'${id}')">
                  <div class="settings-theme-preview">
                    <div class="stp-bg" style="background:${t.preview[1]}"></div>
                    <div class="stp-accent" style="background:${t.preview[0]}"></div>
                    <div class="stp-card" style="background:${t.preview[2]}"></div>
                  </div>
                  <div class="settings-theme-name">${t.name}</div>
                </div>
              `).join('')}
            </div>
          </div>

          <!-- Crossfade -->
          <div class="settings-section">
            <div class="settings-section-title">Кроссфейд</div>
            <div class="settings-row">
              <span class="settings-label">Плавный переход</span>
              <label class="settings-toggle">
                <input type="checkbox" id="settings-crossfade" ${settings.crossfade ? 'checked' : ''} onchange="SettingsComponent._toggleCrossfade(this.checked)">
                <span class="settings-toggle-track"><span class="settings-toggle-thumb"></span></span>
              </label>
            </div>
            <div class="settings-row crossfade-duration-row ${settings.crossfade ? '' : 'disabled'}" id="crossfade-dur-row">
              <span class="settings-label">Длительность: <strong id="crossfade-dur-val">${settings.crossfadeDuration}с</strong></span>
              <input type="range" id="settings-crossfade-dur" class="settings-slider" min="2" max="12" step="1" value="${settings.crossfadeDuration}"
                     oninput="SettingsComponent._setCrossfadeDuration(this.value)">
            </div>
            <div class="settings-hint">Предзагружает следующий трек и плавно микширует</div>
          </div>

          <!-- Comments -->
          <div class="settings-section">
            <div class="settings-section-title">Комментарии</div>
            <div class="settings-row">
              <span class="settings-label">Показывать тайм-комментарии</span>
              <label class="settings-toggle">
                <input type="checkbox" id="settings-comments" ${settings.commentsEnabled ? 'checked' : ''} onchange="SettingsComponent._toggleComments(this.checked)">
                <span class="settings-toggle-track"><span class="settings-toggle-thumb"></span></span>
              </label>
            </div>
          </div>

          <!-- Bypass -->
          <div class="settings-section">
            <div class="settings-section-title" id="settings-bypass-title">Обход блокировки</div>
            <div class="settings-row">
              <span class="settings-label">Включить обход</span>
              <label class="settings-toggle">
                <input type="checkbox" id="settings-bypass" ${settings.bypassEnabled ? 'checked' : ''} onchange="SettingsComponent._toggleBypass(this.checked)">
                <span class="settings-toggle-track"><span class="settings-toggle-thumb"></span></span>
              </label>
            </div>
            <div class="settings-hint">Проксирует обложки и аватарки через сервер, если CDN заблокирован</div>
            ${settings.cdnProxyEnabled ? '<div class="settings-hint" style="color:#4caf50">CDN прокси активен — обложки загружаются через сервер</div>' : ''}
            ${settings.bypassEnabled && settings.bypassMethodIndex > 0 ? '<div class="settings-hint" style="color:#4caf50">Обход активен — используется прокси #' + settings.bypassMethodIndex + '</div>' : ''}
            ${settings.bypassEnabled && !settings.cdnProxyEnabled && !settings.bypassMethodIndex ? '<div class="settings-hint" style="color:var(--accent)">CDN доступен напрямую</div>' : ''}
          </div>

          <!-- Background mode -->
          <div class="settings-section">
            <div class="settings-section-title">Режим работы</div>
            <div class="settings-row">
              <span class="settings-label">Фоновый режим</span>
              <label class="settings-toggle">
                <input type="checkbox" id="settings-bgmode" ${settings.backgroundMode ? 'checked' : ''} onchange="SettingsComponent._toggleBackgroundMode(this.checked)">
                <span class="settings-toggle-track"><span class="settings-toggle-thumb"></span></span>
              </label>
            </div>
            <div class="settings-hint">При закрытии окна приложение продолжает работать в системном трее</div>
          </div>

          <!-- Yandex Music Import (кнопка экспорта — без тумблера ненайденных) -->
          <div class="settings-section">
            <div class="settings-section-title">Импорт</div>
            <button class="ym-import-btn" onclick="YandexImport.openDialog()">
              <svg class="ym-import-icon" width="22" height="22" viewBox="0 0 1000 999.9941406" fill="none">
                <path fill="#FED42B" d="M990.5263062,381.161499l-3.9005737-19.3916931l-164.9055176-28.8068542l95.8240356-129.6425323l-11.1403198-12.1870575l-140.9465332,67.5902405l17.8244629-179.5018616l-14.4853516-8.3040466L683.001709,216.0630493L586.6281128,0h-16.7133179l22.8419189,208.8642578L350.4190063,14.9589682l-20.6139221,6.0935392l186.6246033,234.3495026L147.0751495,132.4085846l-16.7133484,18.8361511l329.8051147,187.8175812L5.0116663,376.7229309L0,404.9859009l472.9796448,51.5201721L78.5492401,782.8198853l16.7133484,22.7133179l469.6347046-255.3961792l-93.0286865,449.8571167h28.4150391l179.9404297-423.2665405l109.7478638,331.302124l19.5028687-14.9589233l-45.1283569-336.8401489l171.0282593,193.9052734l11.1461792-17.730835L815.5976562,491.9620667l182.7298584,67.5902405L1000,539.0553589L836.2114868,418.2782898l154.3208008-37.1167297L990.5263062,381.161499z"/>
              </svg>
              <span>Экспорт из Яндекс Музыки</span>
              <svg class="ym-import-sc-icon" xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 512 512"><rect width="512" height="512" rx="15%" fill="#f50"/><path d="m59 270-3 22 3 22c0 2 3 2 3 0l3-22-3-22c0-3-3-3-3 0zm18-14c0-3-3-3-3 0l-5 36 4 35c0 3 4 3 4 0l4-35zm59-30-3 66 2 40c0 8 7 8 7 0l4-40-4-66c0-5-6-5-6 0zm-31 22-4 44 3 40c0 6 5 6 5 0l4-40-4-44c0-3-4-3-4 0zm70 84 3-40-3-88c0-6-7-6-7 0l-3 88 2 40c0 8 8 8 8 0zm68 0 2-40-2-102c0-7-10-7-10 0l-2 102 2 40c0 8 10 8 10 0zm-34 0 3-40-3-89c0-6-9-6-9 0l-2 89 2 40c0 8 9 8 9 0zm-83 0 3-40-3-41c0-3-6-3-6 0l-3 41 3 40c0 7 6 7 6 0zm-33 0 4-40-4-43c0-3-4-3-4 0l-4 43 4 40c0 4 4 4 4 0zm124-125-2 85 1 40c0 8 10 8 10 0l2-40-2-85c0-7-9-7-9 0zm-58 125 3-40-3-81c0-6-7-6-7 0l-3 81 2 40c0 8 8 8 8 0zm33 0 3-40-3-91c0-6-8-6-8 0l-3 91 3 40c0 8 8 8 8 0zm196-89c-5-57-64-94-118-73-4 2-5 3-5 6v156c0 3 2 6 5 6h137c27 0 49-22 49-49 0-37-35-57-68-46zm-138-62-3 111 3 40c0 8 10 8 10 0l3-40-3-111c0-7-10-7-10 0z" fill="#ffffff"/></svg>
            </button>
            <div class="settings-hint">Перенесёт лайкнутые треки из Яндекс Музыки в MusiCenter через поиск в SoundCloud</div>
          </div>

          <!-- СаундВолна + YM Playlist toggle -->
          <div class="settings-section">
            <div class="settings-section-title">СаундВолна</div>
            ${(() => {
              const ymPl = (Store.get('playlists') || []).find(p => p.isYandex === true && p.title === 'Яндекс Музыка');
              const available = ymPl && ymPl.tracks && ymPl.tracks.length > 0;
              // ★ FIX: Show saved state even when playlist is loading.
              // Only use `available` to DISABLE the toggle, not to override the visual state.
              const checked = !!settings.swUseYmPlaylist;
              return `
                <div class="settings-row">
                  <span class="settings-label" style="${!available ? 'opacity:0.4' : ''}">СаундВолна взаимодействует с плейлистом Яндекс Музыки</span>
                  <label class="settings-toggle${!available ? ' settings-toggle-dim' : ''}">
                    <input type="checkbox" id="settings-sw-ym" ${checked ? 'checked' : ''} ${!available ? 'disabled' : ''}
                      onchange="SettingsComponent._toggleSwYm(this.checked)">
                    <span class="settings-toggle-track"><span class="settings-toggle-thumb"></span></span>
                  </label>
                </div>
                <div class="settings-hint" style="${!available ? 'opacity:0.3;font-style:italic' : ''}">
                  ${!available ? 'Плейлист «Яндекс Музыка» не найден или пуст' : 'СаундВолна берёт треки из плейлиста Яндекс Музыки и тоже использует их для алгоритмов'}
                </div>
              `;
            })()}
          </div>

        </div>
      </div>
    `;

    requestAnimationFrame(() => el.classList.add('open'));
  },

  close() {
    if (!this._open) return;
    this._open = false;
    const el = document.getElementById('settings-panel');
    if (!el) return;
    el.classList.remove('open');
    setTimeout(() => el.remove(), 350);
  },

  _selectTheme(id) {
    if (id === 'custom') {
      this._openCustomEditor();
      return;
    }
    this.applyTheme(id, true);
    document.querySelectorAll('.settings-theme-item').forEach(item => {
      item.classList.toggle('active', item.dataset.theme === id);
    });
    Utils.log('info', '[Settings] Theme selected: ' + id);
  },

  
  _themeContextMenu(e, themeId) {
    if (themeId === 'custom') return; 
    e.preventDefault();
    e.stopPropagation();

    
    document.querySelectorAll('.theme-ctx-menu').forEach(m => m.remove());

    const menu = document.createElement('div');
    menu.className = 'theme-ctx-menu ctx-menu';
    menu.style.cssText = 'left:' + Math.min(e.clientX, window.innerWidth - 200) + 'px;top:' + Math.min(e.clientY, window.innerHeight - 60) + 'px';
    menu.innerHTML = '<div class="ctx-item" style="white-space:nowrap">Открыть в Custom</div>';
    menu.querySelector('.ctx-item').addEventListener('click', () => {
      menu.remove();
      this._openInCustom(themeId);
    });
    document.body.appendChild(menu);
    requestAnimationFrame(() => menu.classList.add('open'));
    setTimeout(() => document.addEventListener('click', () => {
      menu.classList.remove('open');
      setTimeout(() => menu.remove(), 200);
    }, { once: true }), 10);
  },

  _openInCustom(themeId) {
    const theme = Themes[themeId];
    if (!theme) return;

    InAppModal.confirm({
      title: 'Открыть в Custom',
      message: 'Если у вас уже была тема в Custom, она пропадёт!',
      confirmText: 'Да, я согласен',
      danger: false,
      onConfirm: () => {
        
        const customColors = {
          accent: theme.accent,
          bgPrimary: theme.bgPrimary,
          waveBars: theme.waveBars || '',
          waveHex: theme.accent,
        };
        const settings = Store.get('settings') || {};
        settings.customTheme = customColors;
        Store.set({ settings });

        Themes.custom = _buildCustomTheme(customColors);
        this.applyTheme('custom', true);
        this._updateCustomThemePreview();

        
        this._openCustomEditor();
        Utils.log('info', '[Settings] Theme "' + themeId + '" opened in Custom editor');
        Utils.toast('Тема загружена в Custom для редактирования');
      },
    });
  },

  _openCustomEditor() {
    const c = _getCustomColors();
    const settings = Store.get('settings') || {};
    const bgUrl = settings.bgImageUrl || '';
    const bgOpacity = settings.bgOpacity || 0.15;
    let ed = document.getElementById('custom-theme-editor');
    if (ed) ed.remove();

    ed = document.createElement('div');
    ed.id = 'custom-theme-editor';
    ed.innerHTML = `
      <div class="cte-backdrop" onclick="SettingsComponent._closeCustomEditor()"></div>
      <div class="cte-card">
        <div class="cte-header">
          <h3>Своя тема</h3>
          <button class="settings-close-btn" onclick="SettingsComponent._closeCustomEditor()">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>
          </button>
        </div>
        <div class="cte-body">
          <div class="cte-preview" id="cte-preview">
            <div class="cte-preview-bar" id="cte-bar" style="background:${c.accent}"></div>
            <div class="cte-preview-bg" id="cte-bg" style="background:${c.bgPrimary}">
              <div class="cte-preview-card" id="cte-card-preview" style="background:rgba(255,255,255,0.06)">
                <div class="cte-preview-accent" id="cte-accent-dot" style="background:${c.accent}"></div>
                <div class="cte-preview-lines">
                  <div style="width:60%;height:4px;border-radius:2px;background:rgba(255,255,255,0.5)"></div>
                  <div style="width:40%;height:3px;border-radius:2px;background:rgba(255,255,255,0.2)"></div>
                </div>
              </div>
              <div class="cte-preview-wave" id="cte-wave">
                <div class="cte-wave-b" style="height:8px;background:${c.waveHex||c.accent}"></div>
                <div class="cte-wave-b" style="height:14px;background:${c.waveHex||c.accent}"></div>
                <div class="cte-wave-b" style="height:10px;background:${c.waveHex||c.accent}"></div>
                <div class="cte-wave-b" style="height:16px;background:${c.waveHex||c.accent}"></div>
                <div class="cte-wave-b" style="height:6px;background:${c.waveHex||c.accent}"></div>
              </div>
            </div>
          </div>

          <div class="cte-row">
            <label>Акцентный цвет</label>
            <div class="cte-color-wrap">
              <input type="color" id="cte-accent" value="${c.accent}" oninput="SettingsComponent._ctePreview()">
              <span class="cte-hex" id="cte-accent-hex">${c.accent}</span>
            </div>
          </div>
          <div class="cte-row">
            <label>Цвет фона</label>
            <div class="cte-color-wrap">
              <input type="color" id="cte-bg-color" value="${c.bgPrimary}" oninput="SettingsComponent._ctePreview()">
              <span class="cte-hex" id="cte-bg-hex">${c.bgPrimary}</span>
            </div>
          </div>
          <div class="cte-row">
            <label>Цвет волн</label>
            <div class="cte-color-wrap">
              <input type="color" id="cte-wave-color" value="${c.waveHex || c.accent}" oninput="SettingsComponent._ctePreview()">
              <span class="cte-hex" id="cte-wave-hex">${c.waveHex||c.accent}</span>
            </div>
          </div>

          <!-- ★ Background image/GIF section (moved here from main settings) -->
          <div class="cte-divider"></div>
          <div class="cte-row cte-bg-section">
            <label>Фон (изображение / GIF)</label>
            <div class="cte-bg-picker">
              <button class="cte-bg-btn ${bgUrl ? '' : 'active'}" onclick="SettingsComponent._setBg('');SettingsComponent._openCustomEditor()">Нет</button>
              <button class="cte-bg-btn" onclick="document.getElementById('cte-bg-file-input').click()">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                Файл
              </button>
              <button class="cte-bg-btn" onclick="SettingsComponent._cteBgToggleUrl()">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>
                URL
              </button>
              <input type="file" id="cte-bg-file-input" accept="image/*,.gif" style="display:none" onchange="SettingsComponent._cteBgFileChosen(this)">
            </div>
          </div>
          <div id="cte-bg-url-row" style="display:none;gap:6px;margin-top:6px">
            <input type="text" id="cte-bg-url-input" class="settings-input" placeholder="https://..." style="flex:1" onkeydown="if(event.key==='Enter')SettingsComponent._cteBgFromUrl()">
            <button class="settings-btn-sm" onclick="SettingsComponent._cteBgFromUrl()">ОК</button>
          </div>
          ${bgUrl ? `
          <div class="cte-row" style="margin-top:8px">
            <label>Прозрачность фона: <strong>${Math.round((bgOpacity||0.15)*100)}%</strong></label>
          </div>
          <input type="range" class="settings-slider" min="0" max="60" step="1" value="${Math.round((bgOpacity||0.15)*100)}"
                 oninput="SettingsComponent._bgOpacity(this.value)" style="margin:6px 0">
          <div style="display:flex;align-items:center;gap:8px;margin-top:4px">
            <img src="${bgUrl}" style="max-height:50px;border-radius:6px;opacity:0.7">
            <button class="cte-bg-btn" onclick="SettingsComponent._setBg('');SettingsComponent._openCustomEditor()" style="color:#ef4444">✕ Убрать</button>
          </div>
          ` : ''}
        </div>
        <div class="cte-footer">
          <button class="cte-cancel" onclick="SettingsComponent._closeCustomEditor()">Отмена</button>
          <button class="cte-apply" onclick="SettingsComponent._applyCustomTheme()">Применить</button>
        </div>
      </div>
    `;
    document.body.appendChild(ed);
    requestAnimationFrame(() => ed.classList.add('open'));
  },

  _ctePreview() {
    const accent = document.getElementById('cte-accent').value;
    const bg = document.getElementById('cte-bg-color').value;
    const wave = document.getElementById('cte-wave-color').value;
    
    document.getElementById('cte-accent-hex').textContent = accent;
    document.getElementById('cte-bg-hex').textContent = bg;
    document.getElementById('cte-wave-hex').textContent = wave;
    
    document.getElementById('cte-bar').style.background = accent;
    document.getElementById('cte-bg').style.background = bg;
    document.getElementById('cte-accent-dot').style.background = accent;
    document.querySelectorAll('.cte-wave-b').forEach(b => b.style.background = wave);
  },

  _applyCustomTheme() {
    const accent = document.getElementById('cte-accent').value;
    const bg = document.getElementById('cte-bg-color').value;
    const waveHex = document.getElementById('cte-wave-color').value;
    const {r,g,b} = _hexToRgb(waveHex);
    const waveBars = `rgba(${r},${g},${b},0.35)`;

    const customColors = { accent, bgPrimary: bg, waveBars, waveHex: waveHex };
    const settings = Store.get('settings') || {};
    settings.customTheme = customColors;
    Store.set({ settings });

    Themes.custom = _buildCustomTheme(customColors);
    this.applyTheme('custom', true);
    this._closeCustomEditor();
    
    document.querySelectorAll('.settings-theme-item').forEach(item => {
      item.classList.toggle('active', item.dataset.theme === 'custom');
    });
    
    this._updateCustomThemePreview();
  },

  
  _updateCustomThemePreview() {
    const customItem = document.querySelector('.settings-theme-item[data-theme="custom"]');
    if (!customItem) return;
    const preview = Themes.custom?.preview;
    if (!preview) return;
    const bg = customItem.querySelector('.stp-bg');
    const accent = customItem.querySelector('.stp-accent');
    const card = customItem.querySelector('.stp-card');
    if (bg) bg.style.background = preview[1];
    if (accent) accent.style.background = preview[0];
    if (card) card.style.background = preview[2];
  },

  _closeCustomEditor() {
    const ed = document.getElementById('custom-theme-editor');
    if (!ed) return;
    ed.classList.remove('open');
    setTimeout(() => ed.remove(), 300);
  },

  _toggleCrossfade(enabled) {
    const settings = Store.get('settings') || {};
    settings.crossfade = enabled;
    Store.set({ settings });
    const row = document.getElementById('crossfade-dur-row');
    if (row) row.classList.toggle('disabled', !enabled);
    CrossfadeEngine.setEnabled(enabled);
  },

  _setCrossfadeDuration(val) {
    const settings = Store.get('settings') || {};
    settings.crossfadeDuration = parseInt(val);
    Store.set({ settings });
    const label = document.getElementById('crossfade-dur-val');
    if (label) label.textContent = val + 'с';
    CrossfadeEngine.setDuration(parseInt(val));
  },

  _toggleComments(enabled) {
    const settings = Store.get('settings') || {};
    settings.commentsEnabled = enabled;
    Store.set({ settings });
    CommentsComponent._enabled = enabled;
    if (!enabled) CommentsComponent._clearAll();
  },

  _toggleBackgroundMode(enabled) {
    const settings = Store.get('settings') || {};
    settings.backgroundMode = enabled;
    Store.set({ settings });
    const api = window.pywebview?.api;
    if (api) api.set_background_mode(enabled);
  },

  _toggleShowYmTab(enabled) {
    const settings = Store.get('settings') || {};
    settings.showYmImportTab = enabled;
    Store.set({ settings });
    YandexImport._updateSidebarTab();
  },

  
  _toggleSwYm(enabled) {
    const settings = Store.get('settings') || {};
    settings.swUseYmPlaylist = enabled;
    Store.set({ settings });
    Utils.log('info', `[Settings] SW+YM playlist toggle: ${enabled ? 'ON' : 'OFF'}`);

    
    if (!enabled && typeof SoundWave !== 'undefined' && SoundWave.isActive()) {
      SoundWave.stop();
      Utils.log('info', '[Settings] SW stopped because YM playlist was disabled');
      Utils.toast('СаундВолна выключена — YM плейлист отключён');
      if (Store.get('currentPage') === 'home' && typeof HomePage !== 'undefined') {
        setTimeout(() => HomePage.render(), 100);
      }
    } else if (enabled) {
      Utils.toast('СаундВолна теперь использует треки из плейлиста Яндекс Музыки');
    }
  },

  _applyBackground(url, opacity) {
    const bg = document.getElementById('app-background');
    if (!url) {
      if (bg) bg.remove();
      return;
    }
    let el = bg;
    if (!el) {
      el = document.createElement('div');
      el.id = 'app-background';
      
      const app = document.getElementById('app');
      if (app) app.insertBefore(el, app.firstChild);
      else document.body.insertBefore(el, document.body.firstChild);
    }
    el.style.backgroundImage = `url(${url})`;
    el.style.opacity = opacity != null ? opacity : 0.15;
  },

  _setBg(url) {
    const settings = Store.get('settings') || {};
    settings.bgImageUrl = url;
    Store.set({ settings });
    this._applyBackground(url, settings.bgOpacity || 0.15);
    Utils.log('info', `[Settings] Background image ${url ? 'set' : 'removed'}`);
  },

  _bgOpacity(val) {
    const opacity = parseInt(val) / 100;
    const settings = Store.get('settings') || {};
    settings.bgOpacity = opacity;
    Store.set({ settings });
    this._applyBackground(settings.bgImageUrl, opacity);
    document.querySelectorAll('.settings-row span:last-child').forEach(s => {
      if (s.textContent && s.textContent.endsWith('%')) s.textContent = val + '%';
    });
  },

  _bgToggleUrl() {
    const row = document.getElementById('settings-bg-url-row');
    if (row) row.style.display = row.style.display === 'none' ? 'flex' : 'none';
    setTimeout(() => document.getElementById('settings-bg-url-input')?.focus(), 50);
  },

  _cteBgToggleUrl() {
    const row = document.getElementById('cte-bg-url-row');
    if (row) row.style.display = row.style.display === 'none' ? 'flex' : 'none';
    setTimeout(() => document.getElementById('cte-bg-url-input')?.focus(), 50);
  },

  _cteBgFromUrl() {
    const input = document.getElementById('cte-bg-url-input');
    const url = input?.value?.trim();
    if (!url) return;
    this._setBg(url);
    
    this._openCustomEditor();
  },

  _cteBgFileChosen(input) {
    const file = input.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      this._setBg(e.target.result);
      this._openCustomEditor();
    };
    reader.readAsDataURL(file);
    input.value = '';
  },

  async _bgFromUrl() {
    const input = document.getElementById('settings-bg-url-input');
    const url = input?.value?.trim();
    if (!url) return;
    this._setBg(url);
  },

  _bgPickFile() {
    document.getElementById('settings-bg-file-input')?.click();
  },

  _bgFileChosen(input) {
    const file = input.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => { this._setBg(e.target.result); };
    reader.readAsDataURL(file);
    input.value = '';
  },

  _toggleBypass(enabled) {
    const settings = Store.get('settings') || {};
    settings.bypassEnabled = enabled;
    if (!enabled) {
      settings.bypassMethod = null;
      settings.bypassMethodIndex = null;
    }
    Store.set({ settings });
    if (enabled) {
      BypassEngine.startProbing();
    } else {
      Utils._imgProxyEnabled = false;
      Utils._imgProxyFn = null;
      BypassEngine._workingMethodIndex = -1;
      
      setTimeout(() => {
        const page = Store.get('currentPage') || 'home';
        App.navigate(page, false);
        NowPlayingComponent._updateTrackInfo();
      }, 300);
    }
  },

  
  highlightBypass() {
    if (!this._open) this.open();
    setTimeout(() => {
      const title = document.getElementById('settings-bypass-title');
      if (title) {
        title.style.color = 'var(--accent)';
        title.style.transition = 'color 0.3s ease';
        title.scrollIntoView({ behavior: 'smooth', block: 'center' });
        setTimeout(() => { title.style.color = ''; }, 2500);
      }
    }, 400);
  },
};


const CrossfadeEngine = {
  _enabled:      false,
  _duration:     6,       
  _crossfading:  false,
  _preloadedUrn: null,

  
  _audioB:      null,   
  _ctxB:        null,   
  _sourceB:     null,   
  _gainA:       null,   
  _gainB:       null,   

  init() {
    const settings = Store.get('settings') || {};
    this._duration = settings.crossfadeDuration || 6;
    this._enabled  = !!(settings.crossfade);
    if (this._enabled) {
      Utils.log('info', `[Crossfade] Включён (Web Audio, ${this._duration}s)`);
    }
  },

  setEnabled(v) {
    this._enabled = v;
    const settings = Store.get('settings') || {};
    settings.crossfade = v;
    Store.set({ settings });
    if (!v) this._cleanup();
    Utils.log('info', `[Crossfade] ${v ? 'ВКЛ' : 'ВЫКЛ'}`);
  },

  setDuration(v) {
    this._duration = v;
    const settings = Store.get('settings') || {};
    settings.crossfadeDuration = v;
    Store.set({ settings });
  },

  
  startCrossfade() {
    if (!this._enabled || this._crossfading) return;
    const { queue, queueIndex } = Store._state;
    const nextTrack = queue[queueIndex + 1];
    if (!nextTrack) return;
    if (nextTrack.urn === this._preloadedUrn) return; 

    this._crossfading  = true;
    this._preloadedUrn = nextTrack.urn;
    Utils.log('info', `[Crossfade] Начало — следующий: ${nextTrack.title}`);

    try {
      
      const ctx = Player._ctx;
      if (!ctx || !Player._masterGain) {
        this._cleanup(); return;
      }
      
      
      this._gainA = Player._masterGain;
      const dur = this._duration;
      const now = ctx.currentTime;
      this._gainA.gain.setValueAtTime(this._gainA.gain.value, now);
      this._gainA.gain.linearRampToValueAtTime(0, now + dur);

      
      this._audioB = new Audio();
      this._audioB.crossOrigin = 'anonymous';
      this._audioB.src = API.streamUrl(nextTrack.urn);
      this._audioB.volume = 1.0;

      this._ctxB   = ctx; 
      this._sourceB = ctx.createMediaElementSource(this._audioB);
      this._gainB   = ctx.createGain();
      this._gainB.gain.setValueAtTime(0, now);
      this._gainB.gain.linearRampToValueAtTime(1, now + dur);
      this._sourceB.connect(this._gainB);
      this._gainB.connect(ctx.destination);

      this._audioB.play().catch(e => {
        Utils.log('error', '[Crossfade] audioB play failed: ' + e.message);
        this._cleanup();
      });

      
      setTimeout(() => {
        if (!this._crossfading) return;
        
        if (this._gainA) this._gainA.gain.value = 1.0;
        this._cleanup();
        Store.next(); 
        Utils.log('info', '[Crossfade] Завершён — переход на следующий трек');
      }, dur * 1000);

    } catch (e) {
      Utils.log('error', '[Crossfade] Ошибка: ' + e.message);
      this._cleanup();
    }
  },

  _cleanup() {
    if (this._audioB) {
      this._audioB.pause();
      this._audioB.src = '';
      try { this._sourceB?.disconnect(); } catch (_) {}
      try { this._gainB?.disconnect();   } catch (_) {}
      this._audioB  = null;
      this._sourceB = null;
      this._gainB   = null;
    }
    
    if (this._gainA && Player._ctx) {
      this._gainA.gain.cancelScheduledValues(Player._ctx.currentTime);
      this._gainA.gain.value = 1.0;
      this._gainA = null;
    }
    this._crossfading  = false;
    this._preloadedUrn = null;
  },
};


const BypassEngine = {
  _probing: false,
  _timeoutTimer: null,
  _workingMethodIndex: -1,  

  
  _proxyUrl(imgUrl, m) {
    return '/imgproxy?url=' + encodeURIComponent(imgUrl) + '&m=' + m;
  },

  
  _testMethod(methodIndex) {
    return new Promise(function (resolve) {
      var testImgUrl = 'https://a1.sndcdn.com/images/default_avatar_large.png';
      var url = methodIndex === 0
        ? testImgUrl
        : '/imgproxy?url=' + encodeURIComponent(testImgUrl) + '&m=' + methodIndex;
      var img = new Image();
      var timer = setTimeout(function () { img.src = ''; resolve(false); }, 8000);
      img.onload = function () { clearTimeout(timer); resolve(img.naturalWidth > 0); };
      img.onerror = function () { clearTimeout(timer); resolve(false); };
      img.src = url + '&_t=' + Date.now();
    });
  },

  
  async startProbing() {
    if (this._probing) return;
    this._probing = true;
    this._showOverlay();

    
    this._setMsg('Проверяем прямой доступ...');
    this._updateProgress(1, 14);

    const directOk = await this._testMethod(0);
    if (directOk) {
      Utils._imgProxyEnabled = false;
      this._workingMethodIndex = 0;
      this._onSuccess('CDN доступен напрямую — прокси не нужен');
      return;
    }

    
    const methodNames = [
      '', 
      'wsrv.nl',
      'weserv.nl',
      'corsproxy.io',
      'allorigins.win',
      'thingproxy',
      'codetabs.com',
      'cors.sh',
      'bridged.cc',
      'cors-anywhere',
      'yacdn.org',
      'codetabs (2)',
    ];

    for (let i = 1; i < 12; i++) {
      this._setMsg(`Пробуем прокси #${i}: ${methodNames[i] || 'метод ' + i}...`);
      this._updateProgress(i + 1, 14);

      const ok = await this._testMethod(i);
      if (ok) {
        Utils._imgProxyEnabled = true;
        Utils._imgProxyFn = (url) => this._proxyUrl(url, i);
        this._workingMethodIndex = i;

        const settings = Store.get('settings') || {};
        settings.bypassMethod = 'server_proxy_' + i;
        settings.bypassMethodIndex = i;
        Store.set({ settings });

        this._onSuccess(`Прокси #${i} (${methodNames[i] || 'метод ' + i}) работает!`);
        setTimeout(() => {
          const page = Store.get('currentPage') || 'home';
          App.navigate(page, false);
          NowPlayingComponent._updateTrackInfo();
        }, 800);
        return;
      }
    }

    this._onAllFailed();
  },

  
  restoreFromSettings(settings) {
    if (!settings.bypassEnabled) return;
    const idx = settings.bypassMethodIndex;
    if (idx != null && idx > 0) {
      Utils._imgProxyEnabled = true;
      Utils._imgProxyFn = (url) => this._proxyUrl(url, idx);
      this._workingMethodIndex = idx;
    } else if (settings.bypassMethod === 'wsrv' || idx == null) {
      
      Utils._imgProxyEnabled = true;
      Utils._imgProxyFn = (url) => this._proxyUrl(url, 1);
      this._workingMethodIndex = 1;
    }
  },

  _onSuccess(message) {
    this._probing = false;
    const bar = document.querySelector('.bypass-progress-fill');
    if (bar) { bar.style.width = '100%'; bar.style.background = '#4caf50'; bar.style.transition = 'width 0.3s ease, background 0.3s ease'; }
    this._setMsg(message);
    setTimeout(() => this._hideOverlay(), 1500);
    Utils.toast(message);
  },

  _onAllFailed() {
    this._probing = false;
    const bar = document.querySelector('.bypass-progress-fill');
    if (bar) { bar.style.width = '100%'; bar.style.background = '#ef4444'; }
    this._setMsg('Все прокси недоступны. Попробуйте VPN.');
    setTimeout(() => this._hideOverlay(), 3000);
    Utils.toast('Не удалось найти рабочий прокси');
  },

  _showOverlay() {
    let el = document.getElementById('bypass-overlay');
    if (!el) { el = document.createElement('div'); el.id = 'bypass-overlay'; document.body.appendChild(el); }
    el.innerHTML = `
      <div class="bypass-overlay-content">
        <div class="bypass-overlay-text">Поиск обхода блокировки...</div>
        <div class="bypass-progress-bar"><div class="bypass-progress-fill"></div></div>
        <div class="bypass-overlay-hint">Проверяем 12 методов</div>
      </div>
    `;
    requestAnimationFrame(() => el.classList.add('open'));
  },

  _hideOverlay() {
    const el = document.getElementById('bypass-overlay');
    if (!el) return;
    el.classList.remove('open');
    setTimeout(() => el.remove(), 400);
  },

  _updateProgress(current, total) {
    const bar = document.querySelector('.bypass-progress-fill');
    if (bar) { bar.style.width = ((current / total) * 100) + '%'; bar.style.transition = 'width 0.4s ease'; }
  },

  _setMsg(text) {
    const msg = document.querySelector('.bypass-overlay-text');
    if (msg) msg.textContent = text;
    const hint = document.querySelector('.bypass-overlay-hint');
    if (hint) hint.textContent = text;
  },

  
  startTimeoutWatch() {
    this._timeoutTimer = setTimeout(async () => {
      const settings = Store.get('settings') || {};

      
      if (settings.bypassEnabled) {
        this.restoreFromSettings(settings);
        return;
      }

      
      const directOk = await this._testMethod(0);
      if (!directOk) {
        
        const toast = document.createElement('div');
        toast.className = 'bypass-suggestion';
        toast.innerHTML = `
          <span>Обложки не загружаются. Включите <a onclick="SettingsComponent.highlightBypass()" style="color:var(--accent);cursor:pointer;text-decoration:underline">обход</a> в настройках!</span>
          <button onclick="this.parentElement.remove()" style="background:none;border:none;color:rgba(255,255,255,0.5);cursor:pointer;padding:4px;margin-left:8px">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
          </button>
        `;
        document.body.appendChild(toast);
        requestAnimationFrame(() => toast.classList.add('visible'));
        setTimeout(() => { if (toast.parentElement) { toast.classList.remove('visible'); setTimeout(() => toast.remove(), 300); } }, 14000);
      }
    }, 4000);
  },

  cancelTimeoutWatch() {
    if (this._timeoutTimer) { clearTimeout(this._timeoutTimer); this._timeoutTimer = null; }
  }
};


const YandexImport = {
  _polling: null,
  _overlay: null,
  _savedToken: '',
  _notFoundList: [],

  
  _injectOverlayCss() {
    if (document.getElementById('ym-import-overlay-css')) return;
    const s = document.createElement('style');
    s.id = 'ym-import-overlay-css';
    s.textContent = `
      .ym-import-fulloverlay {
        position: fixed !important; top: 36px !important; left: 0 !important; right: 0 !important; bottom: 0 !important;
        z-index: 9990 !important;
        display: flex !important; align-items: center !important; justify-content: center !important;
        background: rgba(0,0,0,0.68) !important;
        backdrop-filter: blur(16px) !important; -webkit-backdrop-filter: blur(16px) !important;
        opacity: 0; transition: opacity 0.3s ease; pointer-events: all;
      }
      .ym-import-fulloverlay.open { opacity: 1; }
      .ym-import-fulloverlay.closing { opacity: 0 !important; }
      body.ym-import-active .sidebar { pointer-events:none!important; filter:blur(4px); opacity:0.3; transition:filter .3s,opacity .3s; user-select:none; }
      body.ym-import-active #content { overflow:hidden!important; pointer-events:none!important; }
      /* ★ Titlebar STAYS usable during import (close/minimize/move) */
      body.ym-import-active .now-playing-bar,
      body.ym-import-active #player-bar { pointer-events:none; filter:blur(2px); opacity:0.45; transition:filter .3s,opacity .3s; }
      .settings-toggle-dim { opacity:0.35!important; filter:grayscale(0.6); cursor:not-allowed; }
      .settings-toggle-dim input { pointer-events:none; }
      #ym-skipped { display:none; }
      #ym-skipped.visible { display:inline; }
    `;
    document.head.appendChild(s);
  },

  
  _hasNotFound() { return false; },
  _updateSidebarTab() {
    const existing = document.getElementById('nav-ym-import');
    if (existing) existing.remove();
  },
  async _refreshNotFound() { this._notFoundList = []; },

  openDialog() {
    
    SettingsComponent.close();
    this._removeOverlay();
    this._injectOverlayCss();

    
    document.body.classList.add('ym-import-active');

    
    if (!this._savedToken && window._ymTokenPending) {
      this._savedToken = window._ymTokenPending;
    }
    const savedToken = this._savedToken || Store.get('ymSavedToken') || '';

    const el = document.createElement('div');
    el.className = 'ym-import-fulloverlay';
    el.id = 'ym-import-overlay';
    el.innerHTML = `
      <div class="ym-overlay-box">
        <div class="ym-overlay-title">
          <svg width="24" height="24" viewBox="0 0 1000 999.9941406" fill="none">
            <path fill="#FED42B" d="M990.5,381.2l-3.9-19.4l-164.9-28.8l95.8-129.6l-11.1-12.2l-141,67.6l17.8-179.5l-14.5-8.3L683,216.1L586.6,0h-16.7l22.8,208.9L350.4,15l-20.6,6.1l186.6,234.3L147.1,132.4l-16.7,18.8l329.8,187.8L5,376.7L0,405l473,51.5L78.5,782.8l16.7,22.7l469.6-255.4l-93,449.9h28.4l179.9-423.3l109.7,331.3l19.5-15l-45.1-336.8l171,193.9l11.1-17.7L815.6,492l182.7,67.6L1000,539.1l-163.8-120.8l154.3-37.1L990.5,381.2z"/>
          </svg>
          <span>Импорт из Яндекс Музыки</span>
          <span style="margin-left:auto;opacity:0.3">→</span>
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 512 512"><rect width="512" height="512" rx="15%" fill="#f50"/><path d="m59 270-3 22 3 22c0 2 3 2 3 0l3-22-3-22c0-3-3-3-3 0zm18-14c0-3-3-3-3 0l-5 36 4 35c0 3 4 3 4 0l4-35zm59-30-3 66 2 40c0 8 7 8 7 0l4-40-4-66c0-5-6-5-6 0zm-31 22-4 44 3 40c0 6 5 6 5 0l4-40-4-44c0-3-4-3-4 0zm70 84 3-40-3-88c0-6-7-6-7 0l-3 88 2 40c0 8 8 8 8 0zm68 0 2-40-2-102c0-7-10-7-10 0l-2 102 2 40c0 8 10 8 10 0zm-34 0 3-40-3-89c0-6-9-6-9 0l-2 89 2 40c0 8 9 8 9 0zm-83 0 3-40-3-41c0-3-6-3-6 0l-3 41 3 40c0 7 6 7 6 0zm-33 0 4-40-4-43c0-3-4-3-4 0l-4 43 4 40c0 4 4 4 4 0zm124-125-2 85 1 40c0 8 10 8 10 0l2-40-2-85c0-7-9-7-9 0zm-58 125 3-40-3-81c0-6-7-6-7 0l-3 81 2 40c0 8 8 8 8 0zm33 0 3-40-3-91c0-6-8-6-8 0l-3 91 3 40c0 8 8 8 8 0zm196-89c-5-57-64-94-118-73-4 2-5 3-5 6v156c0 3 2 6 5 6h137c27 0 49-22 49-49 0-37-35-57-68-46zm-138-62-3 111 3 40c0 8 10 8 10 0l3-40-3-111c0-7-10-7-10 0z" fill="#ffffff"/></svg>
          <span>MusiCenter</span>
        </div>
        <input type="password" class="ym-token-input" id="ym-token-input" placeholder="Вставьте токен Яндекс Музыки..." autocomplete="off" value="${Utils.esc(savedToken)}">
        <div class="ym-token-hint">
          Токен можно получить через расширение для браузера
          (<a href="#" onclick="event.preventDefault();window.open('https://chromewebstore.google.com/detail/yandex-music-token/lcbjeookjibfhjjopieifgjnhlegmkib','_blank');return false" style="pointer-events:auto;cursor:pointer;color:var(--accent,#ff5500)"><strong>Chrome</strong></a> /
          <a href="#" onclick="event.preventDefault();window.open('https://addons.mozilla.org/ru/firefox/addon/yandex-music-token/','_blank');return false" style="pointer-events:auto;cursor:pointer;color:var(--accent,#ff5500)"><strong>Firefox</strong></a>).<br>
          Лайкнутые треки будут найдены в SoundCloud и добавлены в избранное.<br>
          <span style="color:rgba(255,255,255,0.25)">SoundCloud ограничивает ~100 лайков/день. Если не все перенесутся — повторите импорт завтра.</span>
        </div>
        <button class="ym-start-btn" id="ym-start-btn" onclick="YandexImport.startImport()">Начать импорт</button>
        <button class="ym-resume-btn" id="ym-resume-btn" style="display:none" onclick="YandexImport.resumeImport()">Продолжить импорт</button>
        <button class="ym-cancel-btn" id="ym-close-btn" onclick="YandexImport.closeDialog()">Закрыть</button>
        <div class="ym-progress-section" id="ym-progress-section" style="display:none">
          <div class="ym-progress-bar"><div class="ym-progress-fill" id="ym-progress-fill"></div></div>
          <div class="ym-progress-text" id="ym-progress-text">Получение треков из Яндекс Музыки...</div>
          <div class="ym-stats">
            <span class="found" id="ym-found">Найдено: 0</span>
            <span class="missing" id="ym-missing">Не найдено: 0</span>
            <span class="skipped" id="ym-skipped">Скипнуто: 0</span>
          </div>
        </div>
        <div class="ym-pause-msg" id="ym-pause-msg" style="display:none"></div>
        <div class="ym-done-msg" id="ym-done-msg" style="display:none"></div>
      </div>
    `;

    
    document.body.appendChild(el);
    this._overlay = el;
    requestAnimationFrame(() => el.classList.add('open'));

    
    this._checkPausedState();

    setTimeout(() => {
      const inp = document.getElementById('ym-token-input');
      if (inp && !inp.value) inp.focus();
    }, 100);
  },

  
  _closeSmooth() {
    const el = document.getElementById('ym-import-overlay');
    if (el) {
      el.classList.remove('open');
      el.classList.add('closing');
      setTimeout(() => this._removeOverlay(), 350);
    } else {
      this._removeOverlay();
    }
  },

  
  _goToYmPlaylist(id) {
    this._closeSmooth();
    setTimeout(() => {
      App.navigate('playlists');
      setTimeout(() => PlaylistsPage.openPlaylist(id), 300);
    }, 420);
  },

  async _checkPausedState() {
    try {
      const resp = await fetch('/local/ym_import/status');
      const s = await resp.json();
      if (s.status === 'paused') {
        const startBtn = document.getElementById('ym-start-btn');
        const resumeBtn = document.getElementById('ym-resume-btn');
        const progSec = document.getElementById('ym-progress-section');
        const pauseMsg = document.getElementById('ym-pause-msg');
        const tokenInput = document.getElementById('ym-token-input');
        const closeBtn = document.getElementById('ym-close-btn');

        if (startBtn) startBtn.style.display = 'none';
        if (resumeBtn) { resumeBtn.style.display = ''; resumeBtn.disabled = false; resumeBtn.textContent = 'Продолжить импорт'; }
        
        if (tokenInput && !tokenInput.value) {
          const tok = this._savedToken || Store.get('ymSavedToken') || '';
          if (tok) tokenInput.value = tok;
        }
        if (tokenInput) tokenInput.disabled = true;
        if (closeBtn) closeBtn.textContent = 'Закрыть';

        
        if (progSec) {
          progSec.style.display = 'block';
          const fill = document.getElementById('ym-progress-fill');
          const pct = s.total > 0 ? Math.round((s.progress / s.total) * 100) : 0;
          if (fill) fill.style.width = pct + '%';
        }
        const foundEl = document.getElementById('ym-found');
        const missingEl = document.getElementById('ym-missing');
        if (foundEl) foundEl.textContent = 'Найдено: ' + (s.found || 0);
        if (missingEl) missingEl.textContent = 'Не найдено: ' + (s.not_found || 0);

        const liked = s.liked || 0;
        const found = s.found || 0;
        const remaining = s.remaining || 0;
        const tracksToLike = s.tracks_to_like || 0;
        if (pauseMsg) {
          pauseMsg.style.display = 'block';
          let msg = '';
          if (s._liking_phase) {
            msg = '<span style="color:#ff9800">Импорт приостановлен. Найдено: <strong>' + found + '</strong>. Лайкнуто: <strong>' + liked + '</strong>. Осталось лайкнуть: <strong>' + tracksToLike + '</strong>.<br>Через пару часов вы сможете продолжить!</span>';
          } else if (remaining > 0) {
            msg = '<span style="color:#ff9800">Импорт приостановлен. Найдено: <strong>' + found + '</strong>. Осталось найти: <strong>' + remaining + '</strong>.<br>Нажмите «Продолжить импорт» чтобы продолжить с того места, где остановились!</span>';
          } else {
            msg = '<span style="color:#ff9800">Все треки найдены (<strong>' + found + '</strong>). Лайкнуто: <strong>' + liked + '</strong>. Через пару часов вы сможете продолжить!</span>';
          }
          pauseMsg.innerHTML = msg;
        }
      }
    } catch (e) {}
  },

  closeDialog() {
    if (this._polling) {
      
      this._pauseImport();
    }
    this._removeOverlay();
  },

  
  async saveAndClose() {
    if (this._polling) {
      this._stopPolling();
      try { await fetch('/local/ym_import/cancel', { method: 'POST' }); } catch (e) {}
      Utils.log('info', '[YM Import] Saved progress before app close');
    }
  },

  _removeOverlay() {
    this._stopPolling();
    
    document.body.classList.remove('ym-import-active');
    const el = document.getElementById('ym-import-overlay');
    if (el) el.remove();
    this._overlay = null;
  },

  async startImport() {
    const tokenInput = document.getElementById('ym-token-input');
    const token = (tokenInput?.value || '').trim();
    if (!token) {
      tokenInput?.focus();
      tokenInput.style.borderColor = '#ff5252';
      setTimeout(() => { if (tokenInput) tokenInput.style.borderColor = ''; }, 2000);
      Utils.log('warning', '[YM Import] No token entered');
      return;
    }

    Utils.log('info', '[YM Import] Starting import...');

    
    this._savedToken = token;
    Store.set({ ymSavedToken: token });

    const startBtn = document.getElementById('ym-start-btn');
    const resumeBtn = document.getElementById('ym-resume-btn');
    const closeBtn = document.getElementById('ym-close-btn');
    const progSec = document.getElementById('ym-progress-section');
    if (startBtn) startBtn.disabled = true;
    if (startBtn) startBtn.textContent = 'Запуск...';
    if (resumeBtn) resumeBtn.style.display = 'none';
    if (tokenInput) tokenInput.disabled = true;

    try {
      const sessionId = Store.get('sessionId') || '';
      Utils.log('info', '[YM Import] Sending start request to server...');
      const resp = await fetch('/local/ym_import/start', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token, sessionId }),
      });
      const data = await resp.json();
      Utils.log('info', '[YM Import] Server response: ' + JSON.stringify(data));
      if (!data.ok) {
        
        if (data.error === 'Импорт уже запущен') {
          this._checkPausedState();
          if (startBtn) { startBtn.style.display = 'none'; }
          if (tokenInput) tokenInput.disabled = true;
          this._startPolling();
          return;
        }
        this._showError(data.error || 'Ошибка запуска');
        if (startBtn) { startBtn.disabled = false; startBtn.textContent = 'Начать импорт'; }
        if (tokenInput) tokenInput.disabled = false;
        return;
      }
    } catch (e) {
      Utils.log('error', '[YM Import] Fetch error: ' + e.message);
      this._showError('Ошибка соединения с сервером: ' + e.message);
      if (startBtn) { startBtn.disabled = false; startBtn.textContent = 'Начать импорт'; }
      if (tokenInput) tokenInput.disabled = false;
      return;
    }

    if (startBtn) startBtn.style.display = 'none';
    if (progSec) progSec.style.display = 'block';
    if (closeBtn) closeBtn.textContent = 'Приостановить импорт';
    this._likingPlaylistSynced = false; 

    
    const pauseMsg = document.getElementById('ym-pause-msg');
    if (pauseMsg) pauseMsg.style.display = 'none';

    this._startPolling();
  },

  async resumeImport() {
    const resumeBtn = document.getElementById('ym-resume-btn');
    const closeBtn = document.getElementById('ym-close-btn');
    const pauseMsg = document.getElementById('ym-pause-msg');

    if (resumeBtn) { resumeBtn.disabled = true; resumeBtn.textContent = 'Возобновление...'; }

    try {
      const resp = await fetch('/local/ym_import/resume', { method: 'POST' });
      const data = await resp.json();
      if (!data.ok) {
        if (data.error === 'Импорт не приостановлен') {
          
          if (pauseMsg) {
            pauseMsg.style.display = 'block';
            pauseMsg.innerHTML = '<span style="color:#ff9800">Лимит ещё не снят! Повторите позже!</span>';
          }
        } else {
          this._showError(data.error || 'Ошибка');
        }
        if (resumeBtn) { resumeBtn.disabled = false; resumeBtn.textContent = 'Продолжить импорт'; }
        return;
      }
    } catch (e) {
      this._showError('Ошибка соединения');
      if (resumeBtn) { resumeBtn.disabled = false; resumeBtn.textContent = 'Продолжить импорт'; }
      return;
    }

    if (resumeBtn) resumeBtn.style.display = 'none';
    if (closeBtn) closeBtn.textContent = 'Приостановить импорт';
    if (pauseMsg) pauseMsg.style.display = 'none';

    const progSec = document.getElementById('ym-progress-section');
    if (progSec) progSec.style.display = 'block';
    const text = document.getElementById('ym-progress-text');
    if (text) { text.textContent = 'Продолжаем поиск и лайки...'; text.style.color = ''; }

    this._startPolling();
  },

  _startPolling() {
    this._stopPolling();
    
    this._polling = setInterval(() => this._pollStatus(), 3000);
  },

  _stopPolling() {
    if (this._polling) { clearInterval(this._polling); this._polling = null; }
    this._pollDomRefs = null; 
  },

  async _pollStatus() {
    let resp;
    try {
      resp = await fetch('/local/ym_import/status');
      const s = await resp.json();

      
      if (!this._pollDomRefs) {
        this._pollDomRefs = {
          fill: document.getElementById('ym-progress-fill'),
          text: document.getElementById('ym-progress-text'),
          foundEl: document.getElementById('ym-found'),
          missingEl: document.getElementById('ym-missing'),
          skippedEl: document.getElementById('ym-skipped'),
        };
      }
      const { fill, text, foundEl, missingEl, skippedEl } = this._pollDomRefs;

      if (s.status === 'fetching') {
        if (text) text.textContent = 'Получение лайкнутых треков из Яндекс Музыки...';
        if (fill) fill.style.width = '5%';
      } else if (s.status === 'searching') {
        const autoSkip = s.auto_skipped || 0;
        const searchTotal = s.total - autoSkip;
        const searched = s.progress - autoSkip;
        const pct = searchTotal > 0 ? Math.round((searched / searchTotal) * 100) : 0;
        if (fill) { fill.style.width = Math.min(100, pct) + '%'; fill.style.background = ''; }
        if (text) text.textContent = 'Поиск треков в SoundCloud: ' + searched + ' / ' + searchTotal;
        if (foundEl) foundEl.textContent = 'Найдено: ' + (s.found || 0);
        if (missingEl) missingEl.textContent = 'Не найдено: ' + s.not_found;
        if (skippedEl) {
          const parts = [];
          if (autoSkip > 0) parts.push('Уже в плейлисте: ' + autoSkip);
          if ((s.skipped || 0) > 0) parts.push('Уже лайкнуто в SC: ' + s.skipped);
          if (parts.length > 0) {
            skippedEl.textContent = parts.join('  ·  ');
            skippedEl.classList.add('visible');
          }
        }
        
        
      } else if (s.status === 'liking') {
        
        if (!this._likingPlaylistSynced) {
          this._likingPlaylistSynced = true;
          this._addPartialResultsToPlaylist();
          Utils.log('info', '[YM Import] Phase 2 started — synced all found tracks to playlist');
        }
        const likeTotal = s.like_total || 1;
        const likePct = Math.round((s.liked / likeTotal) * 100);
        if (fill) { fill.style.width = likePct + '%'; fill.style.background = 'linear-gradient(90deg, var(--accent), #ff9800)'; }
        if (text) text.textContent = 'Лайкаем треки в SoundCloud: ' + s.liked + ' / ' + likeTotal;
        if (foundEl) foundEl.textContent = 'Найдено: ' + (s.found || 0);
        if (missingEl) missingEl.textContent = 'Не найдено: ' + s.not_found;
        
        if (skippedEl) {
          const autoSkip = s.auto_skipped || 0;
          const parts = [];
          if (autoSkip > 0) parts.push('Уже в плейлисте: ' + autoSkip);
          if ((s.skipped || 0) > 0) parts.push('Уже лайкнуто в SC: ' + s.skipped);
          if (parts.length > 0) {
            skippedEl.textContent = parts.join('  ·  ');
            skippedEl.classList.add('visible');
          }
        }
        
        if (s.liked > 0 && s.liked % 5 === 0) {
          this._triggerLikedRefresh();
        }
      } else if (s.status === 'paused') {
        this._stopPolling();
        this._onImportPaused(s);
      } else if (s.status === 'done') {
        this._stopPolling();
        this._onImportDone(s);
      } else if (s.status === 'error') {
        this._stopPolling();
        this._showError(s.error || 'Неизвестная ошибка');
      } else if (s.status === 'idle') {
        this._stopPolling();
      }
    } catch (e) {
      Utils.log('error', '[YM Import] Poll error: ' + e.message);
    }
  },

  
  _lastLikedRefresh: 0,
  _triggerLikedRefresh() {
    const now = Date.now();
    if (now - YandexImport._lastLikedRefresh < 10000) return;
    YandexImport._lastLikedRefresh = now;
    if (Store.get('currentPage') === 'home' && typeof HomePage !== 'undefined') {
      HomePage._loadLikedTracks();
    }
  },

  _onImportPaused(status) {
    const startBtn = document.getElementById('ym-start-btn');
    const resumeBtn = document.getElementById('ym-resume-btn');
    const closeBtn = document.getElementById('ym-close-btn');
    const pauseMsg = document.getElementById('ym-pause-msg');
    const foundEl = document.getElementById('ym-found');
    const missingEl = document.getElementById('ym-missing');

    if (startBtn) startBtn.style.display = 'none';
    if (resumeBtn) { resumeBtn.style.display = ''; resumeBtn.disabled = false; resumeBtn.textContent = 'Продолжить лайки'; }
    if (closeBtn) closeBtn.textContent = 'Закрыть';
    if (foundEl) foundEl.textContent = `Найдено: ${status.found || 0}`;
    if (missingEl) missingEl.textContent = `Не найдено: ${status.not_found}`;

    if (pauseMsg) {
      pauseMsg.style.display = 'block';
      const liked = status.liked || 0;
      const found = status.found || 0;
      pauseMsg.innerHTML = `<span style="color:#ff9800">Все треки найдены и добавлены в плейлист «Яндекс Музыка» (<strong>${found}</strong> треков).<br>Лайкнуто: <strong>${liked}</strong>. К сожалению, SoundCloud не может лайкать так много треков за короткое время. Через пару часов вы сможете продолжить!</span>`;
    }

    
    this._refreshNotFound();
    
    this._triggerLikedRefresh();

    
    this._addPartialResultsToPlaylist().then(playlistId => {
      if (playlistId && pauseMsg) {
        pauseMsg.innerHTML += `<br><small style="color:rgba(255,255,255,0.55);margin-top:6px;display:block">Все найденные треки перенесены в <a onclick="YandexImport._goToYmPlaylist('${playlistId}')" style="color:var(--accent);cursor:pointer;text-decoration:underline">плейлист «Яндекс Музыка» →</a></small>`;
      }
    });
  },

  
  async _addPartialResultsToPlaylist() {
    try {
      const resp = await fetch('/local/ym_import/results');
      const data = await resp.json();
      const tracks = data.tracks || [];
      if (tracks.length === 0) return null;

      let playlists = [...(Store.get('playlists') || [])];
      let playlist = playlists.find(p => p.title === 'Яндекс Музыка' || p.isYandex);
      if (!playlist) {
        playlist = {
          id: Math.random().toString(36).substr(2,9) + Date.now().toString(36),
          title: 'Яндекс Музыка',
          tracks: [],
          createdAt: new Date().toISOString(),
          isYandex: true,
        };
        playlists.push(playlist);
      }

      
      const existingUrns = new Set((playlist.tracks || []).map(t => t.urn || ''));
      const existingIds = new Set((playlist.tracks || []).map(t => t.id).filter(Boolean));
      const newTracks = [];

      for (const t of tracks) {
        if (!t || (!t.urn && !t.id)) continue;
        const urn = t.urn || `soundcloud:tracks:${t.id}`;
        if (existingUrns.has(urn) || (t.id && existingIds.has(t.id))) continue;
        newTracks.push({
          urn, id: t.id, title: t.title || '', user: t.user || { username: '' },
          artwork_url: t.artwork_url || null, duration: t.duration || 0,
          permalink_url: t.permalink_url || '', source: 'soundcloud',
          playback_count: t.playback_count ?? 0,
          favoritings_count: t.favoritings_count ?? t.likes_count ?? 0,
          likes_count: t.likes_count ?? t.favoritings_count ?? 0,
          genre: t.genre || '',
        });
      }

      if (newTracks.length > 0) {
        
        const updatedPlaylists = playlists.map(p =>
          (p.id === playlist.id) ? { ...p, tracks: [...newTracks, ...(p.tracks || [])], isYandex: true } : p
        );
        Store.set({ playlists: updatedPlaylists });
        Utils.log('info', `[YM Import] Batch-added ${newTracks.length} tracks to YM playlist (1 persist)`);
      }

      return playlist.id;
    } catch (e) { Utils.log('error', '[YM Import] _addPartialResults error: ' + e.message); return null; }
  },

  async _onImportDone(status) {
    try {
      const resp = await fetch('/local/ym_import/results');
      const data = await resp.json();
      const tracks = data.tracks || [];
      const notFound = data.not_found_list || [];
      const liked = status.liked || 0;

      
      this._notFoundList = notFound;
      if (notFound.length > 0) {
        const settings = Store.get('settings') || {};
        if (settings.showYmImportTab === undefined) settings.showYmImportTab = true;
        Store.set({ settings });
      }
      this._updateSidebarTab();

      let playlistId = null;
      if (tracks.length > 0) {
        
        playlistId = await this._addPartialResultsToPlaylist();
        Utils.log('info', `[YM Import] Done: batch-synced ${tracks.length} tracks to YM playlist`);
      }

      const doneMsg = document.getElementById('ym-done-msg');
      const progSec = document.getElementById('ym-progress-section');
      const closeBtn = document.getElementById('ym-close-btn');
      const pauseMsg = document.getElementById('ym-pause-msg');

      if (progSec) progSec.style.display = 'none';
      if (pauseMsg) pauseMsg.style.display = 'none';
      if (doneMsg) {
        doneMsg.style.display = 'block';
        let likedText = '';
        if (liked > 0) likedText = `<br><strong style="color:#4caf50">${liked}</strong> треков лайкнуто в SoundCloud`;
        const playlistLinkHtml = playlistId
          ? `<br><span style="color:rgba(255,255,255,0.6);margin-top:8px;display:inline-block">Все треки перенесены в <a onclick="YandexImport._goToYmPlaylist('${playlistId}')" style="color:var(--accent);cursor:pointer;text-decoration:underline">плейлист «Яндекс Музыка» →</a></span>`
          : '';
        doneMsg.innerHTML = `
          <strong>${tracks.length}</strong> треков найдено и добавлено в плейлист «Яндекс Музыка»
          ${likedText}
          ${notFound.length > 0 ? '<br><span style="color:rgba(255,255,255,0.3)">' + notFound.length + ' треков не найдено в SoundCloud</span>' : ''}
          ${playlistLinkHtml}
        `;
      }
      if (closeBtn) closeBtn.textContent = 'Закрыть';

      
      if (Store.get('currentPage') === 'home' && typeof HomePage !== 'undefined') {
        HomePage._loadLikedTracks();
      }
      if (typeof SoundWave !== 'undefined' && SoundWave.isActive()) {
        SoundWave._userLikedUrns = null;
      }

      await fetch('/local/ym_import/reset', { method: 'POST' });

    } catch (e) {
      Utils.log('error', '[YM Import] Results error: ' + e.message);
      this._showError('Ошибка получения результатов');
    }
  },

  async _pauseImport() {
    this._stopPolling();
    try {
      await fetch('/local/ym_import/cancel', { method: 'POST' });
    } catch (e) {}
  },

  _showError(msg) {
    Utils.log('error', '[YM Import] Error: ' + msg);
    
    const progSec = document.getElementById('ym-progress-section');
    if (progSec) progSec.style.display = 'block';
    const text = document.getElementById('ym-progress-text');
    if (text) {
      text.textContent = msg;
      text.style.color = '#ff5252';
    }
    const startBtn = document.getElementById('ym-start-btn');
    if (startBtn) { startBtn.disabled = false; startBtn.textContent = 'Повторить'; startBtn.style.display = ''; }
    const tokenInput = document.getElementById('ym-token-input');
    if (tokenInput) tokenInput.disabled = false;
    const closeBtn = document.getElementById('ym-close-btn');
    if (closeBtn) closeBtn.textContent = 'Закрыть';
  },

  
  async _cancelImport() {
    this._stopPolling();
    try {
      await fetch('/local/ym_import/cancel', { method: 'POST' });
    } catch (e) {}
  },
};
