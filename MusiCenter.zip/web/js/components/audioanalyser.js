

const AudioAnalyser = {
  _analyser: null,
  _ctx: null,
  _connected: false,
  _fftSize: 2048,
  _smoothing: 0.8,

  
  _freqData: null,      
  _freqDataRaw: null,   
  _timeData: null,       
  _prevSpectrum: null,   

  
  _history: [],          
  _historyMax: 100,      
  _analysisInterval: null,
  _analysisRate: 10,     

  
  _current: null,

  
  _trackFeatures: null,  
  _trackUrn: null,
  _trackFrames: 0,
  _trackStartTime: 0,

  
  _onsetTimes: [],        
  _fluxHistory: [],       
  _fluxMedian: 0,         
  _lastOnsetTime: 0,      
  _bpmCache: new Map(),   
  _bpmCacheMax: 500,

  
  _cache: new Map(),
  _cacheMax: 500,

  
  init(ctx, connectAfterNode) {
    if (this._connected) return;
    if (!ctx) {
      Utils.log('warning', '[AudioAnalyser] No AudioContext provided');
      return;
    }
    this._ctx = ctx;

    try {
      this._analyser = ctx.createAnalyser();
      this._analyser.fftSize = this._fftSize;
      this._analyser.smoothingTimeConstant = this._smoothing;
      this._analyser.minDecibels = -90;
      this._analyser.maxDecibels = -10;

      
      if (connectAfterNode) {
        connectAfterNode.connect(this._analyser);
      }

      const bins = this._analyser.frequencyBinCount; 
      this._freqData = new Float32Array(bins);
      this._freqDataRaw = new Uint8Array(bins);
      this._timeData = new Float32Array(this._fftSize);
      this._prevSpectrum = new Float32Array(bins);

      this._connected = true;
      this._startAnalysis();

      Utils.log('info', `[AudioAnalyser] ✓ Connected — FFT=${this._fftSize}, bins=${bins}, rate=${this._analysisRate}Hz`);
    } catch (e) {
      Utils.log('error', '[AudioAnalyser] Init failed: ' + e.message);
    }
  },

  
  _startAnalysis() {
    if (this._analysisInterval) return;
    this._analysisInterval = setInterval(() => this._analyse(), 1000 / this._analysisRate);
    Utils.log('info', '[AudioAnalyser] Analysis loop started');
  },

  _stopAnalysis() {
    if (this._analysisInterval) {
      clearInterval(this._analysisInterval);
      this._analysisInterval = null;
    }
  },

  
  _analyse() {
    if (!this._connected || !this._analyser) return;

    
    this._analyser.getFloatFrequencyData(this._freqData);
    this._analyser.getFloatTimeDomainData(this._timeData);
    this._analyser.getByteFrequencyData(this._freqDataRaw);

    const sampleRate = this._ctx.sampleRate || 44100;
    const bins = this._analyser.frequencyBinCount;
    const binWidth = sampleRate / this._fftSize; 

    
    const magnitude = new Float32Array(bins);
    let totalMag = 0;
    for (let i = 0; i < bins; i++) {
      
      const db = this._freqData[i];
      magnitude[i] = db > -90 ? Math.pow(10, db / 20) : 0;
      totalMag += magnitude[i];
    }

    
    let sumSq = 0;
    for (let i = 0; i < this._timeData.length; i++) {
      sumSq += this._timeData[i] * this._timeData[i];
    }
    const rmsEnergy = Math.sqrt(sumSq / this._timeData.length);

    
    let weightedSum = 0;
    for (let i = 0; i < bins; i++) {
      weightedSum += (i * binWidth) * magnitude[i];
    }
    const centroidHz = totalMag > 0 ? weightedSum / totalMag : 0;
    
    const centroidNorm = centroidHz / (sampleRate / 2);

    
    let spreadSum = 0;
    for (let i = 0; i < bins; i++) {
      const diff = (i * binWidth) - centroidHz;
      spreadSum += diff * diff * magnitude[i];
    }
    const spreadHz = totalMag > 0 ? Math.sqrt(spreadSum / totalMag) : 0;
    const spreadNorm = spreadHz / (sampleRate / 2);

    
    let logSum = 0;
    let arithmeticMean = 0;
    let nonZero = 0;
    for (let i = 0; i < bins; i++) {
      if (magnitude[i] > 1e-10) {
        logSum += Math.log(magnitude[i]);
        nonZero++;
      }
      arithmeticMean += magnitude[i];
    }
    arithmeticMean /= bins;
    const geometricMean = nonZero > 0 ? Math.exp(logSum / nonZero) : 0;
    const flatness = arithmeticMean > 1e-10 ? geometricMean / arithmeticMean : 0;

    
    const totalEnergy = magnitude.reduce((a, b) => a + b, 0);
    const threshold85 = totalEnergy * 0.85;
    let cumEnergy = 0;
    let rolloffBin = 0;
    for (let i = 0; i < bins; i++) {
      cumEnergy += magnitude[i];
      if (cumEnergy >= threshold85) { rolloffBin = i; break; }
    }
    const rolloffHz = rolloffBin * binWidth;
    const rolloffNorm = rolloffHz / (sampleRate / 2);

    
    let flux = 0;
    for (let i = 0; i < bins; i++) {
      const diff = magnitude[i] - (this._prevSpectrum[i] || 0);
      flux += diff * diff;
    }
    flux = Math.sqrt(flux / bins);
    
    this._prevSpectrum.set(magnitude);

    
    let zcr = 0;
    for (let i = 1; i < this._timeData.length; i++) {
      if ((this._timeData[i] >= 0 && this._timeData[i - 1] < 0) ||
          (this._timeData[i] < 0 && this._timeData[i - 1] >= 0)) {
        zcr++;
      }
    }
    const zcrNorm = zcr / this._timeData.length;

    
    const brightnessCutoff = Math.floor(1500 / binWidth);
    let highEnergy = 0;
    for (let i = brightnessCutoff; i < bins; i++) highEnergy += magnitude[i];
    const brightness = totalEnergy > 0 ? highEnergy / totalEnergy : 0;

    
    const lowCut = Math.floor(300 / binWidth);
    const midCut = Math.floor(2000 / binWidth);
    let lowE = 0, midE = 0, highE = 0;
    for (let i = 0; i < bins; i++) {
      const e = magnitude[i] * magnitude[i];
      if (i < lowCut) lowE += e;
      else if (i < midCut) midE += e;
      else highE += e;
    }
    const bandTotal = lowE + midE + highE || 1;
    const lowRatio = lowE / bandTotal;
    const midRatio = midE / bandTotal;
    const highRatio = highE / bandTotal;

    
    const snapshot = {
      ts: Date.now(),
      rmsEnergy,
      centroid: centroidNorm,
      centroidHz,
      spread: spreadNorm,
      flatness: Math.min(1, flatness),
      rolloff: rolloffNorm,
      rolloffHz,
      flux,
      zcr: zcrNorm,
      brightness,
      lowRatio,
      midRatio,
      highRatio,
    };

    this._current = snapshot;

    
    this._history.push(snapshot);
    if (this._history.length > this._historyMax) this._history.shift();

    
    if (this._trackUrn) {
      this._trackFrames++;
      if (!this._trackFeatures) {
        this._trackFeatures = { ...snapshot, min_energy: rmsEnergy, max_energy: rmsEnergy };
      } else {
        const tf = this._trackFeatures;
        const n = this._trackFrames;
        
        tf.rmsEnergy   = tf.rmsEnergy * (n-1)/n + rmsEnergy / n;
        tf.centroid     = tf.centroid * (n-1)/n + centroidNorm / n;
        tf.spread       = tf.spread * (n-1)/n + spreadNorm / n;
        tf.flatness     = tf.flatness * (n-1)/n + flatness / n;
        tf.rolloff      = tf.rolloff * (n-1)/n + rolloffNorm / n;
        tf.flux         = tf.flux * (n-1)/n + flux / n;
        tf.zcr          = tf.zcr * (n-1)/n + zcrNorm / n;
        tf.brightness   = tf.brightness * (n-1)/n + brightness / n;
        tf.lowRatio     = tf.lowRatio * (n-1)/n + lowRatio / n;
        tf.midRatio     = tf.midRatio * (n-1)/n + midRatio / n;
        tf.highRatio    = tf.highRatio * (n-1)/n + highRatio / n;
        tf.min_energy   = Math.min(tf.min_energy, rmsEnergy);
        tf.max_energy   = Math.max(tf.max_energy, rmsEnergy);
      }

      
      this._fluxHistory.push(flux);
      if (this._fluxHistory.length > 30) this._fluxHistory.shift(); 

      if (this._fluxHistory.length >= 5) {
        
        const sorted = [...this._fluxHistory].sort((a, b) => a - b);
        this._fluxMedian = sorted[Math.floor(sorted.length / 2)];
        const threshold = this._fluxMedian * 2.5 + 0.002; 

        const now = Date.now();
        const prev1 = this._fluxHistory[this._fluxHistory.length - 2] || 0;
        const prev2 = this._fluxHistory[this._fluxHistory.length - 3] || 0;

        
        if (flux > threshold && flux > prev1 && flux >= prev2 && (now - this._lastOnsetTime) > 200) {
          this._onsetTimes.push(now);
          this._lastOnsetTime = now;
          
          if (this._onsetTimes.length > 60) this._onsetTimes.shift();
        }
      }
    }
  },

  
  onTrackStart(urn) {
    
    if (this._trackUrn && this._trackFrames > 20) {
      this._finalizeTrack();
    }
    this._trackUrn = urn;
    this._trackFrames = 0;
    this._trackFeatures = null;
    this._trackStartTime = Date.now();
    this._history = [];
    
    this._onsetTimes = [];
    this._fluxHistory = [];
    this._fluxMedian = 0;
    this._lastOnsetTime = 0;
    Utils.log('info', `[AudioAnalyser] Track start: ${urn?.slice(-12) || '?'}`);
  },

  _finalizeTrack() {
    if (!this._trackUrn || !this._trackFeatures || this._trackFrames < 20) return;
    const tf = this._trackFeatures;

    
    const mood = this._computeMood(tf);
    tf.valence = mood.valence;
    tf.arousal = mood.arousal;
    tf.frames = this._trackFrames;
    tf.durationAnalysed = (Date.now() - this._trackStartTime) / 1000;

    
    tf.detectedBPM = 0;
    if (this._onsetTimes.length >= 8) {
      
      const iois = [];
      for (let i = 1; i < this._onsetTimes.length; i++) {
        iois.push(this._onsetTimes[i] - this._onsetTimes[i - 1]);
      }
      
      const validIOIs = iois.filter(d => d >= 300 && d <= 1200);
      if (validIOIs.length >= 4) {
        
        const bins = {};
        for (const ioi of validIOIs) {
          const bin = Math.round(ioi / 10) * 10;
          bins[bin] = (bins[bin] || 0) + 1;
        }
        
        let bestBin = 0, bestCount = 0;
        for (const [bin, count] of Object.entries(bins)) {
          
          const halfBin = Math.round(bin / 2 / 10) * 10;
          const totalCount = count + (bins[halfBin] || 0) * 0.5;
          if (totalCount > bestCount) { bestCount = totalCount; bestBin = parseInt(bin); }
        }
        if (bestBin > 0) {
          tf.detectedBPM = Math.round(60000 / bestBin);
          
          if (tf.detectedBPM < 70) tf.detectedBPM *= 2;
          if (tf.detectedBPM > 200) tf.detectedBPM = Math.round(tf.detectedBPM / 2);
        }
      }
    }

    
    if (tf.detectedBPM > 0) {
      this._bpmCache.set(this._trackUrn, tf.detectedBPM);
      if (this._bpmCache.size > this._bpmCacheMax) {
        const firstKey = this._bpmCache.keys().next().value;
        this._bpmCache.delete(firstKey);
      }
    }

    
    this._cache.set(this._trackUrn, tf);
    if (this._cache.size > this._cacheMax) {
      const firstKey = this._cache.keys().next().value;
      this._cache.delete(firstKey);
    }

    Utils.log('info', `[AudioAnalyser] ★ Track finalized: ${this._trackUrn.slice(-12)} | ` +
      `V=${mood.valence.toFixed(2)} A=${mood.arousal.toFixed(2)} | ` +
      `E=${tf.rmsEnergy.toFixed(3)} C=${tf.centroid.toFixed(3)} F=${tf.flatness.toFixed(3)} ` +
      `R=${tf.rolloff.toFixed(3)} B=${tf.brightness.toFixed(3)} | ` +
      `BPM=${tf.detectedBPM || '?'} (${this._onsetTimes.length} onsets) | ${this._trackFrames} frames`);

    return tf;
  },

  
  _computeMood(features) {
    const { rmsEnergy, centroid, spread, flatness, rolloff, flux, zcr, brightness,
            lowRatio, midRatio, highRatio, min_energy, max_energy } = features;

    
    let arousal = 0;
    
    arousal += Math.min(1, rmsEnergy * 8) * 0.28;
    
    arousal += Math.min(1, centroid * 5) * 0.18;
    
    arousal += Math.min(1, flux * 50) * 0.15;
    
    arousal += Math.min(1, zcr * 8) * 0.10;
    
    arousal += brightness * 0.08;
    
    const dynamicRange = (max_energy - min_energy) || 0;
    arousal += Math.min(1, dynamicRange * 5) * 0.10;
    
    arousal += rolloff * 0.04;
    
    arousal += midRatio * 0.07;

    
    let valence = 0.5; 

    
    valence += (centroid - 0.15) * 1.3;

    
    valence += (flatness - 0.3) * 0.45;

    
    valence -= (lowRatio - 0.3) * 0.7;

    
    valence += (brightness - 0.4) * 0.55;

    
    valence += (spread - 0.1) * 0.25;

    
    valence += (rolloff - 0.3) * 0.35;

    
    valence += (highRatio - 0.2) * 0.3;

    
    if (rmsEnergy < 0.08 && centroid < 0.12) valence -= 0.15; 
    if (rmsEnergy > 0.15 && centroid > 0.2) valence += 0.1;   
    
    if (rmsEnergy < 0.06 && flatness < 0.15 && lowRatio > 0.4) valence -= 0.12;

    
    arousal = Math.max(0, Math.min(1, arousal));
    valence = Math.max(0, Math.min(1, valence));

    return { valence, arousal };
  },

  
  getTrackFeatures(urn) {
    return this._cache.get(urn) || null;
  },

  
  getCurrent() {
    return this._current;
  },

  
  getAverage(frames = 50) {
    if (this._history.length === 0) return null;
    const slice = this._history.slice(-frames);
    const avg = {};
    const keys = ['rmsEnergy','centroid','spread','flatness','rolloff','flux','zcr','brightness',
                  'lowRatio','midRatio','highRatio'];
    for (const k of keys) {
      avg[k] = slice.reduce((s, f) => s + (f[k] || 0), 0) / slice.length;
    }
    return avg;
  },

  
  moodScore(trackUrn, targetPreset) {
    const features = this._cache.get(trackUrn);
    if (!features || !features.valence) return 0; 

    const { valence, arousal, rmsEnergy, centroid, flatness, rolloff,
            brightness, flux, zcr, lowRatio } = features;

    
    const PROFILES = {
      
      
      sad: {
        targetV: 0.15, targetA: 0.20,
        centroid: [0.02, 0.12],    
        energy: [0.01, 0.08],      
        flatness: [0.0, 0.20],     
        brightness: [0.05, 0.30],  
        rolloff: [0.03, 0.20],     
        flux: [0.0, 0.008],        
        lowRatio: [0.30, 0.70],    
        weight: 2.0,               
      },
      
      happy: {
        targetV: 0.85, targetA: 0.65,
        centroid: [0.12, 0.40],    
        energy: [0.06, 0.25],      
        flatness: [0.15, 0.50],    
        brightness: [0.35, 0.75],  
        rolloff: [0.20, 0.55],     
        flux: [0.005, 0.04],       
        lowRatio: [0.10, 0.35],    
        weight: 1.5,
      },
      
      calm: {
        targetV: 0.58, targetA: 0.15,
        centroid: [0.04, 0.18],    
        energy: [0.008, 0.07],     
        flatness: [0.05, 0.40],    
        brightness: [0.10, 0.40],  
        rolloff: [0.05, 0.25],     
        flux: [0.0, 0.006],        
        lowRatio: [0.20, 0.50],    
        weight: 1.5,
      },
      
      energetic: {
        targetV: 0.65, targetA: 0.92,
        centroid: [0.18, 0.55],    
        energy: [0.12, 0.50],      
        flatness: [0.20, 0.70],    
        brightness: [0.40, 0.85],  
        rolloff: [0.25, 0.65],     
        flux: [0.01, 0.12],        
        lowRatio: [0.08, 0.30],    
        weight: 1.5,
      },
      
      
      sleep: {
        targetV: 0.35, targetA: 0.06,
        centroid: [0.01, 0.10],    
        energy: [0.003, 0.04],     
        flatness: [0.0, 0.18],     
        brightness: [0.03, 0.25],  
        rolloff: [0.02, 0.15],     
        flux: [0.0, 0.004],        
        lowRatio: [0.25, 0.60],    
        weight: 2.5,               
      },
      
      
      wakeup: {
        targetV: 0.62, targetA: 0.30,
        centroid: [0.06, 0.25],    
        energy: [0.03, 0.12],      
        flatness: [0.08, 0.35],    
        brightness: [0.20, 0.50],  
        rolloff: [0.10, 0.35],     
        flux: [0.002, 0.02],       
        lowRatio: [0.15, 0.45],    
        weight: 1.2,
      },
      
      
      work: {
        targetV: 0.48, targetA: 0.25,
        centroid: [0.04, 0.22],    
        energy: [0.01, 0.10],      
        flatness: [0.10, 0.55],    
        brightness: [0.15, 0.45],  
        rolloff: [0.08, 0.30],     
        flux: [0.0, 0.008],        
        lowRatio: [0.15, 0.50],    
        weight: 1.8,               
      },
      
      
      workout: {
        targetV: 0.55, targetA: 0.95,
        centroid: [0.20, 0.55],    
        energy: [0.14, 0.50],      
        flatness: [0.25, 0.80],    
        brightness: [0.45, 0.90],  
        rolloff: [0.30, 0.70],     
        flux: [0.02, 0.15],        
        lowRatio: [0.08, 0.28],    
        weight: 1.5,
      },
      
      
      commute: {
        targetV: 0.62, targetA: 0.50,
        centroid: [0.08, 0.30],    
        energy: [0.04, 0.18],      
        flatness: [0.12, 0.50],    
        brightness: [0.25, 0.60],  
        rolloff: [0.12, 0.45],     
        flux: [0.004, 0.03],       
        lowRatio: [0.15, 0.40],    
        weight: 1.0,
      },
    };

    const profile = PROFILES[targetPreset];
    if (!profile) return 0;

    let score = 0;

    
    const vDist = Math.abs(valence - profile.targetV);
    const aDist = Math.abs(arousal - profile.targetA);
    const dist = Math.sqrt(vDist * vDist + aDist * aDist);
    if (dist < 0.2) score += 6;
    else if (dist < 0.35) score += 3;
    else if (dist > 0.6) score -= 6;
    else if (dist > 0.45) score -= 3;

    
    const featureChecks = [
      ['centroid', centroid], ['energy', rmsEnergy], ['flatness', flatness],
      ['brightness', brightness], ['rolloff', rolloff], ['flux', flux],
      ['lowRatio', lowRatio],
    ];
    for (const [name, val] of featureChecks) {
      const range = profile[name];
      if (!range) continue;
      if (val >= range[0] && val <= range[1]) {
        score += 1; 
      } else {
        const distFromRange = val < range[0] ? range[0] - val : val - range[1];
        score -= distFromRange * 8; 
      }
    }

    return score * profile.weight;
  },

  
  getVectorEnrichment(urn) {
    const f = this._cache.get(urn);
    if (!f) return null;

    const v = new Float32Array(8);
    v[0] = Math.min(1, f.rmsEnergy * 8);        
    v[1] = Math.min(1, f.centroid * 5);           
    v[2] = f.brightness;                           
    v[3] = f.flatness;                             
    v[4] = Math.min(1, f.rolloff * 2);            
    v[5] = Math.min(1, f.flux * 100);             
    v[6] = f.valence || 0.5;                       
    v[7] = f.arousal || 0.5;                       
    return v;
  },

  
  getDetectedBPM(urn) {
    if (!urn) return 0;
    
    if (this._bpmCache.has(urn)) return this._bpmCache.get(urn);
    
    const f = this._cache.get(urn);
    return f?.detectedBPM || 0;
  },

  
  getLiveBPM() {
    if (this._onsetTimes.length < 6) return 0;
    
    const recent = this._onsetTimes.slice(-20);
    const iois = [];
    for (let i = 1; i < recent.length; i++) {
      const d = recent[i] - recent[i - 1];
      if (d >= 300 && d <= 1200) iois.push(d);
    }
    if (iois.length < 4) return 0;
    
    iois.sort((a, b) => a - b);
    const medianIOI = iois[Math.floor(iois.length / 2)];
    let bpm = Math.round(60000 / medianIOI);
    if (bpm < 70) bpm *= 2;
    if (bpm > 200) bpm = Math.round(bpm / 2);
    return bpm;
  },

  
  getSpectrum() {
    if (!this._freqDataRaw) return null;
    return this._freqDataRaw; 
  },

  getWaveform() {
    if (!this._timeData) return null;
    return this._timeData;
  },

  
  getStats() {
    return {
      connected: this._connected,
      cachedTracks: this._cache.size,
      bpmCached: this._bpmCache.size,
      currentTrack: this._trackUrn,
      currentFrames: this._trackFrames,
      currentOnsets: this._onsetTimes.length,
      liveBPM: this.getLiveBPM(),
      historyLength: this._history.length,
    };
  },

  logStats() {
    const s = this.getStats();
    Utils.log('info', `[AudioAnalyser] cached=${s.cachedTracks}, bpmCached=${s.bpmCached}, current=${s.currentTrack?.slice(-12)||'none'}, frames=${s.currentFrames}, onsets=${s.currentOnsets}, liveBPM=${s.liveBPM}`);
    if (this._current) {
      const c = this._current;
      Utils.log('info', `[AudioAnalyser] LIVE: E=${c.rmsEnergy.toFixed(3)} C=${c.centroid.toFixed(3)} ` +
        `F=${c.flatness.toFixed(3)} R=${c.rolloff.toFixed(3)} B=${c.brightness.toFixed(3)} ` +
        `Flux=${c.flux.toFixed(4)} ZCR=${c.zcr.toFixed(3)}`);
    }
  },
};
