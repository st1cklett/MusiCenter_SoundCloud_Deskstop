

const SWICONS = {
  sun: `<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="currentColor" viewBox="0 0 16 16"><path d="M8 11a3 3 0 1 1 0-6 3 3 0 0 1 0 6m0 1a4 4 0 1 0 0-8 4 4 0 0 0 0 8M8 0a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 0m0 13a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 13m8-5a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2a.5.5 0 0 1 .5.5M3 8a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2A.5.5 0 0 1 3 8m10.657-5.657a.5.5 0 0 1 0 .707l-1.414 1.415a.5.5 0 1 1-.707-.708l1.414-1.414a.5.5 0 0 1 .707 0m-9.193 9.193a.5.5 0 0 1 0 .707L3.05 13.657a.5.5 0 0 1-.707-.707l1.414-1.414a.5.5 0 0 1 .707 0m9.193 2.121a.5.5 0 0 1-.707 0l-1.414-1.414a.5.5 0 0 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .707M4.464 4.465a.5.5 0 0 1-.707 0L2.343 3.05a.5.5 0 1 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .708"/></svg>`,
  car: `<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="currentColor" viewBox="0 0 16 16"><path d="M4 9a1 1 0 1 1-2 0 1 1 0 0 1 2 0m10 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0M6 8a1 1 0 0 0 0 2h4a1 1 0 1 0 0-2zM4.862 4.276 3.906 6.19a.51.51 0 0 0 .497.731c.91-.073 2.35-.17 3.597-.17s2.688.097 3.597.17a.51.51 0 0 0 .497-.731l-.956-1.913A.5.5 0 0 0 10.691 4H5.309a.5.5 0 0 0-.447.276"/><path d="M2.52 3.515A2.5 2.5 0 0 1 4.82 2h6.362c1 0 1.904.596 2.298 1.515l.792 1.848c.075.175.21.319.38.404.5.25.855.715.965 1.262l.335 1.679q.05.242.049.49v.413c0 .814-.39 1.543-1 1.997V13.5a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1-.5-.5v-1.338c-1.292.048-2.745.088-4 .088s-2.708-.04-4-.088V13.5a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1-.5-.5v-1.892c-.61-.454-1-1.183-1-1.997v-.413a2.5 2.5 0 0 1 .049-.49l.335-1.68c.11-.546.465-1.012.964-1.261a.8.8 0 0 0 .381-.404l.792-1.848ZM4.82 3a1.5 1.5 0 0 0-1.379.91l-.792 1.847a1.8 1.8 0 0 1-.853.904.8.8 0 0 0-.43.564L1.03 8.904a1.5 1.5 0 0 0-.03.294v.413c0 .796.62 1.45 1.408 1.49l.01.001c1.548.07 3.312.12 4.58.12 1.27 0 3.034-.05 4.582-.12l.01-.001c.789-.04 1.408-.694 1.408-1.49v-.413a1.5 1.5 0 0 0-.03-.294l-.335-1.68a.8.8 0 0 0-.43-.563 1.8 1.8 0 0 1-.853-.904L11.36 3.91A1.5 1.5 0 0 0 9.98 3z"/></svg>`,
  laptop: `<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="currentColor" viewBox="0 0 16 16"><path d="M2.5 2A1.5 1.5 0 0 0 1 3.5V12h14V3.5A1.5 1.5 0 0 0 13.5 2zM0 12.5h16a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 0 12.5"/></svg>`,
  workout: `<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="currentColor" viewBox="0 0 24 24"><path d="M20.57 14.86L22 13.43 20.57 12 17 15.57 8.43 7 12 3.43 10.57 2 9.14 3.43 7.71 2 5.57 4.14 4.14 2.71 2.71 4.14l1.43 1.43L2 7.71l1.43 1.43L2 10.57 3.43 12 7 8.43 15.57 17 12 20.57 13.43 22l1.43-1.43L16.29 22l2.14-2.14 1.43 1.43 1.43-1.43-1.43-1.43L22 16.29z"/></svg>`,
  moon: `<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="currentColor" viewBox="0 0 16 16"><path d="M6 .278a.77.77 0 0 1 .08.858 7.2 7.2 0 0 0-.878 3.46c0 4.021 3.278 7.277 7.318 7.277q.792-.001 1.533-.16a.79.79 0 0 1 .81.316.73.73 0 0 1-.031.893A8.35 8.35 0 0 1 8.344 16C3.734 16 0 12.286 0 7.71 0 4.266 2.114 1.312 5.124.06A.75.75 0 0 1 6 .278M4.858 1.311A7.27 7.27 0 0 0 1.025 7.71c0 4.02 3.279 7.276 7.319 7.276a7.32 7.32 0 0 0 5.205-2.162q-.506.063-1.029.063c-4.61 0-8.343-3.714-8.343-8.29 0-1.167.242-2.278.681-3.286"/><path d="M10.794 3.148a.217.217 0 0 1 .412 0l.387 1.162c.173.518.579.924 1.097 1.097l1.162.387a.217.217 0 0 1 0 .412l-1.162.387a1.73 1.73 0 0 0-1.097 1.097l-.387 1.162a.217.217 0 0 1-.412 0l-.387-1.162A1.73 1.73 0 0 0 9.31 6.593l-1.162-.387a.217.217 0 0 1 0-.412l1.162-.387a1.73 1.73 0 0 0 1.097-1.097zM13.863.099a.145.145 0 0 1 .274 0l.258.774c.115.346.386.617.732.732l.774.258a.145.145 0 0 1 0 .274l-.774.258a1.16 1.16 0 0 0-.732.732l-.258.774a.145.145 0 0 1-.274 0l-.258-.774a1.16 1.16 0 0 0-.732-.732L9.1 2.137a.145.145 0 0 1 0-.274l.774-.258c.346-.115.617-.386.732-.732z"/></svg>`,
  heart: `<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="currentColor" viewBox="0 0 16 16"><path fill-rule="evenodd" d="M8 1.314C12.438-3.248 23.534 4.735 8 15-7.534 4.736 3.562-3.248 8 1.314"/></svg>`,
  stars: `<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="currentColor" viewBox="0 0 16 16"><path d="M7.657 6.247c.11-.33.576-.33.686 0l.645 1.937a2.89 2.89 0 0 0 1.829 1.828l1.936.645c.33.11.33.576 0 .686l-1.937.645a2.89 2.89 0 0 0-1.828 1.829l-.645 1.936a.361.361 0 0 1-.686 0l-.645-1.937a2.89 2.89 0 0 0-1.828-1.828l-1.937-.645a.361.361 0 0 1 0-.686l1.937-.645a2.89 2.89 0 0 0 1.828-1.828zM3.794 1.148a.217.217 0 0 1 .412 0l.387 1.162c.173.518.579.924 1.097 1.097l1.162.387a.217.217 0 0 1 0 .412l-1.162.387A1.73 1.73 0 0 0 4.593 5.69l-.387 1.162a.217.217 0 0 1-.412 0L3.407 5.69A1.73 1.73 0 0 0 2.31 4.593l-1.162-.387a.217.217 0 0 1 0-.412l1.162-.387A1.73 1.73 0 0 0 3.407 2.31zM10.863.099a.145.145 0 0 1 .274 0l.258.774c.115.346.386.617.732.732l.774.258a.145.145 0 0 1 0 .274l-.774.258a1.16 1.16 0 0 0-.732.732l-.258.774a.145.145 0 0 1-.274 0l-.258-.774a1.16 1.16 0 0 0-.732-.732L9.1 2.137a.145.145 0 0 1 0-.274l.774-.258c.346-.115.617-.386.732-.732z"/></svg>`,
  lightning: `<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="currentColor" viewBox="0 0 16 16"><path d="M5.52.359A.5.5 0 0 1 6 0h4a.5.5 0 0 1 .474.658L8.694 6H12.5a.5.5 0 0 1 .395.807l-7 9a.5.5 0 0 1-.873-.454L6.823 9.5H3.5a.5.5 0 0 1-.48-.641z"/></svg>`,
  music: `<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="currentColor" viewBox="0 0 16 16"><path d="M9 13c0 1.105-1.12 2-2.5 2S4 14.105 4 13s1.12-2 2.5-2 2.5.895 2.5 2"/><path fill-rule="evenodd" d="M9 3v10H8V3z"/><path d="M8 2.82a1 1 0 0 1 .804-.98l3-.6A1 1 0 0 1 13 2.22V4L8 5z"/></svg>`,
  waves: `<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M2 12c1-3 3-5 5-5s4 4 5 4 3-6 5-6 4 3 5 7"/></svg>`,
  sad: `<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="currentColor" viewBox="0 0 16 16"><path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14m0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16"/><path d="M4.285 12.433a.5.5 0 0 0 .683-.183A3.5 3.5 0 0 1 8 10.5c1.295 0 2.426.703 3.032 1.75a.5.5 0 0 0 .866-.5A4.5 4.5 0 0 0 8 9.5a4.5 4.5 0 0 0-3.898 2.25.5.5 0 0 0 .183.683M7 6.5C7 7.328 6.552 8 6 8s-1-.672-1-1.5S5.448 5 6 5s1 .672 1 1.5m4 0c0 .828-.448 1.5-1 1.5s-1-.672-1-1.5S9.448 5 10 5s1 .672 1 1.5"/></svg>`,
};


const SoundWave = {
  _active: false,
  _queue: [],
  _played: new Set(),
  _heardUrns: new Set(),
  _usedSeedUrns: new Set(),
  _globalHeard: new Set(),
  _tagOffsets: {},
  _seedTracks: [],
  _currentPreset: null,
  _pinTrack: null,
  _pendingPreset: null,  
  _pendingPin: null,     
  _genreWeights: {},
  _artistCounts: {},
  _sessionSeq: [],
  _loading: false,
  _starting: false,
  _animFrame: null,
  _blobColors: null,
  _blobsState: null,
  _diversityEnabled: true,
  _timeContextEnabled: true,
  _blacklist: new Set(),
  _artistBlacklist: new Set(),
  _lastKnownTrack: null,
  _nearEndLastCall: 0,

  
  _prefetchPool: [],         
  _prefetchUrns: new Set(),  
  _isPrefetching: false,     
  _batchCount: 0,            
  _maxBatchCycle: 5,         
  _prefetchTarget: 8,        
  _cycleResetting: false,    

  
  _bgPrefetchPool: [],       
  _bgPrefetching: false,     
  _bgPrefetchDone: false,    

  
  _mixedCache: [],      
  _mixInjectCounter: 0, 
  _mixLikedRecently: false, 
  _mixInjectedUrns: new Set(), 

  async _loadMixedCache() {
    try {
      
      if (this._seedTracks.length < 3) return;
      const picks = [];
      const used = new Set();
      for (let i = 0; i < 3 && i < this._seedTracks.length; i++) {
        const idx = Math.floor(Math.random() * this._seedTracks.length);
        if (used.has(idx)) continue;
        used.add(idx);
        picks.push(this._seedTracks[idx]);
      }
      const tracks = [];
      for (const seed of picks) {
        try {
          const rel = await API.getRelatedTracks(seed.urn, 15);
          (rel.collection || []).filter(t => t.urn && t.title).forEach(t => tracks.push(t));
        } catch {}
      }
      const seen = new Set();
      this._mixedCache = tracks.filter(t => { if (seen.has(t.urn)) return false; seen.add(t.urn); return true; });
      Utils.log('info', `[SW] Mixed cache: ${this._mixedCache.length} tracks from related`);
    } catch (e) {
      Utils.log('info', '[SW] Mixed cache build failed: ' + (e?.message || ''));
    }
  },

  
  _langProfile: { ru: 0, en: 0, other: 0 },
  _langCache: new Map(),

  _detectLang(text) {
    if (!text) return 'other';
    const cyr = (text.match(/[\u0400-\u04FF]/g) || []).length;
    const lat = (text.match(/[a-zA-Z]/g) || []).length;
    
    const arabic = (text.match(/[\u0600-\u06FF\u0750-\u077F\uFB50-\uFDFF\uFE70-\uFEFF]/g) || []).length;
    const cjk = (text.match(/[\u4E00-\u9FFF\u3040-\u309F\u30A0-\u30FF\uAC00-\uD7AF]/g) || []).length;
    const hindi = (text.match(/[\u0900-\u097F\u0980-\u09FF]/g) || []).length;
    const foreign = arabic + cjk + hindi;
    if (foreign > 3) return 'foreign';  
    if (cyr === 0 && lat === 0) return 'other';
    if (cyr > lat * 1.5) return 'ru';
    if (lat > cyr * 1.5) return 'en';
    return 'mixed';
  },

  _trackLang(track) {
    if (!track) return 'other';
    if (this._langCache.has(track.urn)) return this._langCache.get(track.urn);
    const text = [track.title||'', track.user?.username||'', track.tag_list||'', (track.description||'').substring(0,200)].join(' ');
    const lang = this._detectLang(text);
    this._langCache.set(track.urn, lang);
    return lang;
  },

  _buildLangProfile(tracks) {
    const c = { ru: 0, en: 0, other: 0, mixed: 0 };
    for (const t of tracks) { const l = this._trackLang(t); c[l] = (c[l]||0) + 1; }
    const total = Math.max(1, tracks.length);
    this._langProfile = { ru: (c.ru + c.mixed*0.5)/total, en: (c.en + c.mixed*0.5)/total, other: c.other/total };
    Utils.log('info', `[SW] Lang: ru=${(this._langProfile.ru*100).toFixed(0)}% en=${(this._langProfile.en*100).toFixed(0)}%`);
  },

  _langScore(track) {
    const tl = this._trackLang(track);
    
    if (tl === 'foreign') return -20;

    const dom = this._langProfile.ru >= this._langProfile.en ? 'ru' : 'en';
    const domRatio = Math.max(this._langProfile.ru, this._langProfile.en);

    
    const penaltyScale = 1 + domRatio * 2;

    if (domRatio > 0.45) {
      if (tl === dom) return 3 * penaltyScale * 0.5;   
      if (tl === 'mixed') return 1;
      if (tl === 'other') return -1 * penaltyScale;     
      
      return -4 * penaltyScale;
    }
    return 0;
  },

  
  _sessionSkipGenres: {},
  _sessionSkipArtists: {},
  _sessionGoodGenres: {},
  _sessionGoodArtists: {},
  _trackStartTime: 0,

  _onTrackStart(track) {
    if (!this._active || !track) return;
    this._trackStartTime = Date.now();
    
    if (typeof QdrantEngine !== 'undefined' && QdrantEngine._ready) {
      Utils.log('info', `[SW:Qdrant] Track started: "${track.title}" — enriching pool (pool: ${QdrantEngine._poolSize})`);
      QdrantEngine.enrichFromPlayback(track).catch((e) => {
        Utils.log('warning', `[SW:Qdrant] Enrich failed for "${track.title}": ${e?.message || e}`);
      });
    }
  },

  _onTrackEnd(track) {
    if (!this._active || !track) return;
    const elapsed = (Date.now() - this._trackStartTime) / 1000;
    const duration = (track.duration || 0) / 1000;
    const pct = duration > 0 ? Math.min(1, elapsed / duration) : 0;
    const genre = (track.genre || '').toLowerCase().trim();
    const artist = this._artistKey(track);

    
    if (elapsed < 2) return;

    if (pct < 0.25) {
      
      
      const sev = elapsed < 5 ? 2.5 : elapsed < 8 ? 1.5 : 1;
      if (genre) this._sessionSkipGenres[genre] = (this._sessionSkipGenres[genre]||0) + sev;
      if (artist) this._sessionSkipArtists[artist] = (this._sessionSkipArtists[artist]||0) + sev;

      
      const lang = this._trackLang(track);
      if (lang && lang !== 'mixed') {
        this._sessionSkipLangs = this._sessionSkipLangs || {};
        this._sessionSkipLangs[lang] = (this._sessionSkipLangs[lang]||0) + sev;
      }

      
      const topGenre = this._getTopGenres(1)[0] || '';
      if (genre && genre !== topGenre && (this._sessionSkipGenres[genre]||0) >= 8) {
        const { queueIndex } = Store._state;
        const q = Store._state.queue;
        let purged = 0;
        for (let i = q.length - 1; i > queueIndex + 1; i--) {
          if ((q[i]?.genre||'').toLowerCase().trim() === genre) { Store.removeFromQueue(i); purged++; }
        }
        if (purged > 0) { this._queue = Store._state.queue; Utils.log('info', `[SW] Purged ${purged} "${genre}" after skips`); }
      }

      
      if (lang && (this._sessionSkipLangs[lang]||0) >= 10) {
        const { queueIndex } = Store._state;
        const q = Store._state.queue;
        let purged = 0;
        for (let i = q.length - 1; i > queueIndex + 1; i--) {
          if (q[i] && this._trackLang(q[i]) === lang) { Store.removeFromQueue(i); purged++; }
        }
        if (purged > 0) {
          this._queue = Store._state.queue;
          Utils.log('info', `[SW] Purged ${purged} "${lang}" tracks after language skips`);
        }
      }
    } else if (pct > 0.6) {
      if (genre) this._sessionGoodGenres[genre] = (this._sessionGoodGenres[genre]||0) + 1;
      if (artist) this._sessionGoodArtists[artist] = (this._sessionGoodArtists[artist]||0) + 1;
      if (this._mixInjectedUrns.has(track.urn)) {
        this._mixLikedRecently = true;
        Utils.log('info', '[SW] User enjoyed mixed track → will inject more');
      }
    }
    
    if (typeof QdrantEngine !== 'undefined' && QdrantEngine._ready) {
      if (pct < 0.25 && elapsed >= 2) {
        Utils.log('info', `[SW:Qdrant] Recording SKIP feedback: "${track.title}" (pct=${(pct*100).toFixed(0)}%, elapsed=${elapsed.toFixed(1)}s)`);
        QdrantEngine.recordFeedback(track, 'negative').catch((e) => {
          Utils.log('warning', `[SW:Qdrant] Feedback record failed: ${e?.message || e}`);
        });
      } else if (pct > 0.6) {
        Utils.log('info', `[SW:Qdrant] Recording LISTEN feedback: "${track.title}" (pct=${(pct*100).toFixed(0)}%, elapsed=${elapsed.toFixed(1)}s)`);
        QdrantEngine.recordFeedback(track, 'positive').catch((e) => {
          Utils.log('warning', `[SW:Qdrant] Feedback record failed: ${e?.message || e}`);
        });
      }
    }
  },

  _skipPenalty(track) {
    const genre = (track.genre||'').toLowerCase().trim();
    const artist = this._artistKey(track);
    let p = 0;
    if (genre && this._sessionSkipGenres[genre]) p -= Math.min(6, this._sessionSkipGenres[genre] * 0.8);
    if (artist && this._sessionSkipArtists[artist]) p -= Math.min(4, this._sessionSkipArtists[artist] * 1.5);
    if (genre && this._sessionGoodGenres[genre]) p += Math.min(4, this._sessionGoodGenres[genre] * 0.6);
    if (artist && this._sessionGoodArtists[artist]) p += Math.min(3, this._sessionGoodArtists[artist] * 1.0);
    
    const lang = this._trackLang(track);
    if (lang && this._sessionSkipLangs && this._sessionSkipLangs[lang]) {
      p -= Math.min(8, this._sessionSkipLangs[lang] * 0.5);
    }
    return p;
  },

  
  _avgDuration: 0,
  _avgBPM: 0,
  _genrePairs: {},

  _loadBlacklist() {
    this._blacklist = new Set(Store.get('swBlacklist') || []);
    this._artistBlacklist = new Set(Store.get('swArtistBlacklist') || []);
    Utils.log('info', `[SW] Blacklist: ${this._blacklist.size} tracks, ${this._artistBlacklist.size} artists`);
  },

  _saveBlacklist() {
    Store.set({ swBlacklist: [...this._blacklist], swArtistBlacklist: [...this._artistBlacklist] });
  },

  _artistKey(track) {
    return (track?.user?.username || track?.user?.permalink || '').toLowerCase().trim();
  },

  
  _getBPM(track) {
    if (track?.bpm && track.bpm > 30 && track.bpm < 300) return track.bpm;
    if (typeof AudioAnalyser !== 'undefined' && track?.urn) {
      const detected = AudioAnalyser.getDetectedBPM(track.urn);
      if (detected > 30 && detected < 300) return detected;
    }
    return 0;
  },

  
  _isFreeBeat(track) {
    if (!track) return false;
    const title = (track.title || '').toLowerCase();
    const username = (track.user?.username || '').toLowerCase();
    const desc = (track.description || '').substring(0, 300).toLowerCase();
    const tags = (track.tag_list || '').toLowerCase();
    const genre = (track.genre || '').toLowerCase();
    const combined = title + ' | ' + username + ' | ' + tags;

    
    if (/type\s*beat/.test(combined)) return true;

    
    if (/\bfree\b/.test(title) && /\b(beat|instrumental|prod|трек|минус|бит)\b/.test(combined)) return true;

    
    if (/\b(free\s*(for\s*profit|download)|buy\s*(this\s*)?beat|lease|beatstars|untagged|tagged|exclusive\s*rights)\b/.test(combined)) return true;
    if (/\b(prod\.?\s*by|produced\s*by)\b/.test(title) && /\b(free|бесплатн|минус)\b/.test(combined)) return true;

    
    if (/\b(beats|beatz|beatmaker|produc|on\s*the\s*track|instrumentals?)\b/.test(username) && /\b(free|type)\b/.test(title)) return true;

    
    if (/\b(бит|минус|бесплатн|инструментал)\b/.test(title) && /\b(free|бесплатн|скачать)\b/.test(combined)) return true;

    
    if (/\b(beatstars\.com|airbit\.com|buy\s*(2|two|1|one|this)|purchase|lease|licensing|mp3\s*tag)\b/.test(desc)) return true;

    
    if (/^(beats?|instrumentals?|type\s*beats?)$/.test(genre.trim())) return true;

    return false;
  },

  
  _isLowQuality(track) {
    if (!track) return true;
    const plays = track.playback_count || 0;
    const likes = track.favoritings_count ?? track.likes_count ?? 0;
    const followers = track.user?.followers_count || 0;
    const duration = track.duration || 0;

    
    if (plays < 200 && likes < 5 && followers < 100) return true;

    
    if (duration > 0 && (duration < 30000 || duration > 1800000)) return true;

    return false;
  },

  
  _estimateMood(track) {
    if (!track) return { valence: 0.5, arousal: 0.5 };

    
    let audioV = null, audioA = null;
    if (typeof AudioAnalyser !== 'undefined' && track.urn) {
      const af = AudioAnalyser.getTrackFeatures(track.urn);
      if (af && af.valence !== undefined) {
        audioV = af.valence;
        audioA = af.arousal;
        Utils.log('info', `[SW:MOOD] ★ AUDIO features for "${(track.title||'').substring(0,25)}": V=${audioV.toFixed(2)} A=${audioA.toFixed(2)} | E=${af.rmsEnergy.toFixed(3)} C=${af.centroid.toFixed(3)} F=${af.flatness.toFixed(3)} B=${af.brightness.toFixed(3)}`);
      }
    }

    
    const text = ((track.title||'')+' '+(track.genre||'')+' '+(track.tag_list||'')+' '+((track.description||'').substring(0,200))).toLowerCase();
    let kwValence = 0.5, kwArousal = 0.5;

    const bpm = this._getBPM(track);
    if (bpm > 30) {
      if (bpm < 70)       kwArousal = 0.15;
      else if (bpm < 85)  kwArousal = 0.25;
      else if (bpm < 100) kwArousal = 0.40;
      else if (bpm < 120) kwArousal = 0.55;
      else if (bpm < 140) kwArousal = 0.70;
      else if (bpm < 160) kwArousal = 0.85;
      else                kwArousal = 0.95;
    }

    
    if (/edm|trap|bass|hype|workout|dubstep|hardstyle|dnb|metal|punk|hardcore|aggressive|rage|energy/.test(text)) kwArousal = Math.min(1, kwArousal + 0.25);
    if (/pop|dance|party|house|techno|rock|electronic|hip.?hop|rap/.test(text)) kwArousal = Math.min(1, kwArousal + 0.1);
    if (/chill|lo.?fi|ambient|acoustic|folk|jazz|piano|calm|relax|mellow|peaceful|soft/.test(text)) kwArousal = Math.max(0, kwArousal - 0.2);
    if (/sleep|meditation|drone|soundscape|nature|rain|ocean/.test(text)) kwArousal = Math.max(0, kwArousal - 0.3);
    if (/бодр|мощн|сил|злой|агрессив|тяжёл|жёстк|рейв/.test(text)) kwArousal = Math.min(1, kwArousal + 0.2);
    if (/спокойн|тих|нежн|сон|мечт|облак|расслаб/.test(text)) kwArousal = Math.max(0, kwArousal - 0.2);

    
    if (/happy|fun|party|dance|sunshine|summer|love|bright|uplifting|euphoric|feel.?good/.test(text)) kwValence = Math.min(1, kwValence + 0.25);
    if (/pop|indie.?pop|synth.?pop|disco/.test(text)) kwValence = Math.min(1, kwValence + 0.1);
    if (/sad|dark|melancholy|depres|lonely|grief|pain|death|doom|gothic|funeral|emo\b|sorrow|heartbreak|cry|tear|loss|goodbye|farewell/.test(text)) kwValence = Math.max(0, kwValence - 0.30);
    if (/angry|rage|aggressive|brutal|violent|hate|destroy/.test(text)) kwValence = Math.max(0, kwValence - 0.15);
    if (/chill|mellow|peaceful|gentle|tender|warm|dream/.test(text)) kwValence = Math.min(1, kwValence + 0.1);
    if (/весел|радост|лет|солнц|свет|ярк|счаст|танц|любовь/.test(text)) kwValence = Math.min(1, kwValence + 0.2);
    if (/грустн|тоск|печал|боль|один|слез|пуст|мрачн|ночь|тень|смерт|кровь|плач|разлук|прощ|сердц/.test(text)) kwValence = Math.max(0, kwValence - 0.25);
    
    if (/minor|moll|минор/.test(text)) kwValence = Math.max(0, kwValence - 0.15);
    if (/major|dur|мажор/.test(text)) kwValence = Math.min(1, kwValence + 0.1);

    
    const dur = (track.duration || 0) / 1000;
    if (dur > 360) kwValence = Math.max(0, kwValence - 0.05);
    if (dur < 150 && dur > 30) kwValence = Math.min(1, kwValence + 0.05);
    const plays = track.playback_count || 0;
    if (plays > 1000000) kwArousal = Math.min(1, kwArousal + 0.05);
    if (plays < 1000 && plays > 0) kwArousal = Math.max(0, kwArousal - 0.05);

    
    let valence, arousal;
    if (audioV !== null && audioA !== null) {
      
      valence = audioV * 0.60 + kwValence * 0.40;
      arousal = audioA * 0.60 + kwArousal * 0.40;
    } else {
      valence = kwValence;
      arousal = kwArousal;
    }

    return { valence: Math.max(0, Math.min(1, valence)), arousal: Math.max(0, Math.min(1, arousal)) };
  },

  
  _moodMatchScore(track, targetValence, targetArousal, tolerance = 0.3) {
    const { valence, arousal } = this._estimateMood(track);
    const vDist = Math.abs(valence - targetValence);
    const aDist = Math.abs(arousal - targetArousal);
    const dist = Math.sqrt(vDist * vDist + aDist * aDist);
    
    if (dist < tolerance) return 8 - dist * 10;
    if (dist < tolerance * 2) return 3 - dist * 5;
    return -dist * 8;
  },

  _purgeUrn(urn) {
    this._queue = this._queue.filter(t => t.urn !== urn);
    if (Store.get('currentTrack')?.urn === urn) Store.next();
    const q = Store._state.queue;
    for (let i = q.length - 1; i >= 0; i--) {
      if (q[i]?.urn === urn) Store.removeFromQueue(i);
    }
  },

  
  _purgeArtist(artistKey) {
    const cur = Store.get('currentTrack');
    const curIsTarget = cur && this._artistKey(cur) === artistKey;
    const toRemove = new Set(this._queue.filter(t => this._artistKey(t) === artistKey).map(t => t.urn));
    this._queue = this._queue.filter(t => this._artistKey(t) !== artistKey);
    const q = Store._state.queue;
    for (let i = q.length - 1; i >= 0; i--) {
      if (q[i] && this._artistKey(q[i]) === artistKey) Store.removeFromQueue(i);
    }
    toRemove.forEach(u => { this._played.add(u); this._heardUrns.add(u); });
    if (curIsTarget) Store.next();
    return toRemove.size;
  },

  notInterested(track) {
    InAppModal.confirm({
      title: 'Не интересует',
      message: `Трек «${track.title}» больше не попадётся в СаундВолне.`,
      confirmText: 'Да, убрать', danger: false,
      onConfirm: () => {
        this._blacklist.add(track.urn); this._played.add(track.urn); this._heardUrns.add(track.urn);
        this._saveBlacklist(); this._purgeUrn(track.urn);
        const g = (track.genre||'').toLowerCase().trim();
        if (g) this._sessionSkipGenres[g] = (this._sessionSkipGenres[g]||0) + 2;
        Utils.toast('Трек скрыт из СаундВолны');
      },
    });
  },

  notInterestedArtist(track) {
    const artistName = track.user?.username || 'этот артист';
    const artistKey = this._artistKey(track);
    InAppModal.confirm({
      title: 'Не интересует артист',
      message: `Ни «${track.title}», ни другие треки «${artistName}» больше не появятся в СаундВолне.`,
      confirmText: 'Да, скрыть артиста', danger: false,
      onConfirm: () => {
        this._blacklist.add(track.urn); this._played.add(track.urn); this._heardUrns.add(track.urn);
        this._artistBlacklist.add(artistKey); this._saveBlacklist();
        const purged = this._purgeArtist(artistKey);
        if (artistKey) this._sessionSkipArtists[artistKey] = (this._sessionSkipArtists[artistKey]||0) + 5;
        Utils.toast(`Артист «${artistName}» скрыт из СаундВолны`);
        Utils.log('info', `[SW] Artist blacklisted: "${artistKey}", purged ${purged} tracks`);
      },
    });
  },

  _moodPalettes: {
    energetic: ['#FF6B35','#FF2D55','#FFB800','#FF4500','#FF6060','#FF8C00'],
    happy:     ['#34D399','#FBBF24','#60A5FA','#A78BFA','#F472B6','#2DD4BF'],
    calm:      ['#3B82F6','#6366F1','#8B5CF6','#06B6D4','#38BDF8','#818CF8'],
    sad:       ['#7C3AED','#6366F1','#3B82F6','#4C1D95','#312E81','#1E1B4B'],
    default:   null,
  },

  presets: {
    wakeup:  { name: 'Просыпаюсь', icon: 'sun',     tags: ['chill','morning','acoustic','lo-fi'],          timeHours: [5,6,7,8,9] },
    commute: { name: 'В дороге',   icon: 'car',     tags: ['electronic','pop','indie','drive'],             timeHours: [7,8,9,17,18,19] },
    work:    { name: 'Работаю',    icon: 'laptop',  tags: ['focus','ambient','lo-fi','instrumental'],       timeHours: [9,10,11,12,13,14,15,16,17] },
    workout: { name: 'Тренируюсь', icon: 'workout', tags: ['workout','edm','trap','bass','energy','hype'], timeHours: [6,7,8,17,18,19,20] },
    sleep:   { name: 'Засыпаю',    icon: 'moon',    tags: ['ambient','sleep','calm','piano','relax'],       timeHours: [21,22,23,0,1,2,3] },
  },
  characterPresets: {
    favorite:  { name: 'Любимое',    icon: 'heart',     mode: 'favorite' },
    discover:  { name: 'Незнакомое', icon: 'stars',     mode: 'discover' },
    popular:   { name: 'Популярное', icon: 'lightning', mode: 'popular' },
  },
  moodPresets: {
    energetic: { name: 'Бодрое',    icon: 'lightning', tags: ['energetic','upbeat','hype','edm','bass'],       palette: 'energetic' },
    happy:     { name: 'Весёлое',   icon: 'music',     tags: ['happy','fun','party','dance','pop'],            palette: 'happy' },
    calm:      { name: 'Спокойное', icon: 'waves',     tags: ['calm','chill','peaceful','mellow','ambient'],   palette: 'calm' },
    sad:       { name: 'Грустное',  icon: 'sad',       tags: ['sad','emotional','melancholy','dark','indie'],  palette: 'sad' },
  },

  
  async init() {
    Utils.log('info', '[SW] Initializing v6 (Smart Wave)...');
    this._loadBlacklist();
    await this._buildGenreProfile();
    this._loadMixedCache(); 
    
    
    setTimeout(() => this._startBgPrefetch(), 800); 

    
    if (typeof QdrantEngine !== 'undefined') {
      Utils.log('info', '[SW:Qdrant] Starting QdrantEngine initialization...');
      QdrantEngine.init().then(() => {
        if (QdrantEngine._ready && this._seedTracks.length > 0) {
          Utils.log('info', `[SW:Qdrant] Engine ready — seeding pool with ${this._seedTracks.length} liked tracks...`);
          QdrantEngine.seedPool(this._seedTracks).catch(e =>
            Utils.log('warning', '[SW:Qdrant] Seed failed: ' + (e?.message || e))
          );
        } else if (!QdrantEngine._ready) {
          Utils.log('warning', '[SW:Qdrant] Engine not ready — will use legacy algorithm only');
        } else {
          Utils.log('info', '[SW:Qdrant] No seed tracks available yet — seeding deferred');
        }
      }).catch((e) => {
        Utils.log('warning', '[SW:Qdrant] Init failed (non-fatal): ' + (e?.message || e));
      });
    } else {
      Utils.log('info', '[SW] QdrantEngine not loaded — legacy algorithm only');
    }

    
    if (typeof VisibilityManager !== 'undefined') {

    
    const _syncHeroButton = () => {
      if (!this._active) return;
      const btn = document.querySelector('.soundwave-play-btn');
      if (!btn || btn.disabled) return;

      const isPlaying = Store.get('isPlaying');
      const curTrack = Store.get('currentTrack');
      const isWaveTrack = curTrack && this._queue.some(t => t?.urn === curTrack.urn);

      
      if (isPlaying && isWaveTrack && this._swPaused) {
        this._swPaused = false;
        this._swSavedQueue = [];
      }
      
      if (isPlaying && curTrack && !isWaveTrack && !this._swPaused && !this._starting) {
        this._swPaused = true;
        this._swSavedTrack = curTrack;
        this._swSavedPos = Player.getCurrentTime();
      }

      const showPause = this._active && !this._swPaused && isPlaying;
      const pauseSvg = '<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16" rx="1"/><rect x="14" y="4" width="4" height="16" rx="1"/></svg>';
      const playSvg = '<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>';
      btn.innerHTML = showPause ? pauseSvg : playSvg;
      btn.onclick = (e) => { e.stopPropagation(); showPause ? SoundWave.pause() : SoundWave.resume(); };
    };
    Store.on('isPlaying', _syncHeroButton);
    Store.on('currentTrack', _syncHeroButton);
      VisibilityManager.onChange((visible) => {
        if (visible) {
          
          if (this._animPaused && document.getElementById('soundwave-canvas')) {
            this._animPaused = false;
            this.initCanvas();
            Utils.log('info', '[SW] Canvas resumed');
          }
        } else {
          
          if (this._animFrame) {
            cancelAnimationFrame(this._animFrame);
            this._animFrame = null;
            this._animPaused = true;
            Utils.log('info', '[SW] Canvas paused (hidden)');
          }
        }
      });
    }
    this._animPaused = false;

    Store.on('currentTrack', (newTrack) => {
      if (!this._active) return;
      
      
      if (this._swPaused || this._swResuming) return;

      const prev = this._lastKnownTrack;
      if (prev?.urn) {
        
        this._onTrackEnd(prev);
        this._heardUrns.add(prev.urn); this._played.add(prev.urn); this._globalHeard.add(prev.urn);
      }
      this._lastKnownTrack = newTrack || null;
      if (!newTrack) return;
      this._onTrackStart(newTrack);
      this._syncQueueToStore();
      const { queueIndex, queue } = Store._state;
      const remaining = queue.length - queueIndex;

      
      if (remaining < 15) {
        if (this._prefetchPool.length > 0 && !this._loading) {
          
          this._drainPoolToQueue();
          const st = Store._state;
          if (st.queueIndex >= st.queue.length - 1 && st.queue.length > 0) Store.next();
        } else if (this._bgPrefetchPool.length > 0 && !this._loading) {
          
          Utils.log('info', `[SW] Queue low — draining bg pool (${this._bgPrefetchPool.length} tracks)`);
          const bgBatch = this._bgPrefetchPool.splice(0);
          this._bgPrefetchDone = false;
          bgBatch.forEach(t => { this._played.add(t.urn); });
          this._queue.push(...bgBatch);
          this._syncQueueToStore();
          this._batchCount++;
          const st = Store._state;
          if (st.queueIndex >= st.queue.length - 1 && st.queue.length > 0) Store.next();
        } else if (!this._loading && !this._isPrefetching) {
          
          Utils.log('info', `[SW] Queue low (${remaining} left), generating directly...`);
          this._generateBatch().then(() => {
            const st = Store._state;
            if (st.queueIndex >= st.queue.length - 1 && st.queue.length > 0) Store.next();
          });
        }
        
        this._pumpPrefetch();
      }
    });
  },

  _syncQueueToStore() {
    if (!this._active) return;
    const storeQ = Store._state.queue;
    const swQ = this._queue;
    if (storeQ === swQ) return;
    const storeUrns = new Set(storeQ.map(t => t?.urn).filter(Boolean));
    const missing = swQ.filter(t => t?.urn && !storeUrns.has(t.urn));
    if (missing.length > 0) {
      Utils.log('info', `[SW] Re-syncing ${missing.length} tracks`);
      Store.set({ queue: [...storeQ, ...missing] });
      this._queue = Store._state.queue;
    }
  },

  async _loadAllLikedTracks() {
    let all = [];
    try {
      const first = await API.getLikedTracks(200, 0);
      all.push(...(first.collection || []));
      if (all.length >= 200) {
        let offset = 200, page = 1;
        while (page < 15) {
          try {
            await new Promise(r => setTimeout(r, 200));
            const b = await API.getLikedTracks(200, offset);
            const items = b.collection || [];
            if (!items.length) break;
            all.push(...items); offset += items.length; page++;
            if (items.length < 200) break;
          } catch { break; }
        }
      }
    } catch (e) { Utils.log('warning', '[SW] getLikedTracks: ' + e.message); }

    
    const settings = Store.get('settings') || {};
    if (settings.swUseYmPlaylist) {
      const ymPl = (Store.get('playlists') || []).find(p => p.isYandex === true && p.title === 'Яндекс Музыка');
      if (ymPl && ymPl.tracks && ymPl.tracks.length > 0) {
        const likedUrns = new Set(all.map(t => t.urn));
        const extra = ymPl.tracks.filter(t => t.urn && !likedUrns.has(t.urn));
        
        extra.forEach(t => { t._fromYM = true; });
        all.push(...extra);
        Utils.log('info', '[SW] Added ' + extra.length + ' tracks from YM playlist (dupes skipped)');
      }
    }

    
    if (typeof LocalLikes !== 'undefined') {
      const localTracks = LocalLikes.getTracks();
      if (localTracks.length > 0) {
        const existingUrns = new Set(all.map(t => t.urn));
        const extra = localTracks.filter(t => t.urn && !existingUrns.has(t.urn));
        all.push(...extra);
        Utils.log('info', '[SW] Added ' + extra.length + ' tracks from LocalLikes (dupes skipped)');
      }
    }

    
    const seen = new Set();
    all = all.filter(t => { if (!t.urn || seen.has(t.urn)) return false; seen.add(t.urn); return true; });
    Utils.log('info', '[SW] Loaded ' + all.length + ' liked tracks (incl. YM + LocalLikes, deduped)');
    return all;
  },

  async _buildGenreProfile() {
    try {
      const tracks = await this._loadAllLikedTracks();
      this._seedTracks = tracks;
      const gc = {}, ac = {};
      let totalDur = 0, bpmSum = 0, bpmCount = 0;

      tracks.forEach((t, idx) => {
        const w = 0.3 + 0.7 * Math.exp(-idx / 80);
        const g = (t.genre||'').toLowerCase().trim();
        if (g) gc[g] = (gc[g]||0) + w;
        const tags = (t.tag_list||'').split(/[\s,]+/).map(s=>s.toLowerCase().trim()).filter(s=>s.length>2);
        tags.forEach(tag => { gc[tag] = (gc[tag]||0) + 0.5*w; });
        
        if (g && tags.length) { tags.slice(0,3).forEach(tag => { const pair = [g,tag].sort().join('+'); this._genrePairs[pair] = (this._genrePairs[pair]||0) + w; }); }
        const artist = (t.user?.username||'').toLowerCase();
        if (artist) ac[artist] = (ac[artist]||0) + w;
        if (t.duration) totalDur += t.duration;
        if (t.bpm && t.bpm > 30 && t.bpm < 300) { bpmSum += t.bpm; bpmCount++; }
      });

      const maxG = Math.max(1, ...Object.values(gc));
      this._genreWeights = {}; for (const [g,c] of Object.entries(gc)) this._genreWeights[g] = c / maxG;
      const maxA = Math.max(1, ...Object.values(ac));
      this._artistCounts = {}; for (const [a,c] of Object.entries(ac)) this._artistCounts[a] = c / maxA;
      this._avgDuration = tracks.length > 0 ? totalDur / tracks.length : 200000;
      this._avgBPM = bpmCount > 0 ? bpmSum / bpmCount : 0;
      this._buildLangProfile(tracks);
      Utils.log('info', `[SW] Profile: ${Object.keys(this._genreWeights).length} tags, ${tracks.length} liked`);
    } catch (e) { Utils.log('warning', '[SW] Profile failed: ' + e.message); }
  },

  _getRecentUrns() {
    const recent = Store.get('recentlyPlayed') || [];
    const urns = new Set();
    recent.slice(0,50).forEach(t => { if (t.urn) urns.add(t.urn); });
    if (this._currentPreset?.mode === 'discover') (this._seedTracks||[]).forEach(t => { if (t.urn) urns.add(t.urn); });
    return urns;
  },

  
  async _startBgPrefetch() {
    
    if (this._bgPrefetching || this._active) return;
    if (this._seedTracks.length === 0) {
      Utils.log('info', '[SW] BG prefetch: нет сидов, пропускаем');
      return;
    }
    this._bgPrefetching = true;
    Utils.log('info', '[SW] BG prefetch: начинаем тихую загрузку...');

    const existingUrns = new Set(this._bgPrefetchPool.map(t => t.urn));
    let loaded = 0;
    const targetBatches = 3; 

    try {
      while (loaded < targetBatches && !this._active && this._bgPrefetching) {
        
        const batch = await this._buildBatchTracks(true);
        if (!batch || batch.length === 0) break;

        const fresh = batch.filter(t => t?.urn && !existingUrns.has(t.urn));
        if (fresh.length === 0) break;

        fresh.forEach(t => { TrackRegistry.reg(t); existingUrns.add(t.urn); });
        this._bgPrefetchPool.push(...fresh);
        this._bgPrefetchDone = true;
        loaded++;
        Utils.log('info', `[SW] BG prefetch батч ${loaded}/${targetBatches}: +${fresh.length} (всего: ${this._bgPrefetchPool.length})`);

        if (loaded < targetBatches && !this._active) {
          await new Promise(r => setTimeout(r, 500));
        }
      }
    } catch (e) {
      Utils.log('info', '[SW] BG prefetch error (non-fatal): ' + (e?.message || e));
    }

    this._bgPrefetching = false;
    Utils.log('info', `[SW] BG prefetch завершён: ${this._bgPrefetchPool.length} треков готовы`);
  },

  
  _startDirect() {
    
    if (this._starting || this._active) {
      Utils.log('info', '[SW] _startDirect: ignored — already starting/active');
      return;
    }
    
    this._pendingPreset = null;
    this._pendingPin = null;
    
    const btn = document.querySelector('.soundwave-play-btn');
    if (btn) {
      btn.disabled = true;
      btn.style.opacity = '0.5';
      btn.style.pointerEvents = 'none';
    }
    this.start(this._currentPreset || null, this._pinTrack || null);
  },

  
  async start(preset, pinTrack) {
    
    this._active = false;   
    this._loading = false;  
    this._starting = false; 

    
    await new Promise(r => setTimeout(r, 50));

    this._starting = true; this._active = true;
    this._currentPreset = preset || null; this._pinTrack = pinTrack || null;
    
    { const h = document.getElementById('soundwave-hero'); if (h) { h.outerHTML = this.renderHero(); this.initCanvas(); } }
    this._played.clear(); this._heardUrns.clear(); this._usedSeedUrns.clear();
    this._nearEndLastCall = 0; this._lastKnownTrack = null;
    this._queue = []; this._sessionSeq = [];
    
    
    this._swPaused = false;
    this._swResuming = false;
    this._swSavedTrack = null;
    this._swSavedPos = 0;
    this._swSavedQueue = [];
    this._swSavedIdx = -1;
    
    
    Store.set({ queue: [], queueIndex: -1 });
    this._sessionSkipGenres = {}; this._sessionSkipArtists = {};
    this._sessionGoodGenres = {}; this._sessionGoodArtists = {};
    this._mixInjectCounter = 0; this._mixLikedRecently = false; this._mixInjectedUrns = new Set();
    
    if (typeof QdrantEngine !== 'undefined' && QdrantEngine._ready) {
      Utils.log('info', '[SW:Qdrant] Wave restart — resetting session feedback vectors');
      QdrantEngine.resetSession();
    }
    
    this._prefetchPool = []; this._prefetchUrns = new Set();
    this._isPrefetching = false; this._batchCount = 0;

    Utils.log('info', `[SW] Starting wave. globalHeard: ${this._globalHeard.size}, blacklist: ${this._blacklist.size} tracks, ${this._artistBlacklist.size} artists`);
    if (this._currentPreset) {
      Utils.log('info', `[SW:PRESET] ★ Active: "${this._currentPreset.name}" | mode=${this._currentPreset.mode||'tags'} | tags=[${(this._currentPreset.tags||[]).join(',')}] | palette=${this._currentPreset.palette||'default'}`);
    }
    if (this._pinTrack) {
      Utils.log('info', `[SW:PIN] ★ Pin: "${this._pinTrack.title}" by ${this._pinTrack.user?.username||'?'}`);
    }
    if (this._currentPreset) {
      Utils.log('info', `[SW:PRESET] Active preset: "${this._currentPreset.name}" | mode=${this._currentPreset.mode||'none'} | tags=[${(this._currentPreset.tags||[]).join(',')}] | palette=${this._currentPreset.palette||'none'}`);
    } else {
      Utils.log('info', '[SW:PRESET] No preset — normal wave');
    }
    this._updateBlobColors();

    
    if (this._pinTrack && this._bgPrefetchPool.length > 0) {
      Utils.log('info', `[SW] Pin track mode: discarding ${this._bgPrefetchPool.length} generic bg-prefetch tracks`);
      this._bgPrefetchPool = [];
      this._bgPrefetchDone = false;
    }

    
    if (!this._pinTrack && this._bgPrefetchPool.length > 0) {
      Utils.log('info', `[SW] Instant start: using ${this._bgPrefetchPool.length} bg-prefetched tracks`);
      
      const instant = this._bgPrefetchPool.splice(0);
      this._bgPrefetchPool = [];
      this._bgPrefetchDone = false; 
      
      instant.forEach(t => { this._played.add(t.urn); });
      this._queue.push(...instant);
      this._syncQueueToStore();
      this._batchCount++;
      Store.play(this._queue[0], this._queue);
      
      this._swPaused = false;
      this._lastKnownTrack = this._queue[0];
      this._onTrackStart(this._queue[0]);
      this._starting = false;
      
      setTimeout(() => {
        if (this._active && !Store.get('isPlaying') && this._queue.length > 0) {
          Utils.log('info', '[SW] Safety: forcing playback of first track (instant path)');
          Store.set({ isPlaying: true });
        }
      }, 1500);
      const hInst = document.getElementById('soundwave-hero');
      if (hInst) { hInst.outerHTML = this.renderHero(); this.initCanvas(); }
      
      setTimeout(() => this._pumpPrefetch(), 300);
      
      setTimeout(() => this._startBgPrefetch(), 5000);
      return;
    }

    const dismissToast = Utils.toastPersistent('Генерация СаундВолны...');
    if (this._seedTracks.length === 0) await this._buildGenreProfile();
    if (!this._active) { dismissToast(); this._starting = false; return; }

    try {
      await this._generateBatch();
      if (!this._active) { dismissToast(); this._starting = false; const h = document.getElementById('soundwave-hero'); if (h) { h.outerHTML = this.renderHero(); this.initCanvas(); } return; }

      
      if (this._pinTrack && this._queue.length > 0) {
        
        this._queue = this._queue.filter(t => t.urn !== this._pinTrack.urn);
        this._queue.unshift(this._pinTrack);
        Utils.log('info', `[SW] Pin track "${this._pinTrack.title}" prepended to queue (now ${this._queue.length} tracks)`);
      }

      if (this._queue.length > 0) {
        Store.play(this._queue[0], this._queue);
        
        this._swPaused = false;
        this._lastKnownTrack = this._queue[0]; this._onTrackStart(this._queue[0]);
        dismissToast('СаундВолна запущена ✓');
        
        setTimeout(() => {
          if (this._active && !Store.get('isPlaying') && this._queue.length > 0) {
            Utils.log('info', '[SW] Safety: forcing playback of first track');
            Store.set({ isPlaying: true });
          }
        }, 1500);
        
        setTimeout(() => this._pumpPrefetch(), 200);
        
        setTimeout(() => this._startBgPrefetch(), 8000);
      } else { dismissToast('Не удалось найти треки.'); this._active = false; }
    } catch (e) { dismissToast('Ошибка запуска'); this._active = false; }
    this._starting = false;
    const h = document.getElementById('soundwave-hero'); if (h) { h.outerHTML = this.renderHero(); this.initCanvas(); }
  },

  stop() {
    this._active = false; this._starting = false; this._loading = false;
    this._isPrefetching = false;
    this._swPaused = false; 
    this._swResuming = false;
    this._swSavedTrack = null; this._swSavedPos = 0;
    this._swSavedQueue = []; this._swSavedIdx = -1;
    
    this._prefetchPool = []; this._prefetchUrns.clear();
    this._bgPrefetchPool = []; this._bgPrefetchDone = false; this._bgPrefetching = false; 
    this._batchCount = 0;
    this._currentPreset = null; this._pinTrack = null; this._queue = []; this._sessionSeq = [];
    
    this._sessionSkipGenres = {}; this._sessionSkipArtists = {};
    this._sessionGoodGenres = {}; this._sessionGoodArtists = {};
    this._mixInjectCounter = 0; this._mixLikedRecently = false;
    this._mixInjectedUrns = new Set();
    this._lastKnownTrack = null; this._trackStartTime = 0;
    if (this._animFrame) { cancelAnimationFrame(this._animFrame); this._animFrame = null; }
    Store.set({ currentTrack: null, queue: [], queueIndex: -1, isPlaying: false });
    this._updatePausedBar();
    Utils.log('info', '[SW] Stopped — все пулы очищены');
    
    if (typeof QdrantEngine !== 'undefined' && QdrantEngine._ready) {
      Utils.log('info', '[SW:Qdrant] Wave stopped — running cleanup...');
      QdrantEngine.cleanup().catch(e => Utils.log('warning', '[SW:Qdrant] Cleanup failed: ' + (e?.message || e)));
    }
    
    setTimeout(() => this._startBgPrefetch(), 3000);
  },

  
  pause() {
    if (!this._active || this._swPaused) return;
    this._swPaused = true;
    this._swSavedTrack = Store.get('currentTrack');
    this._swSavedPos = Player.getCurrentTime();
    this._swSavedQueue = [...Store._state.queue];
    this._swSavedIdx = Store._state.queueIndex;
    Store.pause();
    Utils.log('info', `[SW] Paused: "${this._swSavedTrack?.title}" pos=${this._swSavedPos.toFixed(1)}s`);
    this._updatePausedBar();
    const h = document.getElementById('soundwave-hero');
    if (h) { h.outerHTML = this.renderHero(); this.initCanvas(); }
  },

  
  resume() {
    if (!this._active || !this._swPaused) return;
    if (!this._swSavedTrack || this._swSavedQueue.length === 0) {
      Utils.log('warning', '[SW] Cannot resume — no saved state, restarting instead');
      this._swPaused = false;
      this._swSavedTrack = null; this._swSavedPos = 0;
      this._swSavedQueue = []; this._swSavedIdx = -1;
      
      this.start(this._currentPreset || null, this._pinTrack || null);
      return;
    }
    this._swResuming = true;  
    this._swPaused = false;

    
    Store.set({ queue: this._swSavedQueue, queueIndex: this._swSavedIdx });
    Store.set({ currentTrack: this._swSavedTrack, isPlaying: true });

    
    const savedPos = this._swSavedPos;
    if (savedPos > 2) {
      
      const checkReady = setInterval(() => {
        if (!Player._loading && Player._currentUrn === this._swSavedTrack?.urn) {
          clearInterval(checkReady);
          Player.seek(savedPos);
          Utils.log('info', `[SW] Seeked to ${savedPos.toFixed(1)}s after resume`);
        }
      }, 200);
      setTimeout(() => clearInterval(checkReady), 10000); 
    }

    Utils.log('info', `[SW] Resumed: "${this._swSavedTrack?.title}" at ${savedPos.toFixed(1)}s`);
    this._updatePausedBar();

    
    setTimeout(() => {
      if (!this._active || this._swPaused) return;
      const { queue: rq, queueIndex: ri } = Store._state;
      if (rq.length - ri < 10 && this._bgPrefetchPool.length > 0) {
        const bgBatch = this._bgPrefetchPool.splice(0);
        this._bgPrefetchDone = false;
        bgBatch.forEach(t => { this._played.add(t.urn); });
        this._queue.push(...bgBatch);
        this._syncQueueToStore();
        Utils.log('info', `[SW] Resume: queue extended from bg pool (+${bgBatch.length})`);
      }
      this._pumpPrefetch();
    }, 600);

    
    setTimeout(() => { this._swResuming = false; }, 500);

    const h = document.getElementById('soundwave-hero');
    if (h) { h.outerHTML = this.renderHero(); this.initCanvas(); }
  },

  isPaused() { return this._active && this._swPaused; },
  _swPaused: false,
  _swResuming: false,
  _swSavedTrack: null,
  _swSavedPos: 0,
  _swSavedQueue: [],
  _swSavedIdx: -1,

  
  _updatePausedBar() {
    const bar = document.getElementById('sw-paused-bar');
    if (bar) { bar.style.display = 'none'; bar.innerHTML = ''; }
  },

  isActive() { return this._active; },

  
  isTrackFromWave(urn) {
    if (!this._active || !urn) return false;
    
    const curTrack = Store.get('currentTrack');
    if (curTrack?.urn === urn) return true;
    return this._queue.some(t => t?.urn === urn);
  },

  
  async _forceGenerate() {
    if (!this._active) return;
    Utils.log('info', '[SW] Queue exhausted — checking prefetch pool...');

    
    if (this._prefetchPool.length > 0) {
      this._drainPoolToQueue();
      const { queueIndex, queue } = Store._state;
      const nextIdx = queueIndex + 1;
      if (nextIdx < queue.length) {
        Store.set({ currentTrack: queue[nextIdx], queueIndex: nextIdx, isPlaying: true });
        Utils.log('info', '[SW] Instant resume from prefetch pool');
      }
      this._pumpPrefetch();
      return;
    }

    
    if (this._bgPrefetchPool.length > 0) {
      Utils.log('info', `[SW] Queue exhausted — using bg pool (${this._bgPrefetchPool.length})`);
      const bgBatch = this._bgPrefetchPool.splice(0);
      this._bgPrefetchDone = false;
      bgBatch.forEach(t => { this._played.add(t.urn); });
      this._queue.push(...bgBatch);
      this._syncQueueToStore();
      this._batchCount++;
      const { queueIndex: qi2, queue: q2 } = Store._state;
      const ni2 = qi2 + 1;
      if (ni2 < q2.length) {
        Store.set({ currentTrack: q2[ni2], queueIndex: ni2, isPlaying: true });
        Utils.log('info', '[SW] Instant resume from BG prefetch pool');
      }
      this._pumpPrefetch();
      return;
    }

    
    if (this._batchCount >= this._maxBatchCycle) {
      Utils.toast('Загрузка треков...', 2500, 'sw-loading');
      await this._resetCycle();
      return;
    }

    
    Utils.toast('Загрузка треков...', 2500, 'sw-loading');
    this._loading = false; 
    try {
      await this._generateBatch();
      const { queueIndex, queue } = Store._state;
      const nextIdx = queueIndex + 1;
      if (nextIdx < queue.length) {
        Store.set({ currentTrack: queue[nextIdx], queueIndex: nextIdx, isPlaying: true });
        Utils.log('info', '[SW] Auto-continuing after force generate');
      } else {
        
        this._usedSeedUrns.clear();
        await this._generateBatch();
        const st2 = Store._state;
        if (st2.queueIndex + 1 < st2.queue.length) {
          Store.set({ currentTrack: st2.queue[st2.queueIndex + 1], queueIndex: st2.queueIndex + 1, isPlaying: true });
        }
      }
    } catch (e) {
      Utils.log('error', '[SW] Force generate failed: ' + e.message);
    }
    this._pumpPrefetch(); 
  },
  _updateBlobColors() {
    const p = this._currentPreset?.palette;
    this._blobColors = (p && this._moodPalettes[p]) ? this._moodPalettes[p] : null;
    
    this._syncBlobColors();
    Utils.log('info', '[SW] Blob colors updated (animation preserved)');
  },

  onThemeChange() {
    
    
    if (document.getElementById('soundwave-canvas')) this.initCanvas();
    Utils.log('info', '[SW] Theme changed — canvas refreshed (animation preserved)');
  },

  
  _syncBlobColors() {
    if (!this._blobsState || !this._blobsState.length) return;
    const rootStyle = getComputedStyle(document.documentElement);
    const accent = rootStyle.getPropertyValue('--accent').trim() || '#ff5500';
    const hexToRgb = h => {
      h = (h || '').replace('#','').trim();
      if (h.startsWith('rgba') || h.startsWith('rgb')) {
        const m = h.match(/\d+/g); return m ? [+m[0],+m[1],+m[2]] : [10,10,12];
      }
      if (h.length === 3) h = h[0]+h[0]+h[1]+h[1]+h[2]+h[2];
      if (h.length < 6) return [10,10,12];
      return [parseInt(h.slice(0,2),16)||10, parseInt(h.slice(2,4),16)||10, parseInt(h.slice(4,6),16)||12];
    };
    let colors;
    if (this._blobColors) {
      colors = this._blobColors.map(hexToRgb);
    } else {
      const [r,g,b] = hexToRgb(accent);
      colors = [
        [r,g,b],
        [Math.min(255,r+70), Math.max(0,g-20),  Math.min(255,b+50)],
        [Math.max(0,r-30),   Math.min(255,g+60), Math.min(255,b+70)],
        [Math.min(255,r+40), Math.min(255,g+50), Math.max(0,b-30)],
        [Math.max(0,r-60),   Math.min(255,g+30), Math.min(255,b+90)],
        [Math.min(255,r+90), Math.max(0,g-50),   Math.min(255,b+20)],
      ];
    }
    this._blobsState.forEach((b, i) => { b.color = colors[i % colors.length]; });
  },

  
  async _buildBatchTracks(bgMode = false) {
    let candidates = [];

    
    let _qdSufficient = false;
    if (this._pinTrack) {
      Utils.log('info', '[SW:Qdrant] Source 0 SKIPPED: pin track mode — using Related API only (proven better)');
    } else if (typeof QdrantEngine !== 'undefined' && QdrantEngine._ready && QdrantEngine._profileReady && QdrantEngine._poolSize >= 100) {
      try {
        Utils.log('info', `[SW:Qdrant] ═══ Source 0: Querying Qdrant (pool: ${QdrantEngine._poolSize}, session: ${QdrantEngine._sessionPositive.length}pos/${QdrantEngine._sessionNegative.length}neg) ═══`);
        const _exUrns = [...new Set([
          ...this._queue.map(t => t?.urn).filter(Boolean),
          ...this._globalHeard, ...this._heardUrns, ...this._blacklist,
          ...this._prefetchUrns,
        ])];
        Utils.log('info', `[SW:Qdrant] Excluding: ${_exUrns.length} URNs + ${this._artistBlacklist.size} artists`);
        const _t0 = performance.now();
        const _qr = await QdrantEngine.recommend({
          preset: this._currentPreset,
          pinTrack: this._pinTrack,
          mode: this._currentPreset?.mode,
          limit: 80,
          excludeUrns: _exUrns,
          excludeArtists: [...this._artistBlacklist],
        });
        const _ms = (performance.now() - _t0).toFixed(0);
        if (_qr.length >= 10) {
          _qr.forEach(r => candidates.push({ track: r.track, score: 12 + (r.score || 0) }));
          _qdSufficient = true;
          Utils.log('info', `[SW:Qdrant] ★★★ SUCCESS: ${_qr.length} vector candidates in ${_ms}ms — LEGACY SOURCES SKIPPED ★★★`);
          Utils.log('info', `[SW:Qdrant] Top 5: ${_qr.slice(0,5).map(r => `"${r.track.title}"(${r.score.toFixed(1)})`).join(', ')}`);
        } else {
          Utils.log('warning', `[SW:Qdrant] Only ${_qr.length} results in ${_ms}ms (need ≥10) — falling back to legacy sources`);
        }
      } catch (e) {
        Utils.log('warning', `[SW:Qdrant] Source 0 FAILED — falling back to legacy: ${e?.message || e}`);
      }
    } else if (typeof QdrantEngine !== 'undefined') {
      if (!QdrantEngine._ready) Utils.log('info', '[SW:Qdrant] Source 0 skipped: engine not ready');
      else if (!QdrantEngine._profileReady) Utils.log('info', '[SW:Qdrant] Source 0 skipped: profile not ready (seeding in progress)');
      else Utils.log('info', `[SW:Qdrant] Source 0 skipped: pool too small (${QdrantEngine._poolSize} < 100)`);
    }

    
    if (this._pinTrack) {
      const isFirstBatch = this._batchCount === 0;
      Utils.log('info', `[SW] ═══ PIN TRACK MODE (batch #${this._batchCount + 1}): "${this._pinTrack.title}" ═══`);

      if (isFirstBatch) {
        
        const hop1 = await this._getRelated(this._pinTrack.urn, 30);
        if (hop1.length > 0) {
          hop1.forEach(t => candidates.push({ track: t, score: 25 }));
          Utils.log('info', `[SW] Hop 1 (direct): +${hop1.length} tracks (score=25)`);

          
          const hop1Scored = hop1.map(t => ({ t, s: this._scoreTrack(t) })).sort((a,b) => b.s - a.s);
          const hop2Seeds = hop1Scored.slice(0, 5).map(h => h.t).filter(t => !this._played.has(t.urn));
          Utils.log('info', `[SW] Hop 2: expanding from ${hop2Seeds.length} best`);
          const hop2Results = await Promise.all(hop2Seeds.map(seed =>
            this._getRelated(seed.urn, 15).catch(() => [])
          ));
          let hop2Count = 0;
          for (const h2 of hop2Results) { h2.forEach(t => { candidates.push({ track: t, score: 20 }); hop2Count++; }); }
          if (hop2Count > 0) Utils.log('info', `[SW] Hop 2: +${hop2Count} tracks (score=20)`);

          
          const allHop2 = hop2Results.flat().filter(t => t?.urn && !this._played.has(t.urn));
          if (allHop2.length > 5) {
            const hop2Best = allHop2.sort((a,b) => this._scoreTrack(b) - this._scoreTrack(a)).slice(0, 3);
            Utils.log('info', `[SW] Hop 3: deepening from ${hop2Best.length} best hop2`);
            const hop3Results = await Promise.all(hop2Best.map(seed =>
              this._getRelated(seed.urn, 10).catch(() => [])
            ));
            let hop3Count = 0;
            for (const h3 of hop3Results) { h3.forEach(t => { candidates.push({ track: t, score: 16 }); hop3Count++; }); }
            if (hop3Count > 0) Utils.log('info', `[SW] Hop 3: +${hop3Count} tracks (score=16)`);
          }
        } else {
          Utils.log('warning', '[SW] Pin: 0 Related from API — fallback to legacy');
        }
      } else {
        
        
        const queueTracks = this._queue.filter(t => t?.urn && !this._played.has(t.urn));
        
        const goodTracks = this._sessionSeq.map(urn => this._queue.find(t => t?.urn === urn)).filter(Boolean);
        const seedPool = [...goodTracks, ...queueTracks];

        
        const usedUrns = new Set();
        const seeds = [];
        const shuffled = [...seedPool];
        for (let i = shuffled.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]]; }
        for (const t of shuffled) {
          if (seeds.length >= 3) break;
          if (!usedUrns.has(t.urn)) { usedUrns.add(t.urn); seeds.push(t); }
        }

        Utils.log('info', `[SW] Pin continuation: ${seeds.length} queue-based seeds: ${seeds.map(t => '"' + t.title + '"').join(', ')}`);

        
        const results = await Promise.all(seeds.map(seed =>
          this._getRelated(seed.urn, 20).catch(() => [])
        ));
        let count = 0;
        for (const rel of results) {
          rel.forEach(t => { candidates.push({ track: t, score: 18 }); count++; });
        }
        Utils.log('info', `[SW] Pin continuation: +${count} tracks from ${seeds.length} seeds (score=18)`);
        
        await new Promise(r => setTimeout(r, 300));
      }

      
      if (typeof QdrantEngine !== 'undefined' && QdrantEngine._ready) {
        QdrantEngine.indexTracks(candidates.map(c => c.track).filter(t => t?.urn)).catch(() => {});
      }
      Utils.log('info', `[SW] ═══ PIN TRACK: ${candidates.length} total candidates (batch #${this._batchCount + 1}) ═══`);
    }

    
    if (!_qdSufficient && !(this._pinTrack && candidates.length >= 30)) {

    
    const seeds = this._pickSmartSeeds(this._pinTrack ? 4 : 10);
    Utils.log('info', `[SW] Seeds: ${seeds.length} smart-weighted`);

    
    const seedPromises = seeds.map(seed => this._getRelated(seed.urn, 20).catch(() => []));
    const seedResults = await Promise.all(seedPromises);

    for (let si = 0; si < seedResults.length; si++) {
      if (!this._active) return [];
      const rel = seedResults[si];
      rel.forEach(t => candidates.push({ track: t, score: 5 + this._scoreTrack(t) }));
    }

    
    const hopPromises = [];
    for (let si = 0; si < Math.min(3, seedResults.length); si++) {
      const rel = seedResults[si];
      if (rel.length > 2 && candidates.length < 150) {
        const best = rel.reduce((a,b) => this._scoreTrack(a) > this._scoreTrack(b) ? a : b);
        if (best && !this._played.has(best.urn)) {
          hopPromises.push(this._getRelated(best.urn, 10).catch(() => []));
        }
      }
    }
    if (hopPromises.length > 0) {
      const hopResults = await Promise.all(hopPromises);
      for (const h2 of hopResults) {
        h2.forEach(t => candidates.push({ track: t, score: 3 + this._scoreTrack(t) }));
      }
    }
    if (!this._active && !bgMode) return [];

    
    const searchTags = this._currentPreset?.tags || this._getTopGenres(5);
    if (searchTags.length > 0) {
      const hour = new Date().getHours();
      const isTime = (this._currentPreset?.timeHours||[]).includes(hour);
      const tagSlice = searchTags.slice(0, isTime ? 4 : 3);
      const tagPromises = tagSlice.map(tag => {
        const off = this._tagOffsets[tag] || 0;
        this._tagOffsets[tag] = (off + 30) % 150;
        return API.searchTracks(tag, 30, off).catch(() => ({ collection: [] }));
      });
      const tagResults = await Promise.all(tagPromises);
      const isTimeFlag = (this._currentPreset?.timeHours||[]).includes(hour);
      for (const d of tagResults) {
        (d.collection||[]).forEach(t => { candidates.push({ track: t, score: (3 + this._scoreTrack(t)) * (isTimeFlag ? 1.5 : 1) }); });
      }
    }

    
    if (candidates.length < 200) {
      const topPairs = Object.entries(this._genrePairs).sort((a,b) => b[1]-a[1]).slice(0,2);
      const pairPromises = topPairs.map(([pair]) =>
        API.searchTracks(pair.replace('+',' '), 15, 0).catch(() => ({ collection: [] }))
      );
      const pairResults = await Promise.all(pairPromises);
      for (const d of pairResults) {
        (d.collection||[]).forEach(t => { candidates.push({ track: t, score: 4 + this._scoreTrack(t) }); });
      }
    }

    
    if (candidates.length < 5) {
      const fq = this._getTopGenres(1)[0] || 'music';
      const fo = this._tagOffsets['__fb']||0; this._tagOffsets['__fb'] = (fo+30)%300;
      try { const d = await API.searchTracks(fq, 30, fo); (d.collection||[]).forEach(t => candidates.push({ track: t, score: this._scoreTrack(t) })); } catch {}
    }

    } 

    
    if (!_qdSufficient && typeof QdrantEngine !== 'undefined' && QdrantEngine._ready) {
      const _newTracks = candidates.map(c => c.track).filter(t => t?.urn);
      if (_newTracks.length > 0) {
        Utils.log('info', `[SW:Qdrant] Indexing ${_newTracks.length} legacy candidates into Qdrant for future use...`);
        QdrantEngine.indexTracks(_newTracks).then(count => {
          if (count > 0) Utils.log('info', `[SW:Qdrant] Indexed ${count} new legacy candidates (pool: ${QdrantEngine._poolSize})`);
        }).catch((e) => {
          Utils.log('warning', `[SW:Qdrant] Legacy indexing failed (non-fatal): ${e?.message || e}`);
        });
      }
    }

    
    const mode = this._currentPreset?.mode;
    if (mode === 'popular') candidates.forEach(c => { c.score += Math.min(6, (c.track.playback_count||0)/100000); });
    else if (mode === 'discover') candidates.forEach(c => { const p = c.track.playback_count||0; c.score += p<1000?10:p<5000?7:p<20000?4:p<100000?1:-3; });
    else if (mode === 'favorite') candidates.forEach(c => { const g = (c.track.genre||'').toLowerCase(); if (g && this._genreWeights[g]) c.score += this._genreWeights[g]*4; });

    
    const excludeUrns = new Set([
      ...this._queue.map(t => t?.urn).filter(Boolean),
      ...this._prefetchUrns  
    ]);
    const seen = new Set();
    let filtered = [];
    let blHits = 0, qualHits = 0, beatHits = 0;
    for (const c of candidates) {
      if (!c.track?.urn || seen.has(c.track.urn)) continue;
      if (excludeUrns.has(c.track.urn)) continue;
      if (this._globalHeard.has(c.track.urn)) continue;
      if (this._heardUrns.has(c.track.urn)) continue;
      if (this._blacklist.has(c.track.urn) || this._artistBlacklist.has(this._artistKey(c.track))) { blHits++; continue; }

      
      if (mode !== 'discover' && this._isFreeBeat(c.track)) { beatHits++; continue; }

      
      const artK = this._artistKey(c.track);
      const isKnownArtist = artK && (this._artistCounts[artK] || 0) > 0.1;
      if (!isKnownArtist && this._isLowQuality(c.track)) { qualHits++; continue; }

      seen.add(c.track.urn); filtered.push(c);
    }
    if (blHits) Utils.log('info', `[SW] Blocked ${blHits} blacklisted`);
    if (beatHits) Utils.log('info', `[SW] Filtered ${beatHits} free beats/type beats`);
    if (qualHits) Utils.log('info', `[SW] Filtered ${qualHits} low-quality tracks`);
    Utils.log('info', `[SW] Candidates: ${candidates.length} raw -> ${filtered.length} unique`);

    
    let _bpmSC = 0, _bpmAA = 0, _bpmNone = 0;
    for (const c of filtered) {
      const scBpm = c.track.bpm && c.track.bpm > 30 && c.track.bpm < 300;
      if (scBpm) { _bpmSC++; continue; }
      if (typeof AudioAnalyser !== 'undefined' && c.track.urn) {
        const det = AudioAnalyser.getDetectedBPM(c.track.urn);
        if (det > 30 && det < 300) { _bpmAA++; continue; }
      }
      _bpmNone++;
    }
    Utils.log('info', `[SW:BPM] Stats: ${_bpmSC} from SoundCloud, ${_bpmAA} from AudioAnalyser, ${_bpmNone} unknown (${filtered.length} total)`);

    
    for (const c of filtered) {
      c.score += this._langScore(c.track);
      c.score += this._skipPenalty(c.track);

      const plays = c.track.playback_count||0, likes = c.track.favoritings_count??c.track.likes_count??0;
      const followers = c.track.user?.followers_count || 0;

      
      if (plays < 100) c.score -= 15;            
      else if (plays < 300) c.score -= 10;
      else if (plays < 500) c.score -= 6;
      else if (plays < 1000) c.score -= 3;
      else if (plays < 3000) c.score -= 1;

      
      if (plays > 50000) c.score += 1.5;
      if (plays > 200000) c.score += 1;

      
      if (followers < 50 && plays < 1000) c.score -= 5;
      else if (followers < 200 && plays < 3000) c.score -= 2;

      
      if (plays > 1000) {
        const ratio = likes / plays;
        c.score += ratio > 0.1 ? 3 : ratio > 0.05 ? 2 : ratio > 0.02 ? 1 : ratio > 0.005 ? 0 : -1;
      } else if (plays > 300) {
        c.score += (likes / plays > 0.1) ? 1 : 0;
      }
      
      if (plays > 10000 && likes < 10) c.score -= 4;

      
      const title = (c.track.title||'').toLowerCase();
      const username = (c.track.user?.username||'').toLowerCase();
      const titleAndUser = title + ' ' + username;
      if (/wshh|world\s*star|repost|premiere|exclusive|official\s*video/.test(titleAndUser)) {
        c.score -= 5;
      }

      
      if (this._isFreeBeat(c.track)) c.score -= 12;
      
      if (/\b(free\s*(dl|download)?|type\s*beat|instrumental|prod\.?\s*by)\b/i.test(title)) c.score -= 6;
      if (/\b(минус|бит\b|инструментал)/i.test(title)) c.score -= 5;

      const created = c.track.created_at;
      if (created) {
        const days = (Date.now() - new Date(created).getTime()) / 86400000;
        const vel = plays / Math.max(1, days);
        c.score += vel>5000?3:vel>1000?2:days<30?1.5:days<90?0.5:0;
      }

      if (this._avgDuration > 0 && c.track.duration) {
        const diff = Math.abs(c.track.duration - this._avgDuration) / this._avgDuration;
        if (diff > 3) c.score -= 4; else if (diff > 1.5) c.score -= 2;
      }
      if (this._avgBPM > 0) {
        const trackBPM = this._getBPM(c.track);
        if (trackBPM > 30) {
          const bd = Math.abs(trackBPM - this._avgBPM);
          if (bd > 60) c.score -= 3; else if (bd > 40) c.score -= 1.5; else if (bd < 15) c.score += 1;
        }
      }
      const art = this._artistKey(c.track), aff = this._artistCounts[art]||0;
      if (aff > 0.5) c.score += 2; else if (aff > 0.3) c.score += 1;
      if (aff > 0.7) c.score -= aff * 1.5;

      if (this._currentPreset?.tags || this._currentPreset?.mode) {
        const trackText = ((c.track.genre||'')+' '+(c.track.tag_list||'')+' '+(c.track.title||'')+' '+((c.track.description||'').substring(0,200))).toLowerCase();
        let moodMatch = 0;
        if (this._currentPreset.tags) {
          for (const pt of this._currentPreset.tags) { if (trackText.includes(pt)) moodMatch++; }
          c.score += moodMatch * 3;
        }

        
        const _TARGETS = {
          wakeup:   {v:0.62, a:0.30, bpm:[100,120]},  
          commute:  {v:0.62, a:0.50, bpm:[90,130]},    
          work:     {v:0.48, a:0.25, bpm:[60,90]},     
          workout:  {v:0.55, a:0.95, bpm:[130,160]},   
          sleep:    {v:0.35, a:0.06, bpm:[60,80]},      
          energetic:{v:0.65, a:0.92, bpm:[130,170]},   
          happy:    {v:0.85, a:0.65, bpm:[120,150]},   
          calm:     {v:0.58, a:0.15, bpm:[70,90]},     
          sad:      {v:0.15, a:0.20, bpm:[60,70]},     
        };
        let _targetKey = null;
        for (const [k,p] of Object.entries(this.presets)) if(p===this._currentPreset){_targetKey=k;break;}
        if(!_targetKey) for (const [k,p] of Object.entries(this.moodPresets)) if(p===this._currentPreset){_targetKey=k;break;}
        if (_targetKey && _TARGETS[_targetKey]) {
          const target = _TARGETS[_targetKey];
          const mScore = this._moodMatchScore(c.track, target.v, target.a);
          c.score += mScore;

          
          const _trackBPM = this._getBPM(c.track);
          if (target.bpm && _trackBPM > 30) {
            const [bpmMin, bpmMax] = target.bpm;
            const _bpmSource = (c.track.bpm && c.track.bpm > 30) ? 'SC' : 'AA';
            if (_trackBPM >= bpmMin && _trackBPM <= bpmMax) {
              c.score += 4; 
              if (filtered.indexOf(c) < 5) Utils.log('info', `[SW:BPM:${_bpmSource}] ★ "${(c.track.title||'').substring(0,25)}" ${_trackBPM}bpm IN ${bpmMin}-${bpmMax} → +4`);
            } else if (_trackBPM >= bpmMin - 15 && _trackBPM <= bpmMax + 15) {
              c.score += 1; 
            } else {
              const distFromRange = _trackBPM < bpmMin ? bpmMin - _trackBPM : _trackBPM - bpmMax;
              c.score -= Math.min(8, distFromRange * 0.15);
            }
          }
        }

        
        if (typeof AudioAnalyser !== 'undefined' && _targetKey && c.track.urn) {
          const audioScore = AudioAnalyser.moodScore(c.track.urn, _targetKey);
          if (audioScore !== 0) {
            c.score += audioScore;
            
            if (Math.abs(audioScore) > 5) {
              Utils.log('info', `[SW:AUDIO] "${(c.track.title||'').substring(0,25)}" audioScore=${audioScore.toFixed(1)} for ${_targetKey}`);
            }
          }
        }

        
        const { valence, arousal } = this._estimateMood(c.track);
        if (this._currentPreset===this.presets.sleep||this._currentPreset===this.moodPresets.calm||this._currentPreset===this.presets.wakeup) {
          if(arousal>0.7) c.score-=10;
          if(/edm|trap|hype|bass|metal|punk|hardstyle|aggressive|dubstep/.test(trackText)) c.score-=8;
          if(arousal<0.35) c.score+=3;
        }
        if (this._currentPreset===this.presets.workout||this._currentPreset===this.moodPresets.energetic) {
          if(arousal<0.35) c.score-=10;
          if(/ambient|sleep|calm|relax|piano|meditation|lo-fi|acoustic/.test(trackText)) c.score-=8;
          if(arousal>0.7) c.score+=3;
          if((c.track.playback_count||0)>100000) c.score+=2;
        }
        if (this._currentPreset===this.moodPresets.sad) {
          
          if(valence>0.65) c.score-=12; if(arousal>0.70) c.score-=8;
          if(/happy|fun|party|dance|hype|energetic|workout|весел|радост|танц|бодр/.test(trackText)) c.score-=10;
          if(valence<0.30&&arousal<0.40) c.score+=6;
          if(valence<0.20) c.score+=3; 
          
          if (typeof AudioAnalyser !== 'undefined' && c.track.urn) {
            const af = AudioAnalyser.getTrackFeatures(c.track.urn);
            if (af) {
              
              if (af.brightness < 0.30 && af.centroid < 0.12) c.score += 4;
              if (af.rmsEnergy > 0.15) c.score -= 5; 
              if (af.flatness < 0.20) c.score += 2;  
              if (af.brightness > 0.50) c.score -= 4; 
            }
          }
        }
        if (this._currentPreset===this.moodPresets.happy) {
          if(valence<0.3) c.score-=10;
          if(/sad|dark|melancholy|depres|lonely|doom|death|грустн|тоск|боль|мрачн/.test(trackText)) c.score-=8;
          if(valence>0.65) c.score+=3;
          
          if (typeof AudioAnalyser !== 'undefined' && c.track.urn) {
            const af = AudioAnalyser.getTrackFeatures(c.track.urn);
            if (af) {
              if (af.brightness > 0.40 && af.centroid > 0.15) c.score += 3;
              if (af.rmsEnergy < 0.03) c.score -= 3; 
            }
          }
        }
        if (this._currentPreset===this.presets.work) {
          if(arousal>0.8) c.score-=6;
          if(/hype|party|aggressive|metal|hardcore/.test(trackText)) c.score-=5;
          if(/focus|instrumental|lo-fi|study|ambient|beats|piano/.test(trackText)) c.score+=4;
          
          if (typeof AudioAnalyser !== 'undefined' && c.track.urn) {
            const af = AudioAnalyser.getTrackFeatures(c.track.urn);
            if (af && af.flux < 0.008) c.score += 3; 
            if (af && af.flux > 0.02) c.score -= 2;  
          }
        }
        if (this._currentPreset===this.presets.commute) {
          if(arousal<0.2||arousal>0.9) c.score-=3;
          if(/drive|pop|indie|electronic|synth/.test(trackText)) c.score+=3;
        }
      }

      
      const mode = this._currentPreset?.mode;
      if(mode==='discover'){const la=new Set(this._seedTracks.map(t=>this._artistKey(t)).filter(Boolean));if(la.has(art))c.score-=6;}
      if(mode==='popular'){const p=c.track.playback_count||0;if(p>500000)c.score+=4;else if(p>100000)c.score+=2;else if(p<10000)c.score-=3;}
      if(mode==='favorite'){const la=new Set(this._seedTracks.map(t=>this._artistKey(t)).filter(Boolean));if(la.has(art))c.score+=3;}

      if (this._pinTrack) {
        const pinArtist = this._artistKey(this._pinTrack);
        const pinGenre = (this._pinTrack.genre||'').toLowerCase();
        if (art === pinArtist) c.score += 4;
        if (pinGenre && (c.track.genre||'').toLowerCase() === pinGenre) c.score += 2;
      }
    }

    
    filtered = filtered.filter(c => c.score > -3);

    
    if (this._currentPreset) {
      const presetName = this._currentPreset.name || 'unknown';
      const presetMode = this._currentPreset.mode || 'tags';
      Utils.log('info', `[SW:PRESET] ═══ "${presetName}" (${presetMode}) — scoring results ═══`);
      Utils.log('info', `[SW:PRESET] After filtering: ${filtered.length} tracks`);
      
      const top20 = [...filtered].sort((a,b) => b.score - a.score).slice(0, 20);
      if (top20.length > 0) {
        let moodSummary = { vLow: 0, vHigh: 0, aLow: 0, aHigh: 0 };
        top20.forEach(c => {
          const m = this._estimateMood(c.track);
          if (m.valence < 0.4) moodSummary.vLow++; else if (m.valence > 0.6) moodSummary.vHigh++;
          if (m.arousal < 0.4) moodSummary.aLow++; else if (m.arousal > 0.6) moodSummary.aHigh++;
        });
        Utils.log('info', `[SW:PRESET] Top-20 mood: ${moodSummary.vHigh} happy/${moodSummary.vLow} sad, ${moodSummary.aHigh} energetic/${moodSummary.aLow} calm`);
        Utils.log('info', `[SW:PRESET] Top-5: ${top20.slice(0,5).map(c => `"${c.track.title}"(${c.score.toFixed(1)})`).join(', ')}`);
      }
    }

    const temp = mode === 'discover' ? 2.0 : mode === 'favorite' ? 0.8 : 1.3;
    
    
    filtered.forEach(c => {
      const hasAudio = typeof AudioAnalyser !== 'undefined' && c.track.urn && AudioAnalyser.getTrackFeatures(c.track.urn);
      const confidence = hasAudio ? 0.85 : 0.4; 
      const noise = (Math.random() - 0.5) * 2 * (1 - confidence) * 4; 
      c.sortKey = c.score / temp + noise;
    });
    filtered.sort((a,b) => b.sortKey - a.sortKey);

    
    const MMR_LAMBDA = 0.65; 
    const batchArt = {}, batch = [];
    const selected = new Set();

    for (let iter = 0; iter < 30 && filtered.length > 0; iter++) {
      let bestIdx = -1, bestMMR = -Infinity;
      for (let i = 0; i < filtered.length; i++) {
        if (selected.has(i)) continue;
        const c = filtered[i];
        const artK = this._artistKey(c.track);

        
        const maxScore = filtered[0]?.sortKey || 1;
        const relScore = maxScore > 0 ? c.sortKey / maxScore : 0;

        
        let maxSim = 0;
        for (const sel of batch) {
          const selArt = this._artistKey(sel);
          if (artK && artK === selArt) { maxSim = 1.0; break; } 
          if ((c.track.genre||'').toLowerCase() === (sel.genre||'').toLowerCase() && c.track.genre) maxSim = Math.max(maxSim, 0.4);
        }

        const mmrScore = MMR_LAMBDA * relScore - (1 - MMR_LAMBDA) * maxSim;
        if (mmrScore > bestMMR) { bestMMR = mmrScore; bestIdx = i; }
      }
      if (bestIdx < 0) break;
      selected.add(bestIdx);
      const chosen = filtered[bestIdx];
      const artK = this._artistKey(chosen.track);
      batchArt[artK] = (batchArt[artK]||0) + 1;
      
      if (batchArt[artK] > 2) continue;
      batch.push(chosen.track);
    }
    
    if (batch.length < 12 && filtered.length >= 12) {
      const ba2 = {};
      const existing = new Set(batch.map(t => t.urn));
      for (const c of filtered) {
        if (batch.length >= 30) break;
        if (existing.has(c.track.urn)) continue;
        const a = this._artistKey(c.track); ba2[a]=(ba2[a]||0)+1;
        if (ba2[a]>2) continue;
        batch.push(c.track);
        existing.add(c.track.urn);
      }
    }

    
    if (this._mixedCache.length > 0 && batch.length > 3) {
      const injectCount = this._mixLikedRecently ? 2 : 1;
      const qUrns = new Set(batch.map(t => t.urn));
      const available = this._mixedCache.filter(t => t.urn && !qUrns.has(t.urn) && !this._globalHeard.has(t.urn) && !this._blacklist.has(t.urn) && !this._artistBlacklist.has(this._artistKey(t)) && this._trackLang(t) !== 'foreign' && !this._isFreeBeat(t) && (t.playback_count||0) >= 300);
      for (let i = 0; i < injectCount && available.length > 0; i++) {
        const idx = Math.floor(Math.random() * available.length);
        const mixTrack = available.splice(idx, 1)[0];
        const pos = Math.min(batch.length, 4 + Math.floor(Math.random() * 3));
        batch.splice(pos, 0, mixTrack);
        this._mixInjectedUrns.add(mixTrack.urn);
        Utils.log('info', `[SW] Injected mixed track: ${mixTrack.title}`);
      }
      this._mixLikedRecently = false;
    }

    
    this._sortByEnergyArc(batch);
    return batch;
  },

  
  async _generateBatch() {
    if (this._loading || !this._active) return;
    this._loading = true;
    try {
      const batch = await this._buildBatchTracks();
      if (!this._active || batch.length === 0) { this._loading = false; return; }
      batch.forEach(t => { TrackRegistry.reg(t); this._played.add(t.urn); });
      if (this._played.size > 300) {
        const arr = [...this._played]; this._played = new Set(arr.slice(arr.length - 300));
      }
      this._queue.push(...batch);
      this._syncQueueToStore();
      this._batchCount++;
      Utils.log('info', `[SW] Generated ${batch.length} tracks → queue (total: ${this._queue.length}, batch #${this._batchCount}/${this._maxBatchCycle})`);
    } catch (e) { Utils.log('error', '[SW] Gen error: ' + e.message); }
    this._loading = false;
  },

  
  async _prefetchBatch() {
    if (this._isPrefetching || !this._active) return;
    if (this._prefetchPool.length >= this._prefetchTarget) return; 
    if (this._batchCount >= this._maxBatchCycle) return; 
    this._isPrefetching = true;
    try {
      Utils.log('info', `[SW] Prefetching batch (pool: ${this._prefetchPool.length}/${this._prefetchTarget})...`);
      const batch = await this._buildBatchTracks();
      if (!this._active || batch.length === 0) { this._isPrefetching = false; return; }
      batch.forEach(t => {
        TrackRegistry.reg(t);
        this._played.add(t.urn);
        this._prefetchUrns.add(t.urn); 
      });
      if (this._played.size > 300) {
        const arr = [...this._played]; this._played = new Set(arr.slice(arr.length - 300));
      }
      this._prefetchPool.push(batch);
      Utils.log('info', `[SW] Prefetch ready: ${batch.length} tracks (pool: ${this._prefetchPool.length}/${this._prefetchTarget})`);
    } catch (e) { Utils.log('error', '[SW] Prefetch error: ' + e.message); }
    this._isPrefetching = false;
    
    if (this._active && this._prefetchPool.length < this._prefetchTarget) {
      setTimeout(() => this._pumpPrefetch(), 300);
    }
  },

  
  _drainPoolToQueue() {
    if (this._prefetchPool.length === 0) return false;
    const batch = this._prefetchPool.shift();
    
    const valid = batch.filter(t =>
      !this._blacklist.has(t.urn) &&
      !this._artistBlacklist.has(this._artistKey(t)) &&
      !this._globalHeard.has(t.urn) &&
      !this._heardUrns.has(t.urn)
    );
    
    batch.forEach(t => this._prefetchUrns.delete(t.urn));
    if (valid.length > 0) {
      this._queue.push(...valid);
      this._syncQueueToStore();
      this._batchCount++;
      Utils.log('info', `[SW] Drained prefetch → ${valid.length} tracks added (pool left: ${this._prefetchPool.length}, batch #${this._batchCount}/${this._maxBatchCycle})`);
    }
    return valid.length > 0;
  },

  
  _pumpPrefetch() {
    if (!this._active || this._isPrefetching || this._loading) return;
    if (this._prefetchPool.length >= this._prefetchTarget) return;
    if (this._batchCount >= this._maxBatchCycle) return; 
    this._prefetchBatch();
  },

  
  async _resetCycle() {
    
    if (this._cycleResetting) return;
    this._cycleResetting = true;
    Utils.log('info', `[SW] Cycle complete (${this._batchCount} batches). Resetting...`);
    this._batchCount = 0;
    this._prefetchPool = [];
    this._prefetchUrns.clear();
    this._played.clear();
    this._usedSeedUrns.clear();
    this._isPrefetching = false;
    this._loading = false;
    
    await this._generateBatch();
    
    this._pumpPrefetch();
    
    const st = Store._state;
    const nextIdx = st.queueIndex + 1;
    if (nextIdx < st.queue.length) {
      Store.set({ currentTrack: st.queue[nextIdx], queueIndex: nextIdx, isPlaying: true });
      Utils.log('info', '[SW] Cycle reset complete — playback resumed');
    }
    
    setTimeout(() => { this._cycleResetting = false; }, 2000);
  },

  _scoreTrack(t) {
    let s = 0;
    const g = (t.genre||'').toLowerCase();
    if (g && this._genreWeights[g]) s += this._genreWeights[g] * 5;
    (t.tag_list||'').split(/[\s,]+/).forEach(tag => { const tg = tag.toLowerCase().trim(); if (tg && this._genreWeights[tg]) s += this._genreWeights[tg]*2; });
    const p = t.playback_count||0;
    
    if (p < 200) s -= 8;
    else if (p < 500) s -= 4;
    else if (p < 1000) s -= 1;
    else s += p>500000?1:p>100000?2:p>10000?1.5:0.5;
    const likes = t.favoritings_count??t.likes_count??0;
    if (p > 500 && likes/p > 0.05) s += 1;
    
    if (this._isFreeBeat(t)) s -= 10;
    return s;
  },

  _getTopGenres(n) {
    return Object.entries(this._genreWeights).sort((a,b) => b[1]-a[1]).slice(0,n).map(([g]) => g).filter(g => g.length > 2);
  },

  _pickSmartSeeds(n) {
    const pool = this._seedTracks; if (!pool.length) return [];
    let unused = pool.filter(t => !this._usedSeedUrns.has(t.urn));
    if (unused.length < n) { this._usedSeedUrns.clear(); unused = pool.slice(); }

    const weighted = unused.map(t => {
      const g = (t.genre||'').toLowerCase().trim();
      const gw = (g && this._genreWeights[g]) ? this._genreWeights[g] : 0.3;
      const sessionBoost = (g && this._sessionGoodGenres[g]) ? this._sessionGoodGenres[g]*0.5 : 0;
      const sessionPen = (g && this._sessionSkipGenres[g]) ? this._sessionSkipGenres[g]*0.3 : 0;
      return { track: t, weight: Math.max(0.01, gw + sessionBoost - sessionPen) };
    });

    const picks = [], usedIdx = new Set();
    for (let i = 0; i < Math.min(n, weighted.length); i++) {
      const totalW = weighted.reduce((s,w,j) => usedIdx.has(j)?s:s+w.weight, 0);
      let r = Math.random() * totalW, chosen = 0;
      for (let j = 0; j < weighted.length; j++) { if (usedIdx.has(j)) continue; r -= weighted[j].weight; if (r <= 0) { chosen = j; break; } }
      usedIdx.add(chosen); picks.push(weighted[chosen].track); this._usedSeedUrns.add(weighted[chosen].track.urn);
    }
    return picks;
  },

  
  _sortByEnergyArc(batch) {
    if (batch.length < 5) return;
    const eOf = t => {
      
      if (typeof AudioAnalyser !== 'undefined' && t.urn) {
        const af = AudioAnalyser.getTrackFeatures(t.urn);
        if (af && af.arousal !== undefined) return af.arousal;
      }
      const s = ((t.genre||'')+(t.tag_list||'')).toLowerCase();
      if (/edm|trap|bass|hype|workout|dubstep|hardstyle/.test(s)) return 0.85;
      if (/pop|dance|party|rock|punk|metal/.test(s)) return 0.7;
      if (/ambient|sleep|calm|relax|piano/.test(s)) return 0.2;
      if (/lo-?fi|chill|acoustic|folk|jazz/.test(s)) return 0.35;
      if (/sad|dark|melancholy/.test(s)) return 0.3;
      if (/hip-?hop|rap|r&?b|indie/.test(s)) return 0.55;
      const _bpm = this._getBPM(t);
      if (_bpm > 140) return 0.75;
      if (_bpm > 0 && _bpm < 85) return 0.35;
      return 0.5;
    };
    const wE = batch.map(t => ({ t, e: eOf(t) }));
    wE.sort((a,b) => a.e - b.e);
    const n = wE.length;
    
    
    const arc = new Array(n);
    const peakPos = Math.floor(n * 0.6); 
    for (let i = 0; i < n; i++) {
      
      let target;
      if (i <= peakPos) {
        target = i / peakPos; 
      } else {
        target = 1.0 - 0.5 * ((i - peakPos) / (n - 1 - peakPos)); 
      }
      
      const targetE = wE[0].e + target * (wE[n-1].e - wE[0].e);
      let bestIdx = 0, bestDist = Infinity;
      for (let j = 0; j < wE.length; j++) {
        if (wE[j].used) continue;
        const d = Math.abs(wE[j].e - targetE);
        if (d < bestDist) { bestDist = d; bestIdx = j; }
      }
      wE[bestIdx].used = true;
      arc[i] = wE[bestIdx].t;
    }
    for (let i = 0; i < n; i++) batch[i] = arc[i];
  },

  async _getRelated(urn, limit) {
    try { return (await API.getRelatedTracks(urn, limit)).collection?.filter(t => t.urn && t.title) || []; }
    catch { return []; }
  },

  onTrackNearEnd() {
    if (!this._active) return;
    const now = Date.now(); if (now - this._nearEndLastCall < 3000) return; this._nearEndLastCall = now;
    const cur = Store.get('currentTrack');
    if (cur?.urn) { this._heardUrns.add(cur.urn); this._played.add(cur.urn); this._globalHeard.add(cur.urn); if (!this._sessionSeq.includes(cur.urn)) { this._sessionSeq.push(cur.urn); if (this._sessionSeq.length>30) this._sessionSeq.shift(); } }
    this._syncQueueToStore();
    const { queueIndex, queue } = Store._state;
    if (queue.length - queueIndex < 10 && !this._loading) {
      Utils.log('info', `[SW] Queue low, generating...`);
      if (this._batchCount >= this._maxBatchCycle) {
        
        this._resetCycle();
      } else {
        this._generateBatch();
      }
    }
  },

  startByTrack(track) {
    
    this._pendingPreset = null;
    this._pendingPin = null;
    this.start(null, track);
  },

  
  renderHero() {
    const isActive = this._active;
    const preset = this._currentPreset;
    const pin = this._pinTrack;

    
    if (isActive && this._swPaused && Store.get('isPlaying')) {
      const curTrack = Store.get('currentTrack');
      if (curTrack && this._queue.some(t => t?.urn === curTrack.urn)) {
        this._swPaused = false;
        this._swSavedQueue = [];
      }
    }

    return `
      <div class="soundwave-hero" id="soundwave-hero">
        <canvas class="soundwave-canvas" id="soundwave-canvas"></canvas>
        <div class="soundwave-content">
          <div class="soundwave-title">СаундВолна</div>
          ${isActive ? `
            <div class="soundwave-status">
              ${pin ? `<span class="soundwave-chip">${Utils.esc(pin.title)} <span class="sw-chip-x" onclick="event.stopPropagation();SoundWave._removePinLive()">✕</span></span>` : ''}
              ${preset ? `<span class="soundwave-chip sw-chip-preset">${SWICONS[preset.icon] || ''} ${preset.name} <span class="sw-chip-x" onclick="event.stopPropagation();SoundWave._removePresetLive()">✕</span></span>` : ''}
            </div>
          ` : ''}
          <button class="soundwave-play-btn${this._starting || this._loading ? ' sw-btn-loading' : ''}"
            ${this._starting || this._loading ? 'disabled' : ''}
            onclick="event.stopPropagation();${isActive
              ? (this._swPaused
                ? 'SoundWave.resume()'
                : 'SoundWave.pause()')
              : 'SoundWave._startDirect()'}">
            ${(this._starting || this._loading) && !isActive
              ? `<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" style="animation:sw-spin 6s linear infinite"><g><circle cx="12" cy="3" r="1.3"/><circle cx="16.5" cy="4.21" r="1.1"/><circle cx="19.79" cy="7.5" r="0.9"/><circle cx="21" cy="12" r="0.8"/><circle cx="19.79" cy="16.5" r="0.7"/><circle cx="16.5" cy="19.79" r="0.6"/><circle cx="12" cy="21" r="0.5"/><circle cx="7.5" cy="19.79" r="0.6"/><circle cx="4.21" cy="16.5" r="0.7"/><circle cx="3" cy="12" r="0.8"/><circle cx="4.21" cy="7.5" r="0.9"/><circle cx="7.5" cy="4.21" r="1.1"/></g></svg>`
              : isActive
                ? (this._swPaused
                  ? '<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>'
                  : '<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16" rx="1"/><rect x="14" y="4" width="4" height="16" rx="1"/></svg>')
                : '<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>'}
          </button>
          <button class="soundwave-gear-btn" onclick="event.stopPropagation();SoundWave.openPanel()" title="Настройки СаундВолны">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
            <span>Настроить</span>
          </button>
        </div>
      </div>`;
  },

  
    initCanvas() {
    const canvas = document.getElementById('soundwave-canvas');
    if (!canvas) return;
    if (this._animFrame) { cancelAnimationFrame(this._animFrame); this._animFrame = null; }

    const ctx = canvas.getContext('2d');
    const dpr = window.devicePixelRatio || 1;

    
    const resize = () => {
      const rect = canvas.parentElement.getBoundingClientRect();
      canvas.width  = rect.width  * dpr;
      canvas.height = rect.height * dpr;
      canvas.style.width  = rect.width  + 'px';
      canvas.style.height = rect.height + 'px';
    };
    resize();

    
    if (canvas._resizeObs) canvas._resizeObs.disconnect();
    canvas._resizeObs = new ResizeObserver(() => { resize(); });
    canvas._resizeObs.observe(canvas.parentElement);

    
    const rootStyle = getComputedStyle(document.documentElement);
    const bgPrimary = rootStyle.getPropertyValue('--bg-primary').trim() || '#08080a';
    const accent    = rootStyle.getPropertyValue('--accent').trim()     || '#ff5500';

    const hexToRgb = h => {
      h = (h || '').replace('#','').trim();
      if (h.startsWith('rgba') || h.startsWith('rgb')) {
        const m = h.match(/\d+/g); return m ? [+m[0],+m[1],+m[2]] : [10,10,12];
      }
      if (h.length === 3) h = h[0]+h[0]+h[1]+h[1]+h[2]+h[2];
      if (h.length < 6) return [10,10,12];
      return [parseInt(h.slice(0,2),16)||10, parseInt(h.slice(2,4),16)||10, parseInt(h.slice(4,6),16)||12];
    };

    const [bgR, bgG, bgB] = hexToRgb(bgPrimary);
    const bgLum   = 0.299*bgR + 0.587*bgG + 0.114*bgB;
    const isLight = bgLum > 130;

    const blobAlpha  = isLight ? [0.28, 0.13, 0.04] : [0.55, 0.28, 0.08];
    const trailAlpha = isLight ? 0.16 : 0.06;

    
    let colors;
    if (this._blobColors) {
      colors = this._blobColors.map(hexToRgb);
    } else {
      const [r,g,b] = hexToRgb(accent);
      colors = [
        [r,g,b],
        [Math.min(255,r+70), Math.max(0,g-20),  Math.min(255,b+50)],
        [Math.max(0,r-30),   Math.min(255,g+60), Math.min(255,b+70)],
        [Math.min(255,r+40), Math.min(255,g+50), Math.max(0,b-30)],
        [Math.max(0,r-60),   Math.min(255,g+30), Math.min(255,b+90)],
        [Math.min(255,r+90), Math.max(0,g-50),   Math.min(255,b+20)],
      ];
    }

    
    const getConfig = () => {
      const pw = canvas.parentElement.getBoundingClientRect().width;
      if (pw < 300)      return { count: 5,  rMin: 0.15, rMax: 0.25 };
      else if (pw < 500) return { count: 7,  rMin: 0.18, rMax: 0.28 };
      else if (pw < 800) return { count: 10, rMin: 0.20, rMax: 0.32 };
      else               return { count: 12, rMin: 0.22, rMax: 0.35 };
    };

    let cfg = getConfig();

    
    if (!this._blobsState || this._blobsState.length !== cfg.count) {
      this._blobsState = Array.from({ length: cfg.count }, (_, i) => ({
        x:         0.1 + Math.random() * 0.8,
        y:         0.1 + Math.random() * 0.8,
        vx:        (Math.random() - 0.5) * 0.0014,
        vy:        (Math.random() - 0.5) * 0.0012,
        r:         cfg.rMin + Math.random() * (cfg.rMax - cfg.rMin),
        color:     colors[i % colors.length],
        phase:     i * 0.65,
        wobble:    0.05 + Math.random() * 0.09,
        wobbleSpd: 0.003 + Math.random() * 0.004,
      }));
    } else {
      
      this._blobsState.forEach((b, i) => { b.color = colors[i % colors.length]; });
    }

    const blobs = this._blobsState;
    let t = 0;
    let cachedCfgCount = cfg.count;
    let cfgCheckCounter = 0;

    ctx.fillStyle = `rgb(${bgR},${bgG},${bgB})`;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    const draw = () => {
      if (!document.getElementById('soundwave-canvas')) {
        if (canvas._resizeObs) canvas._resizeObs.disconnect();
        this._animFrame = null;
        return;
      }

      const w = canvas.width, h = canvas.height;

      
      if (++cfgCheckCounter >= 120) {
        cfgCheckCounter = 0;
        const newCfg = getConfig();
        if (newCfg.count !== cachedCfgCount) {
          this._blobsState = null;
          this.initCanvas();
          return;
        }
      }

      
      ctx.fillStyle = `rgba(${bgR},${bgG},${bgB},${isLight ? 0.18 : 0.10})`;
      ctx.fillRect(0, 0, w, h);

      for (const blob of blobs) {
        blob.x += blob.vx;
        blob.y += blob.vy;
        if (blob.x < 0.05) { blob.x = 0.05; blob.vx =  Math.abs(blob.vx); }
        if (blob.x > 0.95) { blob.x = 0.95; blob.vx = -Math.abs(blob.vx); }
        if (blob.y < 0.05) { blob.y = 0.05; blob.vy =  Math.abs(blob.vy); }
        if (blob.y > 0.95) { blob.y = 0.95; blob.vy = -Math.abs(blob.vy); }
        
        blob.vx += (Math.random() - 0.5) * 0.00012;
        blob.vy += (Math.random() - 0.5) * 0.00010;
        const spd = Math.sqrt(blob.vx*blob.vx + blob.vy*blob.vy);
        
        if (spd > 0.003) { blob.vx *= 0.003/spd; blob.vy *= 0.003/spd; }

        const cx  = blob.x * w;
        const cy  = blob.y * h;
        
        const rad = blob.r * Math.min(w, h) * (1 + Math.sin(t * blob.wobbleSpd + blob.phase) * blob.wobble);

        const grad = ctx.createRadialGradient(cx, cy, 0, cx, cy, rad);
        const [r,g,b] = blob.color;
        grad.addColorStop(0,    `rgba(${r},${g},${b},${blobAlpha[0]})`);
        grad.addColorStop(0.35, `rgba(${r},${g},${b},${blobAlpha[1]})`);
        grad.addColorStop(0.7,  `rgba(${r},${g},${b},${blobAlpha[2]})`);
        grad.addColorStop(1,    `rgba(${r},${g},${b},0)`);

        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(cx, cy, rad, 0, Math.PI*2);
        ctx.fill();
      }

      t++;
      this._animFrame = requestAnimationFrame(draw);
    };

    this._animFrame = requestAnimationFrame(draw);
  },

  
  openPanel() {
    let el = document.getElementById('soundwave-panel');
    if (!el) { el = document.createElement('div'); el.id = 'soundwave-panel'; document.body.appendChild(el); }

    
    if (this._pendingPreset === null && this._currentPreset !== null) {
      this._pendingPreset = this._currentPreset;
    }
    if (this._pendingPin === null && this._pinTrack !== null) {
      this._pendingPin = this._pinTrack;
    }

    
    const activityBtn = (id, cat, p) => {
      const active = this._pendingPreset === p;
      return `<button class="sw2-btn ${active ? 'sw2-active' : ''}" onclick="SoundWave._selectPreset('${id}','${cat}')">
        <div class="sw2-btn-icon">${SWICONS[p.icon] || ''}</div>
        <div class="sw2-btn-label">${p.name}</div>
      </button>`;
    };

    const charBtn = (id, cat, p) => {
      const active = this._pendingPreset === p;
      return `<button class="sw2-chip ${active ? 'sw2-active' : ''}" onclick="SoundWave._selectPreset('${id}','${cat}')">
        <span class="sw2-chip-icon">${SWICONS[p.icon] || ''}</span>
        <span>${p.name}</span>
      </button>`;
    };

    const moodBtn = (id, cat, p) => {
      const active = this._pendingPreset === p;
      const palette = this._moodPalettes[p.palette] || this._moodPalettes.default;
      const grad = palette ? `linear-gradient(135deg, ${palette[0]}22, ${palette[2]}22)` : '';
      const borderColor = active && palette ? palette[0] : '';
      return `<button class="sw2-mood ${active ? 'sw2-active' : ''}" onclick="SoundWave._selectPreset('${id}','${cat}')"
        style="${grad ? `background:${grad};` : ''}${borderColor ? `border-color:${borderColor};` : ''}">
        <div class="sw2-mood-icon">${SWICONS[p.icon] || ''}</div>
        <div class="sw2-mood-label">${p.name}</div>
      </button>`;
    };

    el.innerHTML = `
      <div class="modal-backdrop" onclick="SoundWave.closePanel()"></div>
      <div class="sw2-panel">
        <div class="sw2-header">
          <div class="sw2-title-row">
            <div>
              <h2 class="sw2-title">СаундВолна</h2>
              <p class="sw2-subtitle">Умный подбор музыки на основе аудиоанализа</p>
            </div>
            <button class="sw2-close" onclick="SoundWave.closePanel()">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>
            </button>
          </div>
        </div>

        ${this._pinTrack ? `
          <div class="sw2-section">
            <div class="sw2-section-label">По волне трека</div>
            <div class="sw2-pin">
              <div class="sw2-pin-info">
                <div class="sw2-pin-title">${Utils.esc(this._pinTrack.title)}</div>
                <div class="sw2-pin-artist">${Utils.esc(this._pinTrack.user?.username || '')}</div>
              </div>
              <button class="sw2-pin-x" onclick="SoundWave._removePin()">✕</button>
            </div>
          </div>
        ` : ''}

        <div class="sw2-section">
          <div class="sw2-section-label">Под занятие</div>
          <div class="sw2-grid-activity">
            ${Object.entries(this.presets).map(([id, p]) => activityBtn(id, 'presets', p)).join('')}
          </div>
        </div>

        <div class="sw2-section">
          <div class="sw2-section-label">Настроение</div>
          <div class="sw2-grid-mood">
            ${Object.entries(this.moodPresets).map(([id, p]) => moodBtn(id, 'moodPresets', p)).join('')}
          </div>
        </div>

        <div class="sw2-section">
          <div class="sw2-section-label">Характер</div>
          <div class="sw2-grid-char">
            ${Object.entries(this.characterPresets).map(([id, p]) => charBtn(id, 'characterPresets', p)).join('')}
          </div>
        </div>

        <div class="sw2-actions">
          <button class="sw2-start" onclick="SoundWave._startFromPanel()">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>
            ${this._active ? 'Перезапустить' : 'Запустить волну'}
            ${!this._active && this._bgPrefetchDone ? '<span class="sw2-ready">⚡ готово</span>' : ''}
            ${!this._active && this._bgPrefetching ? '<span class="sw2-ready">⟳ загрузка...</span>' : ''}
          </button>
          ${this._active ? `
          <button class="sw2-stop" onclick="SoundWave._stopFromPanel()">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="6" width="12" height="12" rx="2"/></svg>
            Выключить
          </button>
          ` : ''}
        </div>
      </div>
    `;
    requestAnimationFrame(() => el.classList.add('open'));
  },

  _getTimeHint(hour) {
    if (hour >= 5  && hour <= 8)  return 'Доброе утро! Попробуй «Просыпаюсь»';
    if (hour >= 9  && hour <= 11) return 'Рабочее утро — «Работаю» или «В дороге»?';
    if (hour >= 12 && hour <= 14) return 'Обед — почему бы не что-то весёлое?';
    if (hour >= 17 && hour <= 20) return 'Вечер — «В дороге» или «Тренируюсь»?';
    if (hour >= 21 || hour <= 3)  return 'Поздний вечер — попробуй «Засыпаю»';
    return '';
  },

  closePanel() {
    const el = document.getElementById('soundwave-panel');
    if (!el) return;
    
    
    this._pendingPreset = null;
    this._pendingPin = null;
    el.classList.remove('open');
    setTimeout(() => el.remove(), 300);
  },

  _selectPreset(id, cat) {
    const p = this[cat][id];
    const wasActive = this._pendingPreset === p;

    
    if (wasActive) {
      this._pendingPreset = null;
      Utils.log('info', `[SW:PRESET] Panel: DESELECTED "${p.name}" (not applied yet)`);
      this.openPanel();
      return;
    }

    
    if (this._pendingPin || this._pinTrack) {
      if (typeof InAppModal !== 'undefined') {
        InAppModal.confirm({
          title: 'Трек по волне активен',
          message: `Сейчас выбран трек по волне. Чтобы выбрать настроение «${p.name}», трек по волне будет сброшен.`,
          confirmText: 'Продолжить',
          cancelText: 'Отмена',
          danger: false,
          onConfirm: () => {
            Utils.log('info', `[SW:PRESET] User confirmed: removing pin to select preset "${p.name}"`);
            this._pendingPin = null;
            this._pendingPreset = p;
            Utils.log('info', `[SW:PRESET] Panel: STAGED "${p.name}" (not applied yet — press Start)`);
            this.openPanel();
          },
        });
      }
      return;
    }

    
    this._pendingPreset = p;
    Utils.log('info', `[SW:PRESET] Panel: STAGED "${p.name}" (cat=${cat}, id=${id}) — press Start to apply`);
    this.openPanel();
  },

  _removePin()     { this._pendingPin = null; Utils.log('info', '[SW:PRESET] Pin removed from panel (pending)'); this.openPanel(); },
  _removePinLive() {
    Utils.log('info', `[SW:PRESET] ✕ Pin removed live: "${this._pinTrack?.title}" — stopping wave`);
    this._pinTrack = null;
    this._pendingPin = null;
    this.stop();
    Utils.toast('Трек по волне отключён', 2500, 'sw-pin-off');
    if (Store.get('currentPage') === 'home' && typeof HomePage !== 'undefined') {
      setTimeout(() => HomePage.render(), 100);
    }
  },
  _removePresetLive() {
    const oldName = this._currentPreset?.name || '';
    const oldMode = this._currentPreset?.mode || 'tags';
    Utils.log('info', `[SW:PRESET] ✕ Preset removed live: "${oldName}" (mode=${oldMode}) — restarting as normal wave`);
    this._currentPreset = null;
    this._pendingPreset = null;
    this._updateBlobColors();
    Utils.toast('Режим отключён — обычная волна', 2500, 'sw-preset-off');
    this.start(null, null);
  },
  _startFromPanel() {
    
    this._currentPreset = this._pendingPreset || null;
    this._pinTrack = this._pendingPin || null;
    if (this._currentPreset) this._updateBlobColors();
    const presetInfo = this._currentPreset
      ? `preset="${this._currentPreset.name}" mode=${this._currentPreset.mode||'tags'} tags=[${(this._currentPreset.tags||[]).join(',')}]`
      : 'NO PRESET (normal wave)';
    Utils.log('info', `[SW:PRESET] ═══ CONFIRMED & Starting wave: ${presetInfo}, pin=${this._pinTrack?.title||'none'} ═══`);
    this.closePanel();
    Utils.toast('Генерация волны...', 2500, 'sw-gen');
    this.start(this._currentPreset, this._pinTrack);
  },

  _stopFromPanel() {
    Utils.log('info', `[SW:PRESET] Stop from panel — preset="${this._currentPreset?.name||'none'}", pin="${this._pinTrack?.title||'none'}"`);
    this.closePanel();
    this.stop();
    Utils.toast('СаундВолна выключена', 2500, 'sw-off');
    if (Store.get('currentPage') === 'home' && typeof HomePage !== 'undefined') {
      setTimeout(() => HomePage.render(), 100);
    }
  },
};
