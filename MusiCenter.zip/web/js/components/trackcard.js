

const TrackRegistry = {
  _map: new Map(),
  _MAX_SIZE: 3000,
  reg(track) {
    if (!track?.urn) return '';
    
    if (this._map.has(track.urn)) this._map.delete(track.urn);
    this._map.set(track.urn, track);
    
    if (this._map.size > this._MAX_SIZE) {
      const iter = this._map.keys();
      let toDelete = this._map.size - this._MAX_SIZE;
      while (toDelete-- > 0) {
        const key = iter.next().value;
        this._map.delete(key);
      }
    }
    return track.urn;
  },
  get(urn) { return this._map.get(urn) || null; },
  
  cleanup() {
    if (this._map.size > this._MAX_SIZE) {
      const entries = [...this._map.entries()];
      this._map.clear();
      entries.slice(-this._MAX_SIZE).forEach(([k,v]) => this._map.set(k, v));
    }
  },
};

const TrackCardComponent = {
  
  _queues: new Map(),        
  _lastSetContext: 'default', 

  
  get _currentQueue() {
    return this._queues.get(this._lastSetContext) || [];
  },

  card(track, queue) {
    TrackRegistry.reg(track);
    const art = Utils.art(track.artwork_url, 't300x300');
    const isPlaying = Store.get('currentTrack')?.urn === track.urn && Store.get('isPlaying');
    const urn = Utils.esc(track.urn);
    
    const isLocalLike = track._isLocalLike || (typeof LocalLikes !== 'undefined' && LocalLikes.hasTrack(track.urn));
    const localBadgeHtml = isLocalLike ? `
      <div class="ll-badge" onclick="event.stopPropagation(); PlaylistsPage.openPlaylist(LocalLikes.getPlaylist().id)" oncontextmenu="event.stopPropagation(); event.preventDefault(); LocalLikes.tryLikeAndRemove('${urn}')">
        <svg viewBox="0 0 32 32" fill="currentColor"><path d="M0 16q0 2.912 1.824 5.088t4.576 2.752q0.032 0 0.032-0.032v-0.064t0.032-0.032q0.544-1.344 1.344-2.176t2.208-1.184v-2.336q0-2.496 1.728-4.256t4.256-1.76 4.256 1.76 1.76 4.256v2.336q1.376 0.384 2.176 1.216t1.344 2.144l0.096 0.288h0.384q2.464 0 4.224-1.76t1.76-4.224v-2.016q0-2.464-1.76-4.224t-4.224-1.76q-0.096 0-0.32 0.032 0.32-1.152 0.32-2.048 0-3.296-2.368-5.632t-5.632-2.368q-2.88 0-5.056 1.824t-2.784 4.544q-1.152-0.352-2.176-0.352-3.296 0-5.664 2.336t-2.336 5.664v1.984zM10.016 25.824q-0.096 0.928 0.576 1.6l4 4q0.576 0.576 1.408 0.576t1.408-0.576l4-4q0.672-0.672 0.608-1.6-0.064-0.32-0.16-0.576-0.224-0.576-0.736-0.896t-1.12-0.352h-1.984v-5.984q0-0.832-0.608-1.408t-1.408-0.608-1.408 0.608-0.576 1.408v5.984h-2.016q-0.608 0-1.12 0.352t-0.736 0.896q-0.096 0.288-0.128 0.576z"/></svg>
      </div>` : '';
    return `
      <div class="track-card ${isPlaying ? 'playing' : ''}" data-urn="${urn}"
           onclick="TrackCardComponent.play('${urn}')"
           oncontextmenu="ContextMenu.showByUrn(event,'${urn}')"
           onmousedown="TrackCardComponent._tilt3D(this,event)"
           onmousemove="TrackCardComponent._tiltMove(this,event)"
           onmouseleave="TrackCardComponent._tiltReset(this)">
        <div class="track-card-art">
          ${art ? `<img src="${Utils.esc(art)}" alt="${Utils.esc(track.title)}" loading="lazy">` :
            '<div class="flex-center" style="width:100%;height:100%;background:rgba(255,255,255,0.03)"><svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.15)" stroke-width="1.5"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg></div>'}
          <div class="track-card-overlay">
            <div class="track-card-play-btn">
              ${isPlaying ? '<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M6 4h4v16H6zM14 4h4v16h-4z"/></svg>'
                          : '<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>'}
            </div>
          </div>
          <div class="track-card-duration">${Utils.dur(track.duration)}</div>
        </div>
        ${localBadgeHtml}
        <div class="track-card-info">
          <div class="track-card-title">${Utils.esc(track.title)}</div>
          <div class="track-card-artist" onclick="event.stopPropagation(); ArtistPage.openFromUrn('${Utils.esc(track.user?.urn || '')}','${Utils.esc(track.user?.username || '')}')">${Utils.esc(track.user?.username || '')}</div>
          ${track.playback_count > 0 ? `<div class="track-card-plays" style="display:flex;align-items:center;gap:4px"><svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 18v-6a9 9 0 0 1 18 0v6"/><path d="M21 19a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3zM3 19a2 2 0 0 0 2 2h1a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2H3z"/></svg> ${Utils.fc(track.playback_count)}</div>` : ''}
          ${(track.favoritings_count ?? track.likes_count) > 0 ? `<div class="track-card-plays" style="margin-top:1px;display:flex;align-items:center;gap:4px"><svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg> ${Utils.fc(track.favoritings_count ?? track.likes_count)}</div>` : ''}
        </div>
      </div>`;
  },

  row(track, index, queue) {
    TrackRegistry.reg(track);
    const art = Utils.art(track.artwork_url, 't200x200');
    const current   = Store.get('currentTrack');
    const isThis    = current?.urn === track.urn;
    const isPlaying = isThis && Store.get('isPlaying');
    const urn = Utils.esc(track.urn);
    
    const isLocalLike = track._isLocalLike || (typeof LocalLikes !== 'undefined' && LocalLikes.hasTrack(track.urn));
    const llIcon = isLocalLike ? `<div class="ll-row-icon" title="Локально на устройстве" onclick="event.stopPropagation(); PlaylistsPage.openPlaylist(LocalLikes.getPlaylist().id)"><svg viewBox="0 0 32 32" fill="var(--accent)"><path d="M0 16q0 2.912 1.824 5.088t4.576 2.752q0.032 0 0.032-0.032v-0.064t0.032-0.032q0.544-1.344 1.344-2.176t2.208-1.184v-2.336q0-2.496 1.728-4.256t4.256-1.76 4.256 1.76 1.76 4.256v2.336q1.376 0.384 2.176 1.216t1.344 2.144l0.096 0.288h0.384q2.464 0 4.224-1.76t1.76-4.224v-2.016q0-2.464-1.76-4.224t-4.224-1.76q-0.096 0-0.32 0.032 0.32-1.152 0.32-2.048 0-3.296-2.368-5.632t-5.632-2.368q-2.88 0-5.056 1.824t-2.784 4.544q-1.152-0.352-2.176-0.352-3.296 0-5.664 2.336t-2.336 5.664v1.984zM10.016 25.824q-0.096 0.928 0.576 1.6l4 4q0.576 0.576 1.408 0.576t1.408-0.576l4-4q0.672-0.672 0.608-1.6-0.064-0.32-0.16-0.576-0.224-0.576-0.736-0.896t-1.12-0.352h-1.984v-5.984q0-0.832-0.608-1.408t-1.408-0.608-1.408 0.608-0.576 1.408v5.984h-2.016q-0.608 0-1.12 0.352t-0.736 0.896q-0.096 0.288-0.128 0.576z"/></svg></div>` : '';
    return `
      <div class="track-row ${isThis ? 'active' : ''}" data-urn="${urn}"
           onclick="TrackCardComponent.play('${urn}')"
           oncontextmenu="ContextMenu.showByUrn(event,'${urn}')">
        <div class="track-row-index">${index + 1}</div>
        <div class="track-row-play-btn">
          ${isPlaying ? '<svg width="14" height="14" viewBox="0 0 24 24" fill="white"><path d="M6 4h4v16H6zM14 4h4v16h-4z"/></svg>'
                      : '<svg width="14" height="14" viewBox="0 0 24 24" fill="white"><path d="M8 5v14l11-7z"/></svg>'}
        </div>
        <div class="track-row-art" style="position:relative">
          ${art ? `<img src="${Utils.esc(art)}" alt="" loading="lazy">` : '<div style="width:100%;height:100%;background:rgba(255,255,255,0.04)"></div>'}
          ${isLocalLike ? '<div class="ll-row-art-dot"></div>' : ''}
        </div>
        <div class="track-row-info">
          <div class="track-row-title">${llIcon}${Utils.esc(track.title)}</div>
          <div class="track-row-artist" onclick="event.stopPropagation(); ArtistPage.openFromUrn('${Utils.esc(track.user?.urn || '')}','${Utils.esc(track.user?.username || '')}')">${Utils.esc(track.user?.username || '')}</div>
        </div>
        <button class="track-row-like-btn ${NowPlayingComponent._likedTracks.has(track.urn) ? 'active' : ''}"
                onclick="event.stopPropagation(); TrackCardComponent._toggleRowLike(this, '${urn}')"
                title="${NowPlayingComponent._likedTracks.has(track.urn) ? 'Убрать из любимых' : 'В любимые'}">
          <svg width="14" height="14" viewBox="0 0 24 24"
               fill="${NowPlayingComponent._likedTracks.has(track.urn) ? 'var(--accent)' : 'none'}"
               stroke="${NowPlayingComponent._likedTracks.has(track.urn) ? 'var(--accent)' : 'currentColor'}" stroke-width="2">
            <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
          </svg>
        </button>
        <div class="track-row-stats">
          ${track.playback_count > 0 ? `<span class="track-row-stat"><svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 18v-6a9 9 0 0 1 18 0v6"/><path d="M21 19a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3zM3 19a2 2 0 0 0 2 2h1a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2H3z"/></svg>${Utils.fc(track.playback_count)}</span>` : ''}
          ${(track.favoritings_count ?? track.likes_count) > 0 ? `<span class="track-row-stat"><svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>${Utils.fc(track.favoritings_count ?? track.likes_count)}</span>` : ''}
        </div>
        <div class="track-row-duration">${Utils.dur(track.duration)}</div>
      </div>`;
  },

  feedCard(track, queue) {
    TrackRegistry.reg(track);
    const art   = Utils.art(track.artwork_url, 't300x300');
    const isThis = Store.get('currentTrack')?.urn === track.urn;
    const urn = Utils.esc(track.urn);
    return `
      <div class="feed-card ${isThis ? 'active' : ''}" data-urn="${urn}"
           onclick="TrackCardComponent.play('${urn}')"
           oncontextmenu="ContextMenu.showByUrn(event,'${urn}')">
        <div class="feed-card-art">
          ${art ? `<img src="${Utils.esc(art)}" alt="" loading="lazy">` :
            '<div class="flex-center" style="width:100%;height:100%;background:rgba(255,255,255,0.03)"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.15)" stroke-width="1.5"><path d="M9 18V5l12-2v13"/></svg></div>'}
          <div class="feed-card-play"><div class="feed-card-play-inner"><svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg></div></div>
        </div>
        <div class="feed-card-info">
          <div class="feed-card-title">${Utils.esc(track.title)}</div>
          <div class="feed-card-artist" onclick="event.stopPropagation(); ArtistPage.openFromUrn('${Utils.esc(track.user?.urn || '')}','${Utils.esc(track.user?.username || '')}')">${Utils.esc(track.user?.username || '')}</div>
          <div class="feed-card-meta">
            ${track.genre ? `<span style="padding:1px 6px;border-radius:10px;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.04);font-size:9px">${Utils.esc(track.genre)}</span>` : ''}
            <span>${Utils.fc(track.playback_count)} Прослушиваний</span>
          </div>
        </div>
        <div class="feed-card-right"><div class="feed-card-dur">${Utils.dur(track.duration)}</div></div>
      </div>`;
  },

  featured(track, queue) {
    TrackRegistry.reg(track);
    const art    = Utils.art(track.artwork_url, 't500x500');
    const avatar = Utils.art(track.user?.avatar_url, 'small');
    const isPlaying = Store.get('currentTrack')?.urn === track.urn && Store.get('isPlaying');
    const urn = Utils.esc(track.urn);
    return `
      <div class="featured-card" data-urn="${urn}" oncontextmenu="ContextMenu.showByUrn(event,'${urn}')">
        ${art ? `<div class="featured-bg"><img src="${Utils.esc(art)}" alt=""><div class="featured-bg-overlay"></div></div>` : ''}
        <div class="featured-content">
          <div class="featured-art" onclick="TrackCardComponent.play('${urn}')">
            ${art ? `<img src="${Utils.esc(art)}" alt="${Utils.esc(track.title)}">` : ''}
          </div>
          <div class="featured-info">
            <div class="featured-title">${Utils.esc(track.title)}</div>
            <div class="featured-artist-row" onclick="ArtistPage.openFromUrn('${Utils.esc(track.user?.urn || '')}','${Utils.esc(track.user?.username || '')}')" style="cursor:pointer">
              ${avatar ? `<img class="featured-artist-avatar" src="${Utils.esc(avatar)}" alt="">` : ''}
              <span class="featured-artist-name">${Utils.esc(track.user?.username || '')}</span>
            </div>
            <div class="featured-tags">
              ${track.genre ? `<span class="featured-genre">#${Utils.esc(track.genre)}</span>` : ''}
              <div class="featured-stats">
                <span>${Utils.fc(track.playback_count)}</span>
                <span>&#9829; ${Utils.fc(track.favoritings_count ?? track.likes_count)}</span>
                <span>${Utils.dur(track.duration)}</span>
              </div>
            </div>
          </div>
          <div class="featured-play-btn" onclick="TrackCardComponent.play('${urn}')">
            ${isPlaying ? '<svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor"><path d="M6 4h4v16H6zM14 4h4v16h-4z"/></svg>'
                        : '<svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>'}
          </div>
        </div>
      </div>`;
  },

  play(urn) {
    
    let bestQueue = null;
    let bestCtx   = null;

    
    const lastQ = this._queues.get(this._lastSetContext);
    if (lastQ && lastQ.some(t => t.urn === urn)) {
      bestQueue = lastQ;
      bestCtx   = this._lastSetContext;
    }

    
    if (!bestQueue) {
      for (const [ctx, q] of this._queues) {
        if (q.some(t => t.urn === urn)) {
          bestQueue = q;
          bestCtx   = ctx;
          break; 
        }
      }
    }

    
    if (!bestQueue) {
      bestQueue = [];
      bestCtx   = 'single';
    }

    const track = bestQueue.find(t => t.urn === urn) || TrackRegistry.get(urn);
    if (track) {
      if (Store.get('currentTrack')?.urn === urn) {
        Store.togglePlay();
      } else {
        Utils.log('info', `[Queue] Play from ctx="${bestCtx}" (${bestQueue.length} tracks, idx=${bestQueue.findIndex(t=>t.urn===urn)})`);
        Store.play(track, bestQueue.length ? bestQueue : [track]);
      }
    }
  },

  setQueue(queue, context) {
    
    const ctx = context || 'default';
    this._queues.set(ctx, queue);
    this._lastSetContext = ctx;
    queue.forEach(t => TrackRegistry.reg(t));
    
    if (this._queues.size > 30) {
      const first = this._queues.keys().next().value;
      this._queues.delete(first);
    }
  },

  async _toggleRowLike(btn, urn) {
    
    if (typeof LocalLikes !== 'undefined' && LocalLikes.hasTrack(urn)) {
      btn.style.transform = 'scale(1.3)';
      setTimeout(() => { btn.style.transform = ''; }, 300);
      const ok = await LocalLikes.tryLikeAndRemove(urn);
      if (ok) {
        NowPlayingComponent._likedTracks.add(urn);
        const svg = btn.querySelector('svg');
        btn.classList.add('active');
        svg.setAttribute('fill', 'var(--accent)');
        svg.setAttribute('stroke', 'var(--accent)');
        const cur = Store.get('currentTrack');
        if (cur && cur.urn === urn) NowPlayingComponent._updateTrackInfo();
      }
      return;
    }

    const isLiked = NowPlayingComponent._likedTracks.has(urn);
    const svg = btn.querySelector('svg');

    
    if (isLiked) {
      NowPlayingComponent._likedTracks.delete(urn);
      btn.classList.remove('active');
      svg.setAttribute('fill', 'none');
      svg.setAttribute('stroke', 'currentColor');
    } else {
      NowPlayingComponent._likedTracks.add(urn);
      btn.classList.add('active');
      svg.setAttribute('fill', 'var(--accent)');
      svg.setAttribute('stroke', 'var(--accent)');
      btn.style.transform = 'scale(1.3)';
      setTimeout(() => { btn.style.transform = ''; }, 300);
      const track = TrackRegistry.get(urn);
      if (track) NowPlayingComponent._animateLike(track);
    }

    
    try {
      await LikeQueue.enqueue(urn, isLiked ? 'unlike' : 'like');
    } catch (err) {
      
      Utils.log('error', `[RowLike] Error: ${err.message}`);
      if (isLiked) {
        NowPlayingComponent._likedTracks.add(urn);
        btn.classList.add('active');
        svg.setAttribute('fill', 'var(--accent)');
        svg.setAttribute('stroke', 'var(--accent)');
      } else {
        NowPlayingComponent._likedTracks.delete(urn);
        btn.classList.remove('active');
        svg.setAttribute('fill', 'none');
        svg.setAttribute('stroke', 'currentColor');
      }
    }

    
    const currentTrack = Store.get('currentTrack');
    if (currentTrack && currentTrack.urn === urn) {
      NowPlayingComponent._updateTrackInfo();
    }
  },

  _tilt3D(el, e) { el.style.transition = 'none'; },
  _tiltMove(el, e) {
    const rect = el.getBoundingClientRect();
    const dx = (e.clientX - (rect.left + rect.width / 2))  / (rect.width / 2);
    const dy = (e.clientY - (rect.top  + rect.height / 2)) / (rect.height / 2);
    el.style.transform = `perspective(500px) rotateX(${-dy * 12}deg) rotateY(${dx * 12}deg) scale3d(1.03,1.03,1.03)`;
  },
  _tiltReset(el) {
    el.style.transition = 'transform 0.5s cubic-bezier(0.16,1,0.3,1)';
    el.style.transform  = '';
  },
};


const ContextMenu = {
  _el: null,

  showByUrn(e, urn) {
    const track = TrackRegistry.get(urn);
    if (!track) { e.preventDefault(); return; }
    this.show(e, track);
  },

  
  showUpward(e, track, fromPlayer = false) {
    this.show(e, track, true, fromPlayer);
  },

  show(e, track, forceUpward = false, fromPlayer = false) {
    e.preventDefault();
    e.stopPropagation();
    this._close();

    const isLiked = NowPlayingComponent._likedTracks.has(track.urn);
    const hasArtwork = !!track.artwork_url;

    
    const isArtistOpen = !!document.getElementById('artist-modal');
    const showHide = !isArtistOpen;

    const menu = document.createElement('div');
    menu.className = 'ctx-menu';

    
    const showSWItems = fromPlayer && typeof SoundWave !== 'undefined' && SoundWave.isActive() && SoundWave.isTrackFromWave(track.urn);

    
    const menuEstimatedHeight = (showHide ? 340 : 300) + (showSWItems ? 75 : 0);
    const menuWidth = 230;
    const spaceBelow = window.innerHeight - e.clientY;
    const spaceRight = window.innerWidth - e.clientX;
    const openUp = forceUpward || spaceBelow < menuEstimatedHeight;

    const x = spaceRight < menuWidth ? window.innerWidth - menuWidth - 8 : e.clientX;
    let y;
    if (openUp) {
      y = -9999;
      menu.dataset.openUp = '1';
    } else {
      y = Math.min(e.clientY, window.innerHeight - menuEstimatedHeight);
    }
    menu.style.cssText = `left:${x}px;top:${y}px`;

    menu.innerHTML = `
      ${showSWItems ? `
        <div class="ctx-item ctx-not-interested-artist" data-action="not-interested-artist">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/><line x1="2" y1="2" x2="22" y2="22"/></svg>
          Не интересует артист
        </div>
        <div class="ctx-item ctx-not-interested" data-action="not-interested">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="10"/><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"/></svg>
          Не интересует трек
        </div>
        <div class="ctx-sep"></div>
      ` : ''}
      <div class="ctx-item" data-action="play">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg> Слушать
      </div>
      <div class="ctx-item" data-action="like">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="${isLiked ? 'var(--accent)' : 'none'}" stroke="${isLiked ? 'var(--accent)' : 'currentColor'}" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
        ${isLiked ? 'Убрать из любимых' : 'В любимые'}
      </div>
      <div class="ctx-item" data-action="queue">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/></svg> В очередь
      </div>
      <div class="ctx-item" data-action="playlist">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg> В плейлист
      </div>
      <div class="ctx-sep"></div>
      <div class="ctx-item" data-action="wave">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M2 12c1-3 3-5 5-5s4 4 5 4 3-6 5-6 4 3 5 7"/></svg> Трек по волне
      </div>
      <div class="ctx-item" data-action="page">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/></svg> Страница трека
      </div>
      <div class="ctx-item" data-action="artist">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg> Об артисте
      </div>
      ${!hasArtwork ? `<div class="ctx-item" data-action="reload-img">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg> Перезагрузка изображения
      </div>` : ''}
      <div class="ctx-sep"></div>
      <div class="ctx-item" data-action="open-sc">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6M15 3h6v6M10 14L21 3"/></svg> Открыть на <span style="color:#ff7700;font-weight:600">SoundCloud</span>
      </div>
      <div class="ctx-item" data-action="copy-sc">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg> Скопировать ссылку <span style="color:#ff7700;font-weight:600">SoundCloud</span>
      </div>
      ${showHide ? `
        <div class="ctx-sep"></div>
        <div class="ctx-item ctx-danger" data-action="hide">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 12H3M3 12l7-7M3 12l7 7"/></svg> Скрыть
        </div>
      ` : ''}
      ${(typeof LocalLikes !== 'undefined' && LocalLikes.hasTrack(track.urn)) ? `
        <div class="ctx-sep"></div>
        <div class="ctx-item" data-action="ll-try-like" style="color:#4caf50">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#4caf50" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
          Попробовать лайкнуть
        </div>
        <div class="ctx-item ctx-danger" data-action="ll-remove">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
          Удалить из «Локально Нравится»
        </div>
      ` : ''}
    `;

    menu.addEventListener('click', (ev) => {
      const item = ev.target.closest('[data-action]');
      if (!item) return;
      const action = item.dataset.action;
      this._close();
      const t = TrackRegistry.get(track.urn) || track;
      switch (action) {
        case 'not-interested-artist':
          if (typeof SoundWave !== 'undefined') SoundWave.notInterestedArtist(t);
          break;
        case 'not-interested':
          if (typeof SoundWave !== 'undefined') SoundWave.notInterested(t);
          break;
        case 'play': {
          
          TrackCardComponent.play(t.urn);
          break;
        }
        case 'like': {
          
          if (typeof LocalLikes !== 'undefined' && LocalLikes.hasTrack(t.urn)) {
            LocalLikes.tryLikeAndRemove(t.urn).then(ok => {
              if (ok) {
                NowPlayingComponent._likedTracks.add(t.urn);
                const cur = Store.get('currentTrack');
                if (cur && cur.urn === t.urn) NowPlayingComponent._updateTrackInfo();
              }
            });
            break;
          }
          const wasLiked = NowPlayingComponent._likedTracks.has(t.urn);
          
          if (wasLiked) {
            NowPlayingComponent._likedTracks.delete(t.urn);
            NowPlayingComponent._removeFromLikedSection(t.urn);
          } else {
            NowPlayingComponent._likedTracks.add(t.urn);
            NowPlayingComponent._animateLike(t);
          }
          
          const cur = Store.get('currentTrack');
          if (cur && cur.urn === t.urn) NowPlayingComponent._updateTrackInfo();
          
          (async () => {
            try {
              await LikeQueue.enqueue(t.urn, wasLiked ? 'unlike' : 'like');
              Utils.log('info', `[CtxLike] ${wasLiked ? 'Unlike' : 'Like'} OK: ${t.title}`);
            } catch (err) {
              
              Utils.log('error', `[CtxLike] Error: ${err.message}`);
              if (wasLiked) {
                NowPlayingComponent._likedTracks.add(t.urn);
              } else {
                NowPlayingComponent._likedTracks.delete(t.urn);
                NowPlayingComponent._removeFromLikedSection(t.urn);
              }
              if (cur && cur.urn === t.urn) NowPlayingComponent._updateTrackInfo();
            }
          })();
          break;
        }
        
        case 'queue':
          if (Store.get('repeat') === 'one') {
            Utils.toast('У вас стоит трек на повторе, никак не получится проиграть его следующим', 2500, 'repeat-mode');
            Utils.log('info', '[Queue] Blocked add-to-queue: repeat=one active');
          } else {
            Store.addToQueue([t]);
            Utils.toast('Добавлено в очередь');
            Utils.log('info', '[Queue] Track added to queue: ' + t.title);
          }
          break;
        case 'playlist': PlaylistPickerModal.open(t); break;
        case 'page': TrackPage.open(t); break;
        case 'wave':
          if (typeof SoundWave !== 'undefined') {
            SoundWave.startByTrack(t);
            Utils.log('info', '[Context] Wave by track: ' + t.title);
          }
          break;
        case 'artist': ArtistPage.openFromUrn(t.user?.urn || '', t.user?.username || ''); break;
        case 'reload-img': this._reloadImage(t); break;
        
        case 'open-sc': {
          const scUrl = t.permalink_url || ('https://soundcloud.com/' + (t.user?.permalink || '') + '/' + (t.permalink || ''));
          window.open(scUrl, '_blank');
          Utils.log('info', '[Context] Opened on SoundCloud: ' + scUrl);
          break;
        }
        case 'copy-sc': {
          const scUrl2 = t.permalink_url || ('https://soundcloud.com/' + (t.user?.permalink || '') + '/' + (t.permalink || ''));
          navigator.clipboard.writeText(scUrl2).then(() => {
            Utils.toast('Вы успешно скопировали ссылку');
            Utils.log('info', '[Context] Copied SoundCloud link: ' + scUrl2);
          }).catch(() => Utils.toast('Не удалось скопировать', 2500, 'copy-fail'));
          break;
        }
        case 'hide': this._hideCard(t.urn); break;
        case 'll-remove': {
          if (typeof LocalLikes !== 'undefined') {
            LocalLikes.removeTrack(t.urn);
            Utils.toast('Удалено из «Локально Нравится»');
            
            if (Store.get('currentPage') === 'home' && typeof HomePage !== 'undefined') HomePage.render();
            else if (typeof PlaylistsPage !== 'undefined' && PlaylistsPage._currentPl?.isLocalLikes) {
              PlaylistsPage.openPlaylist(PlaylistsPage._currentPl.id);
            }
          }
          break;
        }
        case 'll-try-like': {
          if (typeof LocalLikes !== 'undefined') {
            LocalLikes.tryLikeAndRemove(t.urn).then(ok => {
              if (ok && Store.get('currentPage') === 'home' && typeof HomePage !== 'undefined') HomePage.render();
              else if (ok && typeof PlaylistsPage !== 'undefined' && PlaylistsPage._currentPl?.isLocalLikes) {
                PlaylistsPage.openPlaylist(PlaylistsPage._currentPl.id);
              }
            });
          }
          break;
        }
      }
    });

    document.body.appendChild(menu);
    this._el = menu;

    
    if (menu.dataset.openUp === '1') {
      const actualH = menu.offsetHeight || 320;
      const topY = Math.max(8, e.clientY - actualH - 8);
      menu.style.top = topY + 'px';
    }

    requestAnimationFrame(() => menu.classList.add('open'));
    setTimeout(() => document.addEventListener('click', () => this._close(), { once: true }), 10);
  },

  
  _hideCard(urn) {
    
    const recent = (Store.get('recentlyPlayed') || []).filter(t => t.urn !== urn);
    Store.set({ recentlyPlayed: recent });

    
    const escaped = CSS.escape(urn);
    document.querySelectorAll(`[data-urn="${escaped}"]`).forEach(card => {
      
      const container =
        card.closest('.h-scroll-item') ||
        card.closest('.overlay-item') ||
        card.closest('.track-row') ||
        card.closest('.feed-card') ||
        card;
      container.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
      container.style.opacity    = '0';
      container.style.transform  = 'scale(0.88)';
      setTimeout(() => {
        const h = container.offsetHeight;
        container.style.transition += ', max-height 0.3s ease, margin 0.3s ease, padding 0.3s ease';
        container.style.maxHeight  = h + 'px';
        container.style.overflow   = 'hidden';
        requestAnimationFrame(() => {
          container.style.maxHeight    = '0';
          container.style.marginBottom = '0';
          container.style.paddingBottom = '0';
        });
        setTimeout(() => container.remove(), 320);
      }, 290);
    });
  },

  async _reloadImage(track) {
    Utils.log('info', '[ReloadImg] Starting image reload for: ' + track.title);
    Utils.toast('Перезагрузка изображения...');
    const card = document.querySelector('[data-urn="' + CSS.escape(track.urn) + '"]');
    if (!card) return;

    
    const artWrap = card.querySelector('.track-card-art, .search-row-art, .feed-card-art');
    if (artWrap) {
      const spinner = document.createElement('div');
      spinner.className = 'img-reload-spinner';
      spinner.innerHTML = '<div class="spinner-inline" style="width:24px;height:24px"></div>';
      artWrap.appendChild(spinner);
    }

    
    let origUrl = track.artwork_url;
    if (!origUrl) {
      try {
        Utils.log('info', '[ReloadImg] No artwork_url, fetching from API...');
        const freshTrack = await API.getTrack(track.urn);
        if (freshTrack && freshTrack.artwork_url) {
          origUrl = freshTrack.artwork_url;
          
          track.artwork_url = origUrl;
          TrackRegistry.reg(track);
        }
      } catch (e) {
        Utils.log('warning', '[ReloadImg] API fetch failed: ' + e.message);
      }
    }

    if (!origUrl) {
      document.querySelectorAll('.img-reload-spinner').forEach(s => s.remove());
      Utils.toast('Обложка не найдена на SoundCloud');
      return;
    }

    const hiRes = origUrl.replace('-large', '-t500x500');

    for (let m = 0; m < 12; m++) {
      try {
        const proxyUrl = m === 0 ? hiRes : '/imgproxy?url=' + encodeURIComponent(hiRes) + '&m=' + m;
        const ok = await new Promise((resolve) => {
          const img = new Image();
          const timer = setTimeout(() => { img.src = ''; resolve(false); }, 6000);
          img.onload = () => { clearTimeout(timer); resolve(img.naturalWidth > 0 ? proxyUrl : false); };
          img.onerror = () => { clearTimeout(timer); resolve(false); };
          img.src = proxyUrl + (proxyUrl.includes('?') ? '&' : '?') + '_t=' + Date.now();
        });
        if (ok) {
          document.querySelectorAll('[data-urn="' + CSS.escape(track.urn) + '"]').forEach(c => {
            const imgEl = c.querySelector('.track-card-art img, .search-row-art img, .feed-card-art img');
            if (imgEl) imgEl.src = ok;
            else {
              
              const wrap = c.querySelector('.track-card-art, .search-row-art, .feed-card-art');
              if (wrap) { const newImg = document.createElement('img'); newImg.src = ok; newImg.alt = ''; wrap.prepend(newImg); }
            }
            const spinner = c.querySelector('.img-reload-spinner');
            if (spinner) spinner.remove();
          });
          Utils.toast('Обложка загружена!');
          Utils.log('info', '[ReloadImg] Success with method ' + m);
          return;
        }
      } catch {}
    }
    
    document.querySelectorAll('.img-reload-spinner').forEach(s => s.remove());
    Utils.toast('Не удалось загрузить обложку');
    Utils.log('warning', '[ReloadImg] All methods failed for: ' + track.title);
  },

  _close() {
    if (!this._el) return;
    this._el.classList.remove('open');
    const el = this._el;
    this._el = null;
    setTimeout(() => el?.remove(), 200);
  },
};
