

const LRCLIB_API     = 'https://lrclib.net/api';
const MX_PROXY_API   = '/api/musixmatch/lyrics';
const LYRICS_TIMEOUT = 12000;


function _parseLRC(lrc) {
  const lines = [];
  for (const raw of lrc.split('\n')) {
    const m = raw.match(/^\[(\d{2}):(\d{2})\.(\d{2,3})\]\s*(.*)/);
    if (!m) continue;
    const time = +m[1] * 60 + +m[2] + +m[3].padEnd(3, '0') / 1000;
    const text = m[4].trim();
    if (text) lines.push({ time, text });
  }
  return lines.length > 0 ? lines : null;
}


function _clean(s) {
  return s
    .replace(/\(feat\.?[^)]*\)/gi,'')
    .replace(/\(ft\.?[^)]*\)/gi,'')
    .replace(/\[.*?\]/g,'')
    .replace(/\(.*?(remix|edit|version|mix|cover|live|acoustic|instrumental|original|prod).*?\)/gi,'')
    
    .replace(/\s*prod\.?\s*[@]?\s*\S+$/gi,'')
    
    .replace(/\s*\(?\s*(super\s+)?slowed(\s*[\+&]\s*reverb)?\s*\)?\s*$/gi,'')
    .replace(/\s*\(?\s*sped\s+up\s*\)?\s*$/gi,'')
    .replace(/\s*\(?\s*speed\s*up\s*\)?\s*$/gi,'')
    .replace(/\s*\(?\s*nightcore\s*\)?\s*$/gi,'')
    .replace(/\s*\(?\s*full\s+song\s*\)?\s*$/gi,'')
    .replace(/\s*\(?\s*best\s+part\s*\)?\s*$/gi,'')
    .replace(/\s*\(?\s*bass\s+boosted\s*\)?\s*$/gi,'')
    
    .replace(/\.mp3\s*$/gi,'')
    .replace(/\s+/g,' ').trim();
}

function _deepClean(s) {
  return _clean(s)
    .replace(/\b(slowed|reverb|sped|speed|nightcore|phonk|tiktok|edit)\b/gi,'')
    .replace(/\s+/g,' ').trim();
}
function _alphaOnly(s) { return s.replace(/[^\p{L}\p{N}\s]/gu,'').replace(/\s+/g,' ').trim(); }
function _splitAT(raw) {
  for (const sep of [' - ',' – ',' — ',' // ']) {
    const idx = raw.indexOf(sep);
    if (idx > 0) { const a = raw.slice(0,idx).trim(), t = raw.slice(idx+sep.length).trim(); if (a && t) return [a,t]; }
  }
  
  return null;
}


async function _lrclibFetch(params, signal) {
  try {
    const res = await fetch(`${LRCLIB_API}/search?${new URLSearchParams(params)}`, {signal});
    if (!res.ok) return null;
    const d = await res.json();
    if (!d?.length) return null;
    const entry = d[0];
    const plain  = entry.plainLyrics  || null;
    const synced = entry.syncedLyrics ? _parseLRC(entry.syncedLyrics) : null;
    if (!plain && !synced) return null;
    return { plain, synced, source: 'lrclib' };
  } catch { return null; }
}
async function _searchLrclib(artist, title) {
  const ctrl = new AbortController();
  const tid  = setTimeout(() => ctrl.abort(), LYRICS_TIMEOUT);
  const sig  = ctrl.signal;
  try {
    const parsed = _splitAT(title);
    if (parsed) {
      const [a,t] = parsed;
      let r = await _lrclibFetch({artist_name:a,track_name:t},sig); if(r) return r;
      const ca=_clean(a),ct=_clean(t);
      r = await _lrclibFetch({artist_name:ca,track_name:ct},sig); if(r) return r;
      
      const dct = _deepClean(t);
      if (dct && dct !== ct) { r = await _lrclibFetch({artist_name:ca,track_name:dct},sig); if(r) return r; }
      const aa=_alphaOnly(ca),at=_alphaOnly(dct||ct);
      if(aa!==ca||at!==ct){r=await _lrclibFetch({artist_name:aa,track_name:at},sig);if(r)return r;}
    }
    const ct=_clean(title);
    let r=await _lrclibFetch({artist_name:artist,track_name:ct},sig);if(r)return r;
    
    const dct = _deepClean(title);
    if (dct && dct !== ct) { r=await _lrclibFetch({artist_name:artist,track_name:dct},sig);if(r)return r; }
    const at=_alphaOnly(dct||ct);
    if(at!==ct){r=await _lrclibFetch({artist_name:artist,track_name:at},sig);if(r)return r;}
    const q=parsed?`${parsed[0]} ${_deepClean(parsed[1])}`:`${artist} ${dct}`;
    r=await _lrclibFetch({q:_alphaOnly(q)},sig);if(r)return r;
    if(parsed){r=await _lrclibFetch({q:_alphaOnly(_deepClean(parsed[1]))},sig);if(r)return r;}
    return null;
  } finally { clearTimeout(tid); }
}


async function _searchMusixmatch(artist, title) {
  const parsed = _splitAT(title);
  const queries = [];
  if (parsed) {
    queries.push({ artist: parsed[0], title: _clean(parsed[1]) });
    queries.push({ artist: _clean(parsed[0]), title: _clean(parsed[1]) });
    
    const dc = _deepClean(parsed[1]);
    if (dc && dc !== _clean(parsed[1])) queries.push({ artist: _clean(parsed[0]), title: dc });
  }
  queries.push({ artist: artist, title: _clean(title) });
  
  const dcTitle = _deepClean(title);
  if (dcTitle && dcTitle !== _clean(title)) queries.push({ artist: artist, title: dcTitle });
  
  if (parsed) queries.push({ artist: '', title: `${_clean(parsed[0])} ${_deepClean(parsed[1])}` });
  
  const finalQ = parsed ? _deepClean(parsed[1]) : dcTitle;
  if (finalQ && finalQ.length > 2) queries.push({ artist: '', title: finalQ });

  
  const seen = new Set();
  const uniqueQueries = queries.filter(q => {
    const key = `${q.artist.toLowerCase()}|${q.title.toLowerCase()}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });

  for (const q of uniqueQueries) {
    if (!q.title || q.title.length < 2) continue;
    const ctrl = new AbortController();
    const tid = setTimeout(() => ctrl.abort(), LYRICS_TIMEOUT);
    try {
      const params = new URLSearchParams({ artist: q.artist, title: q.title });
      const res = await fetch(`${MX_PROXY_API}?${params}`, { signal: ctrl.signal });
      clearTimeout(tid);
      if (!res.ok) continue;
      const data = await res.json();
      const synced = data.synced ? _parseLRC(data.synced) : null;
      const plain  = data.plain || null;
      if (synced || plain) {
        Utils.log('info', `[Lyrics/MX] Found: "${q.artist}" / "${q.title}" synced=${!!synced} plain=${!!plain}`);
        return { plain, synced, source: 'musixmatch' };
      }
    } catch (e) {
      clearTimeout(tid);
      if (e.name !== 'AbortError') Utils.log('info', `[Lyrics/MX] Query error: ${e.message || e}`);
    }
  }
  return null;
}


const _lyricsCache = new Map();

function _cacheGet(urn) { return _lyricsCache.get(urn) || null; }
function _cacheSet(urn, provider, value) {
  if (!_lyricsCache.has(urn)) _lyricsCache.set(urn, { lrclib: 'pending', musixmatch: 'pending' });
  _lyricsCache.get(urn)[provider] = value;
}
function _cacheHasAny(urn) {
  const c = _lyricsCache.get(urn);
  if (!c) return false;
  return (c.lrclib && c.lrclib !== 'pending') || (c.musixmatch && c.musixmatch !== 'pending');
}
function _cacheHasResult(urn) {
  const c = _lyricsCache.get(urn);
  if (!c) return false;
  const l = c.lrclib, m = c.musixmatch;
  return (l && l !== 'pending' && (l.synced || l.plain)) || (m && m !== 'pending' && (m.synced || m.plain));
}
function _cacheBothDone(urn) {
  const c = _lyricsCache.get(urn);
  if (!c) return false;
  return c.lrclib !== 'pending' && c.musixmatch !== 'pending';
}


const LyricsComponent = {
  _open:         false,
  _track:        null,
  _activeSource: null,   
  _syncTimer:    null,
  _activeLine:   -1,
  _lineEls:      [],
  _progressUnsub: null,
  _searchGen:    0,      

  init() {
    Utils.log('info', '[Lyrics] Karaoke v4 initialized (progressive LRCLIB + Musixmatch)');
    Store.on('currentTrack', (track) => {
      if (track) this._preCheckLyrics(track);
      if (this._open) {
        if (track && (!this._track || this._track.urn !== track.urn)) {
          this._track = track;
          this._reload();
        } else if (!track) {
          this._smoothClose();
        }
      }
    });
    Store.on('isPlaying', () => {});
    const cur = Store.get('currentTrack');
    if (cur) this._preCheckLyrics(cur);
    
    fetch('/api/musixmatch/status').catch(() => {});
  },

  
  async _preCheckLyrics(track) {
    if (!track?.urn) return;
    
    if (_cacheBothDone(track.urn)) {
      this._updateLyricsButton(track.urn);
      return;
    }
    const urn = track.urn;
    const artist = track.user?.username || '';
    const title  = track.title || '';

    
    _cacheSet(urn, 'lrclib', 'pending');
    _cacheSet(urn, 'musixmatch', 'pending');

    Utils.log('info', `[Lyrics] Pre-check starting: "${title}"`);

    
    _searchLrclib(artist, title).then(r => {
      _cacheSet(urn, 'lrclib', r);
      Utils.log('info', `[Lyrics] LRCLIB done for "${title}": ${r ? (r.synced ? 'synced' : 'plain') : 'none'}`);
      this._updateLyricsButton(urn);
      
      if (this._open && this._track?.urn === urn && !this._activeSource) {
        if (r) this._onProviderReady(urn, 'lrclib', r);
      }
      
      if (this._open && this._track?.urn === urn) this._renderSourceToggle();
    }).catch(() => {
      _cacheSet(urn, 'lrclib', null);
      this._updateLyricsButton(urn);
      if (this._open && this._track?.urn === urn) this._renderSourceToggle();
    });

    
    _searchMusixmatch(artist, title).then(r => {
      _cacheSet(urn, 'musixmatch', r);
      Utils.log('info', `[Lyrics] MX done for "${title}": ${r ? (r.synced ? 'synced' : 'plain') : 'none'}`);
      this._updateLyricsButton(urn);
      
      if (this._open && this._track?.urn === urn && !this._activeSource) {
        if (r) this._onProviderReady(urn, 'musixmatch', r);
      }
      
      if (this._open && this._track?.urn === urn) this._renderSourceToggle();
      
      if (this._open && this._track?.urn === urn && _cacheBothDone(urn) && !_cacheHasResult(urn)) {
        this._setLyricsState('not_found');
        setTimeout(() => { if (this._open && this._track?.urn === urn) this._smoothClose(); }, 2000);
      }
    }).catch(() => {
      _cacheSet(urn, 'musixmatch', null);
      this._updateLyricsButton(urn);
      if (this._open && this._track?.urn === urn) this._renderSourceToggle();
      if (this._open && this._track?.urn === urn && _cacheBothDone(urn) && !_cacheHasResult(urn)) {
        this._setLyricsState('not_found');
        setTimeout(() => { if (this._open && this._track?.urn === urn) this._smoothClose(); }, 2000);
      }
    });
  },

  
  _onProviderReady(urn, source, data) {
    if (this._track?.urn !== urn || !this._open) return;
    
    const cache = _cacheGet(urn);
    const other = source === 'lrclib' ? cache?.musixmatch : cache?.lrclib;
    const otherReady = other && other !== 'pending';

    
    if (otherReady && other?.synced && !data.synced) {
      this._activeSource = source === 'lrclib' ? 'musixmatch' : 'lrclib';
    } else {
      this._activeSource = source;
    }

    const active = this._activeSource;
    const activeData = active === source ? data : other;
    if (!activeData || activeData === 'pending') return;

    Utils.log('info', `[Lyrics] Progressive render: source=${active} for "${this._track?.title}"`);
    this._stopSync();
    this._activeLine = -1;
    this._lineEls = [];
    if (activeData.synced) {
      this._renderSynced(activeData.synced);
      this._startSync(activeData.synced);
    } else if (activeData.plain) {
      this._renderPlain(activeData.plain);
    }
  },

  _onTrackReady() {
    const track = Store.get('currentTrack');
    if (track) this._preCheckLyrics(track);
  },

  _updateLyricsButton(urn) {
    const btn = document.getElementById('btn-lyrics');
    if (!btn) return;
    const cur = Store.get('currentTrack');
    if (cur?.urn !== urn) return;
    const has = _cacheHasResult(urn);
    btn.style.opacity = has ? '1' : (_cacheBothDone(urn) ? '0.25' : '0.5');
    btn.title = has ? 'Караоке' : (_cacheBothDone(urn) ? 'Текст не найден' : 'Поиск текста...');
  },

  toggle() { this._open ? this.close() : this.open(); },

  open() {
    if (this._open) return;
    const track = Store.get('currentTrack');
    
    if (_cacheBothDone(track?.urn) && !_cacheHasResult(track?.urn)) {
      Utils.toast('Для этого трека текст не найден', 2500, 'lyrics-not-found-' + (track?.urn || ''));
      return;
    }
    this._open = true;
    this._track = track;
    this._activeSource = null;
    this._activeLine = -1;
    this._lineEls = [];

    const main = document.getElementById('main-layout');
    if (main) main.classList.add('lyrics-blur');
    document.body.classList.add('karaoke-active');

    let el = document.getElementById('lyrics-panel');
    if (!el) { el = document.createElement('div'); el.id = 'lyrics-panel'; el.className = 'karaoke-v2'; document.getElementById('app').appendChild(el); }
    this._render(el, track);
    requestAnimationFrame(() => {
      el.classList.add('open');
      requestAnimationFrame(() => {
        if (typeof CommentsComponent !== 'undefined') { CommentsComponent._updateMaxVisible(); CommentsComponent._recenter(); }
      });
    });
    document.getElementById('btn-lyrics')?.classList.add('active');
    if (track) this._loadLyrics(track);
    this._progressUnsub = Player.subscribe(() => this._tickProgress());
  },

  close() {
    if (!this._open) return;
    this._open = false;
    this._stopSync();
    if (this._progressUnsub) { this._progressUnsub(); this._progressUnsub = null; }
    const main = document.getElementById('main-layout');
    if (main) main.classList.remove('lyrics-blur');
    document.body.classList.remove('karaoke-active');
    const el = document.getElementById('lyrics-panel');
    if (el) { el.classList.remove('open'); setTimeout(() => el.remove(), 350); }
    document.getElementById('btn-lyrics')?.classList.remove('active');
    if (typeof CommentsComponent !== 'undefined') {
      setTimeout(() => { CommentsComponent._updateMaxVisible(); CommentsComponent._recenter(); }, 60);
    }
    Utils.log('info', '[Lyrics] Karaoke closed');
  },

  _smoothClose() { this.close(); },

  _render(el, track) {
    const art500 = track ? Utils.art(track.artwork_url, 't500x500') : null;
    el.innerHTML = `
      <div class="karaoke-backdrop" id="karaoke-backdrop"></div>
      <div class="karaoke-content">
        <div class="karaoke-left">
          <div class="karaoke-art-wrap" id="karaoke-art-wrap" title="Открыть обложку">
            ${art500 ? `<img class="karaoke-art-img" src="${art500}" alt="" id="karaoke-art-img">` : `<div class="karaoke-art-empty"><svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" opacity="0.15"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg></div>`}
          </div>
          <div class="karaoke-meta">
            <div class="karaoke-title" id="karaoke-title" title="Открыть трек">${Utils.esc(track?.title || '')}</div>
            <div class="karaoke-artist" id="karaoke-artist" title="Открыть артиста">${Utils.esc(track?.user?.username || '')}</div>
          </div>
        </div>
        <div class="karaoke-right" id="karaoke-right">
          <div class="karaoke-source-toggle" id="karaoke-source-toggle"></div>
          <div class="karaoke-lyrics-content">
            <div class="karaoke-state"><div class="lp-spinner"></div><p>Загрузка текста...</p></div>
          </div>
        </div>
      </div>
    `;
    this._bindEvents(el, track);
  },

  _bindEvents(el, track) {
    document.getElementById('karaoke-backdrop').addEventListener('click', () => this.close());
    const artWrap = document.getElementById('karaoke-art-wrap');
    if (artWrap) artWrap.addEventListener('click', () => {
      if (track && typeof FullscreenArt !== 'undefined') FullscreenArt.open(track);
    });
    const titleEl = document.getElementById('karaoke-title');
    if (titleEl) titleEl.addEventListener('click', () => {
      if (track && typeof TrackPage !== 'undefined') TrackPage.open(track);
    });
    const artistEl = document.getElementById('karaoke-artist');
    if (artistEl) artistEl.addEventListener('click', () => {
      if (track?.user && typeof ArtistPage !== 'undefined') ArtistPage.open(track.user);
    });
    const escH = (e) => { if(e.key==='Escape') { this.close(); document.removeEventListener('keydown',escH); }};
    document.addEventListener('keydown', escH);
  },

  _tickProgress() {},

  
  _loadLyrics(track) {
    const urn = track.urn;
    const cache = _cacheGet(urn);

    
    if (cache) {
      
      const lrc = cache.lrclib;
      const mx  = cache.musixmatch;
      const lrcReady = lrc && lrc !== 'pending';
      const mxReady  = mx  && mx  !== 'pending';

      
      let best = null, bestSrc = null;
      if (lrcReady && lrc?.synced)  { best = lrc; bestSrc = 'lrclib'; }
      else if (mxReady && mx?.synced) { best = mx;  bestSrc = 'musixmatch'; }
      else if (lrcReady && lrc?.plain) { best = lrc; bestSrc = 'lrclib'; }
      else if (mxReady && mx?.plain)   { best = mx;  bestSrc = 'musixmatch'; }

      if (best) {
        this._activeSource = bestSrc;
        this._stopSync(); this._activeLine = -1; this._lineEls = [];
        if (best.synced) { this._renderSynced(best.synced); this._startSync(best.synced); }
        else this._renderPlain(best.plain);
        Utils.log('info', `[Lyrics] Cached render: source=${bestSrc} for "${track.title}"`);
      } else if (!lrcReady || !mxReady) {
        
        this._setLyricsState('loading');
      } else {
        
        this._setLyricsState('not_found');
        setTimeout(() => { if (this._open && this._track?.urn === urn) this._smoothClose(); }, 2000);
      }
    } else {
      
      this._setLyricsState('loading');
      this._preCheckLyrics(track);
    }

    
    this._renderSourceToggle();
  },

  
  _renderSourceToggle() {
    const toggle = document.getElementById('karaoke-source-toggle');
    if (!toggle || !this._track) return;
    const urn = this._track.urn;
    const cache = _cacheGet(urn);
    if (!cache) { toggle.innerHTML = ''; return; }

    const providers = [
      { key: 'musixmatch', label: 'Musixmatch', data: cache.musixmatch },
      { key: 'lrclib',     label: 'LRCLIB',     data: cache.lrclib },
    ];

    toggle.innerHTML = providers.map(p => {
      const isPending  = p.data === 'pending';
      const hasResult  = p.data && p.data !== 'pending' && (p.data.synced || p.data.plain);
      const hasSynced  = p.data && p.data !== 'pending' && p.data.synced;
      const notFound   = p.data !== 'pending' && !hasResult;
      const isActive   = p.key === this._activeSource;

      let stateHtml = '';
      if (isPending) stateHtml = '<span class="ks-loading"></span>';
      else if (hasSynced) stateHtml = '<span class="ks-badge ks-badge-sync">sync</span>';
      else if (hasResult) stateHtml = '<span class="ks-badge ks-badge-plain">text</span>';
      else stateHtml = '<span class="ks-badge ks-badge-none">—</span>';

      const disabled = !hasResult;
      return `<button class="ks-btn ${isActive ? 'ks-active' : ''} ${disabled ? 'ks-disabled' : ''}"
                      ${disabled ? 'disabled' : ''}
                      onclick="LyricsComponent._switchSource('${p.key}')">
                <span class="ks-label">${p.label}</span>${stateHtml}
              </button>`;
    }).join('');
  },

  _switchSource(source) {
    if (source === this._activeSource) return;
    const urn = this._track?.urn;
    const cache = _cacheGet(urn);
    if (!cache) return;
    const data = cache[source];
    if (!data || data === 'pending' || (!data.synced && !data.plain)) return;

    this._activeSource = source;
    this._stopSync(); this._activeLine = -1; this._lineEls = [];
    if (data.synced) { this._renderSynced(data.synced); this._startSync(data.synced); }
    else this._renderPlain(data.plain);
    this._renderSourceToggle();
    Utils.log('info', `[Lyrics] Switched to: ${source} (synced=${!!data.synced})`);
  },

  _reload() {
    this._stopSync();
    this._activeSource = null;
    this._activeLine = -1;
    this._lineEls = [];
    const art500 = this._track ? Utils.art(this._track.artwork_url, 't500x500') : null;
    const artEl = document.getElementById('karaoke-art-img');
    if (artEl && art500) artEl.src = art500;
    const titleEl = document.getElementById('karaoke-title');
    if (titleEl) titleEl.textContent = this._track?.title || '';
    const artistEl = document.getElementById('karaoke-artist');
    if (artistEl) artistEl.textContent = this._track?.user?.username || '';
    const newTrack = this._track;
    if (titleEl) titleEl.onclick = () => { if(newTrack && typeof TrackPage!=='undefined') TrackPage.open(newTrack); };
    if (artistEl) artistEl.onclick = () => { if(newTrack?.user && typeof ArtistPage!=='undefined') ArtistPage.open(newTrack.user); };
    const artWrap = document.getElementById('karaoke-art-wrap');
    if (artWrap) artWrap.onclick = () => { if(newTrack && typeof FullscreenArt!=='undefined') FullscreenArt.open(newTrack); };

    const urn = this._track?.urn;
    if (_cacheBothDone(urn) && !_cacheHasResult(urn)) { this._smoothClose(); return; }
    if (this._track) this._loadLyrics(this._track);

    
    if (urn) {
      setTimeout(() => {
        if (this._open && this._track?.urn === urn && !this._activeSource) {
          if (_cacheBothDone(urn) && !_cacheHasResult(urn)) {
            Utils.log('info', `[Lyrics] Safety close: no lyrics found for "${newTrack?.title}" after 8s`);
            this._smoothClose();
          }
        }
      }, 8000);
    }
  },

  _setLyricsState(state) {
    const right = document.getElementById('karaoke-right');
    if (!right) return;
    
    let content = right.querySelector('.karaoke-lyrics-content');
    if (!content) {
      
      content = document.createElement('div');
      content.className = 'karaoke-lyrics-content';
      right.appendChild(content);
    }
    if (state === 'loading') {
      content.innerHTML = `<div class="karaoke-state"><div class="lp-spinner"></div><p>Загрузка текста...</p></div>`;
    } else {
      content.innerHTML = `<div class="karaoke-state">
        <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2" opacity="0.15"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>
        <p class="karaoke-state-title">Текст не найден</p>
      </div>`;
    }
  },

  _renderPlain(text) {
    const right = document.getElementById('karaoke-right');
    if (!right) return;
    let content = right.querySelector('.karaoke-lyrics-content');
    if (!content) { content = document.createElement('div'); content.className = 'karaoke-lyrics-content'; right.appendChild(content); }
    content.innerHTML = `<div class="karaoke-plain"><div class="karaoke-plain-text">${Utils.esc(text).replace(/\n/g,'<br>')}</div></div>`;
  },

  _renderSynced(lines) {
    const right = document.getElementById('karaoke-right');
    if (!right) return;
    let content = right.querySelector('.karaoke-lyrics-content');
    if (!content) { content = document.createElement('div'); content.className = 'karaoke-lyrics-content'; right.appendChild(content); }
    content.innerHTML = `<div class="karaoke-synced" id="karaoke-synced">${lines.map((l,i)=>`<div class="karaoke-line" data-idx="${i}" data-time="${l.time}">${Utils.esc(l.text)}</div>`).join('')}<div style="height:50vh"></div></div>`;
    this._lineEls = Array.from(content.querySelectorAll('.karaoke-line'));
    this._lineEls.forEach(el => {
      el.addEventListener('click', () => Player.seek(parseFloat(el.dataset.time)));
    });
  },

  _startSync(lines) {
    this._stopSync();
    let loggedOnce = false;
    let _scrollTarget = -1, _scrollCurrent = -1;
    const syncFrame = () => {
      this._syncRaf = requestAnimationFrame(syncFrame);
      const ct = document.getElementById('karaoke-synced');
      if (!ct) return;
      if (!this._lineEls.length) {
        this._lineEls = Array.from(ct.querySelectorAll('.karaoke-line'));
        if (!this._lineEls.length) return;
      }
      const time = Player.getCurrentTime();
      if (!loggedOnce && time > 0) { Utils.log('info', `[Lyrics] Sync active, time=${time.toFixed(1)}s, lines=${this._lineEls.length}`); loggedOnce = true; }
      let idx = -1;
      for (let i = lines.length - 1; i >= 0; i--) { if (lines[i].time <= time + 0.3) { idx = i; break; } }
      if (_scrollTarget >= 0) {
        if (_scrollCurrent < 0) _scrollCurrent = ct.scrollTop;
        const diff = _scrollTarget - _scrollCurrent;
        if (Math.abs(diff) > 0.5) { _scrollCurrent += diff * 0.12; ct.scrollTop = _scrollCurrent; }
        else { _scrollCurrent = _scrollTarget; ct.scrollTop = _scrollTarget; }
      }
      if (idx === this._activeLine) return;
      const prev = this._activeLine;
      this._activeLine = idx;
      if (prev >= 0 && prev < this._lineEls.length) { this._lineEls[prev].classList.remove('karaoke-active'); this._lineEls[prev].classList.add('karaoke-past'); }
      if (idx >= 0 && idx < this._lineEls.length) {
        this._lineEls[idx].classList.remove('karaoke-past');
        this._lineEls[idx].classList.add('karaoke-active');
        const elTop = this._lineEls[idx].offsetTop, elH = this._lineEls[idx].clientHeight, ctH = ct.clientHeight;
        _scrollTarget = elTop - ctH / 2 + elH / 2;
        if (_scrollCurrent < 0) _scrollCurrent = ct.scrollTop;
      }
      for (let i = 0; i < this._lineEls.length; i++) {
        if (i < idx) { if (!this._lineEls[i].classList.contains('karaoke-past')) this._lineEls[i].classList.add('karaoke-past'); this._lineEls[i].classList.remove('karaoke-active'); }
        else if (i > idx) { this._lineEls[i].classList.remove('karaoke-past', 'karaoke-active'); }
      }
    };
    this._syncRaf = requestAnimationFrame(syncFrame);
  },

  _stopSync() {
    if (this._syncTimer) { clearInterval(this._syncTimer); this._syncTimer = null; }
    if (this._syncRaf) { cancelAnimationFrame(this._syncRaf); this._syncRaf = null; }
    this._activeLine = -1; this._lineEls = [];
  },
};
