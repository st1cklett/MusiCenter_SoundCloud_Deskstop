

const CommentsComponent = {
  _comments: [],
  _shownIds: new Set(),
  _currentTrackUrn: null,
  _activeElements: [],
  _enabled: true,
  _maxVisible: 3,
  _userPressedPlay: false,  
  _commentsLoaded: false,

  
  _SLOT_H: 62,

  
  _calcMaxVisible() {
    if (document.body.classList.contains('karaoke-active')) {
      return this._calcMaxVisibleKaraoke();
    }
    
    const h = window.innerHeight;
    if (h < 540) return 1;
    if (h < 720) return 2;
    if (h < 960) return 3;
    return 4;
  },

  _calcMaxVisibleKaraoke() {
    const SLOT   = this._SLOT_H;
    const MARGIN = 12; 

    
    const meta    = document.querySelector('.karaoke-meta');
    const artWrap = document.getElementById('karaoke-art-wrap');
    let blockBottom = 0;
    if (meta) {
      blockBottom = meta.getBoundingClientRect().bottom;
    } else if (artWrap) {
      blockBottom = artWrap.getBoundingClientRect().bottom;
    }
    if (!blockBottom) return 1; 

    
    const playerTop = window.innerHeight - 90;
    
    const available = playerTop - blockBottom - MARGIN;

    if (available < SLOT)           return 0; 
    if (available < SLOT * 2 + 8)   return 1;
    if (available < SLOT * 3 + 16)  return 2;
    return 3; 
  },

  
  _updateMaxVisible() {
    const newMax = this._calcMaxVisible();
    if (newMax === this._maxVisible) return;
    this._maxVisible = newMax;
    while (this._activeElements.length > this._maxVisible) this._removeOldest();
  },

  init() {
    
    this._maxVisible = this._calcMaxVisible();
    window.addEventListener('resize', () => {
      this._updateMaxVisible();
    });

    Store.on('currentTrack', (track) => {
      if (track?.urn !== this._currentTrackUrn) {
        this._currentTrackUrn = track?.urn || null;
        this._comments = [];
        this._shownIds.clear();
        this._clearAll();
        this._commentsLoaded = false;
        Utils.log('info', '[Comments] Track changed: ' + (track?.title || 'none'));

        
        if (Store.get('isPlaying') && track) {
          this._userPressedPlay = true;
          this._loadComments(track.urn);
          Utils.log('info', '[Comments] Already playing, loading comments immediately');
        } else {
          this._userPressedPlay = false;
        }
      }
    });

    
    Store.on('isPlaying', (playing) => {
      if (playing && !this._commentsLoaded && this._currentTrackUrn) {
        this._userPressedPlay = true;
        this._loadComments(this._currentTrackUrn);
        Utils.log('info', '[Comments] Play pressed, loading comments');
      }
    });

    Player.subscribe(Utils.throttle(() => this._tick(), 500));

    
    const _karaokeObserver = new MutationObserver(() => {
      setTimeout(() => this._updateMaxVisible(), 150); 
    });
    _karaokeObserver.observe(document.body, { attributes: true, attributeFilter: ['class'] });
  },

  async _loadComments(urn) {
    try {
      
      const cached = SessionCache.getComments(urn);
      if (cached) {
        if (this._currentTrackUrn !== urn) return;
        this._comments = cached;
        this._shownIds.clear();
        this._commentsLoaded = true;
        Utils.log('info', '[Comments] Using cached ' + cached.length + ' comments');
        return;
      }
      const data = await API.getTrackComments(urn, 200);
      if (this._currentTrackUrn !== urn) return;
      this._comments = (data.collection || [])
        .filter(c => c.timestamp != null && c.body)
        .sort((a, b) => a.timestamp - b.timestamp);
      this._shownIds.clear();
      this._commentsLoaded = true;
      
      SessionCache.setComments(urn, this._comments);
      Utils.log('info', '[Comments] Loaded & cached ' + this._comments.length + ' comments');
    } catch (e) { console.warn('[Comments] Failed to load:', e); }
  },

  _tick() {
    if (!this._enabled || !this._comments.length || !this._userPressedPlay) return;
    
    if (Player._loading) return;
    if (!Player.isPlaying()) return;
    const currentMs = Player.getCurrentTime() * 1000;
    const threshold = 2000;
    for (const comment of this._comments) {
      if (this._shownIds.has(comment.id)) continue;
      if (Math.abs(comment.timestamp - currentMs) < threshold) {
        this._shownIds.add(comment.id);
        this._showComment(comment);
        break;
      }
    }
  },

  _showComment(comment) {
    while (this._activeElements.length >= this._maxVisible) this._removeOldest();

    const overlay = document.getElementById('comments-overlay');
    
    this._recenter();

    const avatar = Utils.art(comment.user?.avatar_url, 'small') || '';

    const el = document.createElement('div');
    el.className = 'timed-comment entering';
    el.dataset.cid = comment.id;
    el.dataset.ts  = comment.timestamp;
    el.title = 'Открыть страницу трека с этим комментарием';

    el.innerHTML = `
      <div class="timed-comment-avatar">
        ${avatar
          ? `<img src="${Utils.esc(avatar)}" alt="" onerror="this.parentElement.innerHTML='<div style=\\'width:100%;height:100%;background:rgba(255,255,255,0.1);border-radius:50%\\'></div>'">`
          : '<div style="width:100%;height:100%;background:rgba(255,255,255,0.1);border-radius:50%"></div>'}
      </div>
      <div class="timed-comment-body">${Utils.esc(comment.body)}</div>
      <div class="timed-comment-ts">${Utils.dur(comment.timestamp)}</div>
    `;

    el.addEventListener('click', () => {
      const currentTrack = Store.get('currentTrack');
      if (!currentTrack) return;
      el.classList.add('highlighted');
      setTimeout(() => el.classList.remove('highlighted'), 1500);
      TrackPage.openAndHighlight(currentTrack, comment.id, comment.timestamp);
    });

    overlay.appendChild(el);
    this._activeElements.push(el);

    
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        el.classList.remove('entering');
        el.classList.add('visible');
      });
    });

    setTimeout(() => this._removeComment(el), 5500);
  },

  
  _recenter() {
    const overlay = document.getElementById('comments-overlay');
    if (!overlay) return;

    
    if (document.body.classList.contains('karaoke-active')) {
      const artWrap = document.getElementById('karaoke-art-wrap');
      if (artWrap) {
        const artRect = artWrap.getBoundingClientRect();
        const cx = Math.round(artRect.left + artRect.width / 2);

        overlay.style.left      = cx + 'px';
        overlay.style.transform = 'translateX(-50%)';
        overlay.style.bottom    = '100px';   
        overlay.style.top       = '';
        overlay.style.maxHeight = '';        
        overlay.style.overflow  = 'visible';

        
        this._updateMaxVisible();
        return;
      }
    }

    
    overlay.style.top       = '';
    overlay.style.maxHeight = '';
    overlay.style.overflow  = '';
    overlay.style.bottom    = '100px';
    const npbControls = document.querySelector('.npb-controls');
    if (npbControls) {
      const r = npbControls.getBoundingClientRect();
      const cx = Math.round(r.left + r.width / 2);
      overlay.style.left      = cx + 'px';
      overlay.style.transform = 'translateX(-50%)';
    } else {
      overlay.style.left      = '50vw';
      overlay.style.transform = 'translateX(-50%)';
    }
    
    this._updateMaxVisible();
  },

  _removeComment(el) {
    if (!el.parentNode) return;
    el.classList.remove('visible');
    el.classList.add('exiting');
    setTimeout(() => {
      el.remove();
      this._activeElements = this._activeElements.filter(e => e !== el);
    }, 700);
  },

  _removeOldest() {
    const oldest = this._activeElements.shift();
    if (oldest) { oldest.classList.remove('visible'); oldest.classList.add('exiting'); setTimeout(() => oldest.remove(), 700); }
  },

  _clearAll() {
    const overlay = document.getElementById('comments-overlay');
    if (overlay) overlay.innerHTML = '';
    this._activeElements = [];
  },

  toggle() {
    this._enabled = !this._enabled;
    if (!this._enabled) this._clearAll();
  },
};
