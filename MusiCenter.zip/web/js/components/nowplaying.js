

const NowPlayingComponent = {
  _progressDragging: false,
  _likedTracks: new Set(),

  init() {
    const progressContainer = document.getElementById('progress-bar-container');
    progressContainer.addEventListener('mousedown', (e) => {
      this._progressDragging = true;
      this._seekToPosition(e, progressContainer);
    });
    document.addEventListener('mousemove', (e) => {
      if (this._progressDragging) this._seekToPosition(e, progressContainer);
    });
    document.addEventListener('mouseup', () => { this._progressDragging = false; });

    document.getElementById('btn-play').addEventListener('click', () => Store.togglePlay());
    document.getElementById('btn-prev').addEventListener('click', () => Player.handlePrev());
    document.getElementById('btn-next').addEventListener('click', () => Store.next());
    document.getElementById('btn-shuffle').addEventListener('click', () => Store.toggleShuffle());
    document.getElementById('btn-repeat').addEventListener('click', () => Store.toggleRepeat());

    const volSlider = document.getElementById('volume-slider');
    volSlider.value = Store.get('volume');
    volSlider.addEventListener('input', (e) => Store.setVolume(parseInt(e.target.value)));
    document.getElementById('btn-volume').addEventListener('click', () => {
      Store.setVolume(Store.get('volume') > 0 ? 0 : 50);
    });
    
    const volWrap = document.getElementById('volume-slider-wrap');
    const volBtn = document.getElementById('btn-volume');
    const volLabel = document.getElementById('volume-label');
    
    if (volWrap) volWrap.addEventListener('wheel', (e) => {
      e.preventDefault();
      Store.setVolume(Store.get('volume') + (e.deltaY < 0 ? 3 : -3));
    }, { passive: false });
    
    if (volBtn) volBtn.addEventListener('wheel', (e) => {
      e.preventDefault();
      Store.setVolume(Store.get('volume') + (e.deltaY < 0 ? 3 : -3));
    }, { passive: false });
    
    if (volLabel) volLabel.addEventListener('wheel', (e) => {
      e.preventDefault();
      Store.setVolume(Store.get('volume') + (e.deltaY < 0 ? 3 : -3));
    }, { passive: false });

    document.getElementById('npb-like-btn').addEventListener('click', () => this._toggleLike());
    document.getElementById('npb-artist').addEventListener('click', () => {
      const track = Store.get('currentTrack');
      if (track?.user) ArtistPage.open(track.user);
    });
    document.getElementById('npb-artwork-wrap').addEventListener('click', () => {
      const track = Store.get('currentTrack');
      if (track) FullscreenArt.open(track);
    });
    document.getElementById('npb-title').addEventListener('click', () => {
      const track = Store.get('currentTrack');
      if (track) TrackPage.open(track);
    });
    
    document.getElementById('npb-title').addEventListener('contextmenu', (e) => {
      const track = Store.get('currentTrack');
      if (track) { e.preventDefault(); ContextMenu.showUpward(e, track, true); }
    });
    document.getElementById('npb-artist').addEventListener('contextmenu', (e) => {
      const track = Store.get('currentTrack');
      if (track) { e.preventDefault(); ContextMenu.showUpward(e, track, true); }
    });
    document.getElementById('npb-artwork-wrap').addEventListener('contextmenu', (e) => {
      const track = Store.get('currentTrack');
      if (track) { e.preventDefault(); ContextMenu.showUpward(e, track, true); }
    });

    Store.on('currentTrack', () => this._updateTrackInfo());
    Store.on('isPlaying',    () => this._updatePlayButton());
    
    document.addEventListener('mc:loading', () => this._updatePlayButton());
    Store.on('volume',   (v)  => this._updateVolume(v));
    Store.on('shuffle',  (v)  => this._updateShuffle(v));
    Store.on('repeat',   (v)  => this._updateRepeat(v));
    Player.subscribe(() => this._updateProgress());

    this._updateTrackInfo();
    this._updatePlayButton();
    this._updateVolume(Store.get('volume'));
    this._updateShuffle(Store.get('shuffle'));
    this._updateRepeat(Store.get('repeat'));
    this._syncLikedSet();

    
    Store.on('currentTrack', () => {
      setTimeout(() => Utils._refreshPlayingCards(), 50);
    });
    Store.on('isPlaying', () => {
      setTimeout(() => Utils._refreshPlayingCards(), 50);
    });
  },

  async _syncLikedSet() {
    try {
      const data = await API.getLikedTracks(200);
      (data.collection || []).forEach(t => this._likedTracks.add(t.urn));
    } catch {}
  },

  _seekToPosition(e, container) {
    const rect = container.getBoundingClientRect();
    const pct = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    const dur = Player.getDuration();
    if (dur > 0) Player.seek(pct * dur);
  },

  _updateTrackInfo() {
    const track = Store.get('currentTrack');
    const artwork = document.getElementById('npb-artwork');
    const title   = document.getElementById('npb-title');
    const artist  = document.getElementById('npb-artist');
    const glow    = document.getElementById('ambient-glow');
    const likeBtn = document.getElementById('npb-like-btn');

    if (track) {
      const artUrl = Utils.art(track.artwork_url, 't200x200');
      if (artUrl) { artwork.src = artUrl; artwork.classList.add('visible'); glow.style.backgroundImage = `url(${artUrl})`; }
      else { artwork.classList.remove('visible'); glow.style.backgroundImage = ''; }
      title.textContent  = track.title;
      artist.textContent = track.user?.username || '';
      const liked = this._likedTracks.has(track.urn);
      likeBtn.classList.toggle('active', liked);
      likeBtn.classList.remove('pending-like');
      likeBtn.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="${liked ? 'var(--accent)' : 'none'}" stroke="${liked ? 'var(--accent)' : 'currentColor'}" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>`;
      likeBtn.title = liked ? 'Убрать из любимых' : 'В любимые';
    } else {
      artwork.classList.remove('visible');
      title.textContent  = 'Не воспроизводится';
      artist.textContent = '';
      glow.style.backgroundImage = '';
      likeBtn.classList.remove('active');
    }
    
    if (window.pywebview?.api?.update_tray_track) {
      const trackTitle = track ? `♪ ${track.title} — ${track.user?.username || ''}` : 'MusiCenter';
      window.pywebview.api.update_tray_track(trackTitle).catch(() => {});
    }
  },

  _updatePlayButton() {
    const isPlaying = Store.get('isPlaying');
    const isLoading = Player._loading && isPlaying;
    const iconPlay  = document.getElementById('icon-play');
    const iconPause = document.getElementById('icon-pause');
    const iconLoad  = document.getElementById('icon-loading');
    if (!iconPlay || !iconPause) return;

    if (isLoading) {
      
      iconPlay.style.display  = 'none';
      iconPause.style.display = 'none';
      if (iconLoad) iconLoad.style.display = 'block';
    } else if (isPlaying) {
      
      iconPlay.style.display  = 'none';
      if (iconLoad) iconLoad.style.display = 'none';
      iconPause.style.display = 'block';
    } else {
      
      if (iconLoad) iconLoad.style.display = 'none';
      iconPause.style.display = 'none';
      iconPlay.style.display  = 'block';
    }
  },

  _updateProgress() {
    if (this._progressDragging) return;
    
    if (this._hidden) return;
    const current  = Player.getCurrentTime();
    const duration = Player.getDuration();
    const pct = duration > 0 ? (current / duration) * 100 : 0;
    document.getElementById('progress-fill').style.width  = `${pct}%`;
    document.getElementById('progress-thumb').style.left  = `${pct}%`;
    document.getElementById('time-current').textContent   = Utils.formatTime(current);
    document.getElementById('time-duration').textContent  = Utils.formatTime(duration);
  },

  _updateVolume(vol) {
    const slider = document.getElementById('volume-slider');
    const label  = document.getElementById('volume-label');
    if (slider) slider.value = vol;
    if (label)  label.textContent = `${vol}%`;
    if (slider) {
      const pct = Math.min(vol, 100);
      slider.style.background = `linear-gradient(to right, rgba(255,255,255,0.6) ${pct}%, rgba(255,255,255,0.08) ${pct}%)`;
    }
    const btn = document.getElementById('btn-volume');
    if (!btn) return;
    if (vol === 0) {
      btn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><line x1="23" y1="9" x2="17" y2="15"/><line x1="17" y1="9" x2="23" y2="15"/></svg>';
      btn.classList.add('active');
    } else {
      btn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"/></svg>';
      btn.classList.remove('active');
    }
  },

  _updateShuffle(active) { document.getElementById('btn-shuffle').classList.toggle('active', active); },

  _updateRepeat(mode) {
    const btn = document.getElementById('btn-repeat');
    btn.classList.toggle('active', mode !== 'off');
    if (mode === 'one') {
      btn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/><text x="12" y="14" font-size="8" fill="currentColor" text-anchor="middle" font-weight="bold">1</text></svg>';
    } else {
      btn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></svg>';
    }
  },

  async _toggleLike() {
    const track = Store.get('currentTrack');
    if (!track) return;
    const btn = document.getElementById('npb-like-btn');
    const isLiked = this._likedTracks.has(track.urn);

    
    if (typeof LocalLikes !== 'undefined' && LocalLikes.hasTrack(track.urn)) {
      btn.classList.add('like-pulse');
      setTimeout(() => btn.classList.remove('like-pulse'), 900);
      const ok = await LocalLikes.tryLikeAndRemove(track.urn);
      if (ok) {
        this._likedTracks.add(track.urn);
        btn.classList.add('active');
        btn.querySelector('svg').style.fill = 'var(--accent)';
      }
      
      return;
    }

    
    if (isLiked) {
      this._likedTracks.delete(track.urn);
      btn.classList.remove('active');
      btn.querySelector('svg').style.fill = 'none';
      this._removeFromLikedSection(track.urn);
    } else {
      this._likedTracks.add(track.urn);
      btn.classList.add('active');
      btn.querySelector('svg').style.fill = 'var(--accent)';
      this._animateLike(track);
    }

    
    try {
      await LikeQueue.enqueue(track.urn, isLiked ? 'unlike' : 'like');
      Utils.log('info', `[Like] ${isLiked ? 'Unlike' : 'Like'} queued OK: ${track.title}`);
    } catch (err) {
      
      Utils.log('error', `[Like] Hard error ${isLiked ? 'unlike' : 'like'}: ${err.message}`);
      if (isLiked) {
        this._likedTracks.add(track.urn);
        btn.classList.add('active');
        btn.querySelector('svg').style.fill = 'var(--accent)';
      } else {
        this._likedTracks.delete(track.urn);
        btn.classList.remove('active');
        btn.querySelector('svg').style.fill = 'none';
      }
      
      if (!isLiked && typeof LocalLikes !== 'undefined') {
        if (LocalLikes.hasTrack(track.urn)) {
          Utils.toast('Лайк всё ещё недоступен! Ограничение SoundCloud.', 4000, 'local-like-fail');
        } else {
          LocalLikes.addTrack(track);
          Utils.toast('Лайк не удалось! Но мы добавили его в «Локально Нравится»!', 5000);
        }
      } else {
        Utils.toast('Не удалось изменить лайк', 2500, 'like-fail');
      }
    }
  },

  
  _animateLike(track) {
    const btn = document.getElementById('npb-like-btn');
    if (btn) {
      btn.classList.add('like-pulse');
      setTimeout(() => btn.classList.remove('like-pulse'), 900);
    }
    setTimeout(() => {
      if (Store.get('currentPage') !== 'home') return;
      const hScroll = document.getElementById('home-liked')?.querySelector('.h-scroll');
      if (!hScroll) return;
      if (hScroll.querySelector(`[data-urn="${CSS.escape(track.urn)}"]`)) return;

      if (HomePage._cache.likedTracks) HomePage._cache.likedTracks.unshift(track);
      else HomePage._cache.likedTracks = [track];

      const queue = HomePage._cache.likedTracks;
      TrackRegistry.reg(track);

      const newItem = document.createElement('div');
      newItem.className = 'h-scroll-item';
      newItem.style.cssText = 'opacity:0;transform:scale(0.8) translateY(14px);transition:opacity 0.5s cubic-bezier(0.16,1,0.3,1),transform 0.5s cubic-bezier(0.16,1,0.3,1);flex-shrink:0;';
      newItem.innerHTML = TrackCardComponent.card(track, queue);
      hScroll.insertBefore(newItem, hScroll.firstChild);
      requestAnimationFrame(() => requestAnimationFrame(() => {
        newItem.style.opacity   = '1';
        newItem.style.transform = 'scale(1) translateY(0)';
      }));
    }, 250);
  },

  _removeFromLikedSection(urn) {
    
    if (HomePage._cache?.likedTracks) {
      HomePage._cache.likedTracks = HomePage._cache.likedTracks.filter(t => t.urn !== urn);
    }

    
    const escaped = CSS.escape(urn);
    document.querySelectorAll(`[data-urn="${escaped}"]`).forEach(card => {
      const container =
        card.closest('.h-scroll-item') ||
        card.closest('.overlay-item') ||
        card.closest('.track-row') ||
        card.closest('.feed-card') ||
        card;
      container.style.transition = 'opacity 0.35s ease, transform 0.35s ease';
      container.style.opacity    = '0';
      container.style.transform  = 'scale(0.82)';
      setTimeout(() => {
        const h = container.offsetHeight;
        container.style.transition += ', max-height 0.3s ease, margin 0.3s ease, padding 0.3s ease';
        container.style.maxHeight   = h + 'px';
        container.style.overflow    = 'hidden';
        requestAnimationFrame(() => {
          container.style.maxHeight    = '0';
          container.style.marginBottom = '0';
          container.style.paddingBottom = '0';
        });
        setTimeout(() => container.remove(), 320);
      }, 340);
    });
  },
};
