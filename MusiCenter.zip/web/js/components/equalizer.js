

const EQ_FREQUENCIES = [32, 64, 125, 250, 500, 1000, 2000, 4000, 8000, 16000];
const EQ_LABELS      = ['32', '64', '125', '250', '500', '1K', '2K', '4K', '8K', '16K'];
const EQ_MIN = -12;
const EQ_MAX =  12;

const EQ_PRESETS = {
  flat:          { name: 'Ровный',      gains: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0] },
  bassBoost:     { name: 'Бас+',        gains: [6, 5, 4, 2, 0, 0, 0, 0, 0, 0] },
  bassDestroyer: { name: 'Сабвуфер',    gains: [12, 12, 10, 7, 3, 0, -2, -4, -4, -5] },
  trebleBoost:   { name: 'Верха+',      gains: [0, 0, 0, 0, 0, 0, 2, 4, 5, 6] },
  vocal:         { name: 'Вокал',       gains: [-2, -1, 0, 2, 4, 4, 3, 1, 0, -1] },
  rock:          { name: 'Рок',         gains: [4, 3, 1, 0, -1, 0, 2, 3, 4, 4] },
  electronic:    { name: 'Электроника', gains: [5, 4, 2, 0, -1, 0, 1, 3, 4, 5] },
  classical:     { name: 'Классика',    gains: [0, 0, 0, 0, 0, 0, -2, -3, -3, -4] },
  loudness:      { name: 'Громкость',   gains: [5, 4, 1, 0, -1, 0, -1, 0, 3, 4] },
  vShape:        { name: 'V-образный',  gains: [5, 3, 1, -1, -3, -3, -1, 1, 3, 5] },
  nightMode:     { name: 'Ночной',      gains: [-3, -2, 0, 2, 3, 3, 2, 0, -2, -4] },
};

const EqualizerEngine = {
  _enabled: false,
  _gains:   [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  _preset:  'flat',

  
  _ctx:        null,   
  _sourceNode: null,   
  _masterGain: null,   
  _filters:    [],     
  _chainReady: false,  

  
  attachChain(sourceNode, masterGain, ctx) {
    this._ctx        = ctx;
    this._sourceNode = sourceNode;
    this._masterGain = masterGain;
    this._chainReady = true;

    
    if (!this._filters.length) {
      this._filters = EQ_FREQUENCIES.map((freq, i) => {
        const f = ctx.createBiquadFilter();
        f.type = (i === 0) ? 'lowshelf' : (i === EQ_FREQUENCIES.length - 1) ? 'highshelf' : 'peaking';
        f.frequency.value = freq;
        f.Q.value = 1.414;
        f.gain.value = this._gains[i] || 0;
        return f;
      });
    }

    this._reconnectChain();
    Utils.log('info', `[EQ] Цепочка подключена (enabled=${this._enabled})`);
  },

  
  attachAudio(audioEl) {
    
    
  },

  
  _apply() {
    
    if (this._chainReady) {
      this._applyFilters();
      this._reconnectChain();
    }
    
    const saved = Store.get('settings') || {};
    saved.eqEnabled = this._enabled;
    saved.eqGains   = [...this._gains];
    saved.eqPreset  = this._preset;
    Store.set({ settings: saved });
  },

  _applyFilters() {
    this._filters.forEach((f, i) => {
      f.gain.value = this._enabled ? (this._gains[i] || 0) : 0;
    });
  },

  _reconnectChain() {
    if (!this._chainReady || !this._sourceNode || !this._masterGain) return;

    
    try { this._sourceNode.disconnect(); } catch (_) {}
    this._filters.forEach(f => { try { f.disconnect(); } catch (_) {} });

    if (this._enabled && this._filters.length) {
      
      this._sourceNode.connect(this._filters[0]);
      for (let i = 0; i < this._filters.length - 1; i++) {
        this._filters[i].connect(this._filters[i + 1]);
      }
      this._filters[this._filters.length - 1].connect(this._masterGain);
    } else {
      
      this._sourceNode.connect(this._masterGain);
    }
  },

  
  setEnabled(v) {
    this._enabled = v;
    this._apply();
    Utils.log('info', `[EQ] ${v ? 'ВКЛ' : 'ВЫКЛ'} (Web Audio API)`);
  },

  setBand(index, gain) {
    this._gains[index] = gain;
    this._preset = 'custom';
    
    if (this._chainReady && this._enabled && this._filters[index]) {
      this._filters[index].gain.value = gain;
    }
    
    const saved = Store.get('settings') || {};
    saved.eqEnabled = this._enabled;
    saved.eqGains   = [...this._gains];
    saved.eqPreset  = 'custom';
    Store.set({ settings: saved });
  },

  setPreset(id) {
    const p = EQ_PRESETS[id];
    if (!p) return;
    this._preset = id;
    this._gains  = [...p.gains];
    this._apply();
  },

  resetFlat() { this.setPreset('flat'); },

  restore() {
    const saved = Store.get('settings') || {};
    if (Array.isArray(saved.eqGains) && saved.eqGains.length === 10) {
      this._gains = saved.eqGains;
    }
    if (saved.eqPreset)  this._preset  = saved.eqPreset;
    if (saved.eqEnabled) this._enabled = true;
    
  },

  
  pushToAudio() {
    if (this._chainReady) this._apply();
  },

  
  pushToRust() { this.pushToAudio(); },

  ensureRunning() {
    if (this._ctx?.state === 'suspended') this._ctx.resume().catch(() => {});
  },
};


const EqualizerComponent = {
  _open: false,
  _el: null,

  init() {
    EqualizerEngine.restore();
  },

  toggle() {
    EqualizerEngine.ensureRunning();
    if (this._open) this.close();
    else this.open();
  },

  open() {
    if (this._open) return;
    this._open = true;
    let el = document.getElementById('eq-panel');
    if (!el) { el = document.createElement('div'); el.id = 'eq-panel'; document.body.appendChild(el); }
    this._el = el;
    this._render();
    requestAnimationFrame(() => el.classList.add('open'));
    const btn = document.getElementById('btn-eq');
    if (btn) btn.classList.toggle('active', EqualizerEngine._enabled);
  },

  close() {
    if (!this._open) return;
    this._open = false;
    const el = document.getElementById('eq-panel');
    if (!el) return;
    el.classList.remove('open');
    setTimeout(() => el.remove(), 320);
  },

  _render() {
    const el = this._el;
    if (!el) return;
    const gains   = EqualizerEngine._gains;
    const preset  = EqualizerEngine._preset;
    const enabled = EqualizerEngine._enabled;

    el.innerHTML = `
      <div class="eq-backdrop" id="eq-backdrop"></div>
      <div class="eq-card">
        <div class="eq-header">
          <div class="eq-header-left">
            <div class="eq-icon">
              <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M2 20h3M5 20V10M8 20V4M11 20V14M14 20V8M17 20V2M20 20v6"/></svg>
            </div>
            <div>
              <span class="eq-title">Эквалайзер</span>
              <span class="eq-backend">Web Audio API · BiquadFilter</span>
            </div>
          </div>
          <div class="eq-header-right">
            <button id="eq-power-btn" class="eq-icon-btn ${enabled ? 'eq-power-on' : ''}" title="${enabled ? 'Выкл EQ' : 'Вкл EQ'}">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M18.36 6.64A9 9 0 1 1 5.64 6.64"/><line x1="12" y1="2" x2="12" y2="12"/></svg>
            </button>
            <button id="eq-reset-btn" class="eq-icon-btn" title="Сброс">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/></svg>
            </button>
            <button id="eq-close-btn" class="eq-icon-btn" title="Закрыть">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>
            </button>
          </div>
        </div>

        <div class="eq-sliders-wrap ${enabled ? '' : 'eq-disabled'}">
          <div class="eq-db-labels">
            <span>+12</span><span>0</span><span>-12</span>
          </div>
          <div class="eq-bands" id="eq-bands">
            ${gains.map((g, i) => this._bandHTML(i, g)).join('')}
          </div>
        </div>

        <div class="eq-presets ${enabled ? '' : 'eq-disabled'}">
          <div class="eq-presets-label">Пресеты</div>
          <div class="eq-presets-grid">
            ${Object.entries(EQ_PRESETS).map(([id, p]) =>
              `<button class="eq-preset-btn ${preset === id ? 'active' : ''}" data-preset="${id}">${p.name}</button>`
            ).join('')}
            ${preset === 'custom' ? '<button class="eq-preset-btn active" data-preset="custom">Custom</button>' : ''}
          </div>
        </div>
      </div>
    `;
    this._bindEvents();
  },

  _bandHTML(i, gain) {
    const pct = (gain - EQ_MIN) / (EQ_MAX - EQ_MIN);
    const pos  = (1 - pct) * 140;
    const isPos = gain > 0, isNeg = gain < 0;
    const fillColor  = isPos ? 'rgba(255,85,0,0.7)'   : isNeg ? 'rgba(100,160,255,0.7)' : 'transparent';
    const thumbColor = isPos ? '#ff5500'               : isNeg ? '#64a0ff'               : 'rgba(255,255,255,0.45)';
    const glow = gain !== 0 ? `box-shadow:0 0 10px ${isPos ? 'rgba(255,85,0,0.45)' : 'rgba(100,160,255,0.45)'}` : '';
    const centerPx = 70;
    const fillTop = isPos ? pos : centerPx;
    const fillH   = Math.abs(pos - centerPx);
    return `
      <div class="eq-band" data-band="${i}">
        <span class="eq-band-val ${isPos ? 'eq-val-pos' : isNeg ? 'eq-val-neg' : ''}">${gain > 0 ? '+' : ''}${gain.toFixed(1)}</span>
        <div class="eq-track" data-band="${i}">
          <div class="eq-rail"></div>
          <div class="eq-center-tick"></div>
          <div class="eq-fill" style="top:${fillTop}px;height:${fillH}px;background:${fillColor}"></div>
          <div class="eq-thumb" style="top:${pos - 8}px;background:${thumbColor};${glow}"></div>
        </div>
        <span class="eq-band-label">${EQ_LABELS[i]}</span>
      </div>`;
  },

  _bindEvents() {
    const el = this._el;
    if (!el) return;
    document.getElementById('eq-backdrop').addEventListener('click', () => this.close());
    document.getElementById('eq-close-btn').addEventListener('click', () => this.close());
    document.getElementById('eq-power-btn').addEventListener('click', () => {
      EqualizerEngine.setEnabled(!EqualizerEngine._enabled);
      this._render();
      requestAnimationFrame(() => el.classList.add('open'));
      document.getElementById('btn-eq')?.classList.toggle('active', EqualizerEngine._enabled);
    });
    document.getElementById('eq-reset-btn').addEventListener('click', () => {
      EqualizerEngine.resetFlat();
      this._render();
      requestAnimationFrame(() => el.classList.add('open'));
    });
    el.querySelectorAll('.eq-preset-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const id = btn.dataset.preset;
        if (id && id !== 'custom') {
          EqualizerEngine.setPreset(id);
          this._render();
          requestAnimationFrame(() => el.classList.add('open'));
        }
      });
    });
    el.querySelectorAll('.eq-track').forEach(track => {
      track.addEventListener('pointerdown', (e) => {
        if (!EqualizerEngine._enabled) return;
        e.preventDefault();
        track.setPointerCapture(e.pointerId);
        this._startDrag(parseInt(track.dataset.band), track, e.clientY);
      });
    });
  },

  _startDrag(bandIdx, trackEl, startY) {
    const rect = trackEl.getBoundingClientRect();
    const calcGain = (y) => {
      const pct = 1 - Math.max(0, Math.min(1, (y - rect.top) / rect.height));
      return Math.round((pct * (EQ_MAX - EQ_MIN) + EQ_MIN) * 2) / 2;
    };
    const onMove = (e) => {
      const g = calcGain(e.clientY);
      EqualizerEngine.setBand(bandIdx, g);
      this._updateBand(bandIdx, g);
    };
    const onUp = () => {
      trackEl.removeEventListener('pointermove', onMove);
      trackEl.removeEventListener('pointerup', onUp);
    };
    trackEl.addEventListener('pointermove', onMove);
    trackEl.addEventListener('pointerup',   onUp);
    onMove({ clientY: startY });
  },

  _updateBand(i, gain) {
    const bandEl = this._el?.querySelector(`.eq-band[data-band="${i}"]`);
    if (!bandEl) return;
    const pct = (gain - EQ_MIN) / (EQ_MAX - EQ_MIN);
    const pos  = (1 - pct) * 140;
    const isPos = gain > 0, isNeg = gain < 0;
    const fillColor  = isPos ? 'rgba(255,85,0,0.7)' : isNeg ? 'rgba(100,160,255,0.7)' : 'transparent';
    const thumbColor = isPos ? '#ff5500' : isNeg ? '#64a0ff' : 'rgba(255,255,255,0.45)';
    const glow = gain !== 0 ? `0 0 10px ${isPos ? 'rgba(255,85,0,0.45)' : 'rgba(100,160,255,0.45)'}` : 'none';
    const fillTop = isPos ? pos : 70;
    const fillH   = Math.abs(pos - 70);

    const valEl = bandEl.querySelector('.eq-band-val');
    if (valEl) { valEl.textContent = (gain > 0 ? '+' : '') + gain.toFixed(1); valEl.className = 'eq-band-val' + (isPos ? ' eq-val-pos' : isNeg ? ' eq-val-neg' : ''); }
    const fillEl = bandEl.querySelector('.eq-fill');
    if (fillEl) { fillEl.style.top = fillTop + 'px'; fillEl.style.height = fillH + 'px'; fillEl.style.background = fillColor; }
    const thumbEl = bandEl.querySelector('.eq-thumb');
    if (thumbEl) { thumbEl.style.top = (pos - 8) + 'px'; thumbEl.style.background = thumbColor; thumbEl.style.boxShadow = glow; }

    
    this._el.querySelectorAll('.eq-preset-btn').forEach(b => b.classList.toggle('active', b.dataset.preset === 'custom'));
    if (!this._el.querySelector('[data-preset="custom"]')) {
      const grid = this._el.querySelector('.eq-presets-grid');
      if (grid) { const b = document.createElement('button'); b.className = 'eq-preset-btn active'; b.dataset.preset = 'custom'; b.textContent = 'Custom'; grid.appendChild(b); }
    }
  },
};
