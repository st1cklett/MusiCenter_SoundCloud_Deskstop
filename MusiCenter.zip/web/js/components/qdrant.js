

const QdrantEngine = {
  _QDRANT_URL: 'https://230ea21a-0600-4b2d-8482-fd57f2b315f2.europe-west3-0.gcp.cloud.qdrant.io:6333',
  _QDRANT_KEY: 'YOUR_QDRANT_API_KEY_HERE',
  _COLLECTION: 'sw_v5',
  _DIMS: 72,
  _useProxy: false,

  _ready: false, _poolSize: 0, _profileReady: false,
  _sessionPositive: [], _sessionNegative: [],
  _likedIds: [],  
  _ymLikedCount: 0, 
  _indexedUrns: new Set(), _enrichedSeeds: new Set(),
  _initPromise: null,
  _totalRequests: 0, _totalErrors: 0, _totalIndexed: 0, _lastRecommendMs: 0,

  _log(level, msg) { if(typeof Utils!=='undefined'&&Utils.log)Utils.log(level,msg);else console[level==='error'?'error':'log'](msg); },

  
  _hash(str, numDims) {
    let h1=0x811c9dc5;
    for(let i=0;i<str.length;i++){h1^=str.charCodeAt(i);h1=Math.imul(h1,0x01000193);}
    const dim=(h1>>>0)%numDims;
    let h2=0;
    for(let i=str.length-1;i>=0;i--){h2=Math.imul(h2^str.charCodeAt(i),0x5bd1e995);}
    return{dim, sign:(h2&1)?1.0:-1.0};
  },

  _normalize(vec) {
    let n=0;for(let i=0;i<vec.length;i++)n+=vec[i]*vec[i];n=Math.sqrt(n);
    if(n>1e-9)for(let i=0;i<vec.length;i++)vec[i]/=n;
    return vec;
  },

  _detectLang(track) {
    const text=[track.title||'',track.user?.username||'',track.tag_list||'',(track.description||'').substring(0,200)].join(' ');
    const cyr=(text.match(/[\u0400-\u04FF]/g)||[]).length,lat=(text.match(/[a-zA-Z]/g)||[]).length;
    const foreign=(text.match(/[\u0600-\u06FF\u0750-\u077F\uFB50-\uFDFF\uFE70-\uFEFF\u4E00-\u9FFF\u3040-\u309F\u30A0-\u30FF\uAC00-\uD7AF\u0900-\u097F\u0980-\u09FF]/g)||[]).length;
    if(foreign>3)return'foreign';if(cyr===0&&lat===0)return'other';if(cyr>lat*1.5)return'ru';if(lat>cyr*1.5)return'en';return'mixed';
  },

  
  _MOODS: {
    aggressive:'aggressive hard heavy brutal savage rage fury intense raw dirty filthy grimy жёсткий тяжёлый злой агрессивный мощный грязный бойня кровь убийство смерть война пушка',
    dreamy:'dreamy floating ethereal airy soft cloud gentle tender heavenly warm beautiful delicate light нежный облако лёгкий тёплый красиво нежность сон мечта ангел рай тихо',
    dark:'dark moody gloomy nocturnal night shadow midnight deep underground mysterious haunting тёмный ночь тень мрачный глубокий подземный грусть боль одинокий пустота бездна',
    bright:'bright uplifting euphoric sunshine sunrise morning dawn golden positive inspiring hope cosmic свет утро солнце надежда яркий радость счастье лето рассвет звезда',
    nostalgic:'nostalgic retro vintage 80s 90s throwback old school classic memory memories lofi tape ностальгия ретро воспоминание память детство старый школа классик плёнка',
  },
  _moodSets: null,

  _buildMoodSets() {
    if(this._moodSets)return;
    this._moodSets={};
    for(const[k,v]of Object.entries(this._MOODS))this._moodSets[k]=new Set(v.split(/\s+/));
  },

  _extractMoods(track) {
    this._buildMoodSets();
    const text=((track.title||'')+' '+(track.tag_list||'')+' '+(track.genre||'')+' '+((track.description||'').substring(0,300))).toLowerCase();
    const words=text.split(/[\s\-_,.!?()[\]{}:;'"\/\\+=#@&*|~`<>]+/).filter(w=>w.length>2);
    const f=new Float32Array(5);
    const keys=Object.keys(this._MOODS);
    for(let ki=0;ki<keys.length;ki++){
      let hits=0;
      for(const word of words)if(this._moodSets[keys[ki]].has(word))hits++;
      f[ki]=Math.min(1,hits/2);
    }
    return f;
  },

  // ═══ VECTORIZE v3: TEXT HASHING + METADATA ═══
  // GUARANTEED to produce different vectors for different tracks
  // (artist name alone gives unique fingerprint)
  vectorize(track) {
    if(!track) return new Float32Array(this._DIMS);
    const v = new Float32Array(this._DIMS);

    // [0..31] TEXT FINGERPRINT — hash ALL available text into 32 dims
    const textParts = [];
    // Artist (strongest signal — same artist = similar music)
    const artist = (track.user?.username||'').toLowerCase().trim();
    if(artist) textParts.push(artist, artist, artist); // triple weight
    // Title words
    const title = (track.title||'').toLowerCase();
    title.split(/[\s\-_,.!?()[\]{}:;'"\/\\+=#@&*|~`<>]+/).filter(w=>w.length>2).forEach(w=>textParts.push(w));
    // Genre + tags (if available)
    const genre = (track.genre||'').toLowerCase().trim();
    if(genre&&genre.length>1) textParts.push(genre, genre); // double weight
    (track.tag_list||'').split(/[\s,]+/).forEach(t=>{t=t.toLowerCase().trim();if(t.length>2)textParts.push(t);});
    // Description keywords (first 200 chars)
    (track.description||'').substring(0,200).toLowerCase().split(/[\s\-_,.!?()[\]{}:;'"\/\\+=#@&*|~`<>]+/).filter(w=>w.length>3).slice(0,10).forEach(w=>textParts.push(w));

    for(const part of textParts){
      const{dim,sign}=this._hash(part,32);
      v[dim]+=sign;
    }

    // [32..39] ARTIST-ONLY FINGERPRINT — ensures same-artist tracks cluster
    if(artist){
      for(let ci=0;ci<artist.length&&ci<8;ci++){
        const{dim,sign}=this._hash(artist+'_art_'+ci,8);
        v[32+dim]+=sign*(1+ci*0.1); // slight position weighting
      }
      // Also hash full artist name
      const{dim:ad,sign:as}=this._hash(artist,8);
      v[32+ad]+=as*2; // strong signal
    }

    // [40..41] BPM sin/cos — ★ AudioAnalyser fallback when SoundCloud has no BPM
    let _bpm = (track.bpm && track.bpm > 30 && track.bpm < 300) ? track.bpm : 0;
    if (!_bpm && typeof AudioAnalyser !== 'undefined' && track.urn) {
      const detected = AudioAnalyser.getDetectedBPM(track.urn);
      if (detected > 30 && detected < 300) _bpm = detected;
    }
    if(_bpm > 0){
      const n=(_bpm-30)/270;
      v[40]=Math.sin(n*Math.PI*2); v[41]=Math.cos(n*Math.PI*2);
    }

    // [42] Duration log-norm
    if(track.duration>0) v[42]=Math.min(1,Math.log(track.duration/1000+1)/Math.log(601));

    // [43..46] Popularity
    const plays=track.playback_count||0,likes=track.favoritings_count??track.likes_count??0;
    v[43]=Math.min(1,Math.log1p(plays)/14);
    v[44]=Math.min(1,Math.log1p(likes)/12);
    v[45]=plays>0?Math.min(1,(likes/plays)*5):0;
    v[46]=Math.min(1,Math.log1p(track.user?.followers_count||0)/14);

    // [47..51] Language one-hot
    const lang=this._detectLang(track);
    if(lang==='ru')v[47]=1;else if(lang==='en')v[48]=1;else if(lang==='mixed'){v[47]=0.5;v[48]=0.5;}else if(lang==='foreign')v[51]=1;else v[49]=1;

    // [52..56] Mood from title/tags/desc
    const moods=this._extractMoods(track);
    for(let i=0;i<5;i++)v[52+i]=moods[i];

    // [57] Freshness
    if(track.created_at){const days=(Date.now()-new Date(track.created_at).getTime())/86400000;v[57]=1/(1+days/365);}

    // [58] Velocity
    if(track.created_at&&plays>0){const days=Math.max(1,(Date.now()-new Date(track.created_at).getTime())/86400000);v[58]=Math.min(1,Math.log1p(plays/days)/10);}

    // [59..63] Extra metadata
    v[59]=track.duration>0?(track.duration<120000?0.2:track.duration<240000?0.5:track.duration<420000?0.8:1.0):0.5; // duration category
    v[60]=plays<1000?0.1:plays<10000?0.3:plays<100000?0.6:plays<1000000?0.8:1.0; // play tier
    v[61]=Math.min(1,(track.description||'').length/500); // description richness
    v[62]=track.artwork_url?0.8:0.2; // has artwork
    v[63]=(_bpm>0)?0.8:0.2; // has BPM info (SoundCloud or AudioAnalyser detected)

    // [64..71] ★ AudioAnalyser spectral features (real FFT data)
    if (typeof AudioAnalyser !== 'undefined' && track.urn) {
      const enrichment = AudioAnalyser.getVectorEnrichment(track.urn);
      if (enrichment) {
        for (let i = 0; i < 8; i++) v[64 + i] = enrichment[i];
        // Log enrichment for first few tracks
        if (this._totalIndexed < 20) {
          this._log('info', `[Qdrant:VEC] ★ Audio enrichment for "${(track.title||'?').substring(0,25)}": E=${enrichment[0].toFixed(2)} C=${enrichment[1].toFixed(2)} B=${enrichment[2].toFixed(2)} F=${enrichment[3].toFixed(2)} V=${enrichment[6].toFixed(2)} A=${enrichment[7].toFixed(2)}`);
        }
      }
    }

    return this._normalize(v);
  },

  // ═══ REST CLIENT ═══
  async _req(method,path,body=null){
    const t0=performance.now();this._totalRequests++;
    const url=this._useProxy?`/api/qdrant${path}`:`${this._QDRANT_URL}${path}`;
    const headers={'Content-Type':'application/json'};if(!this._useProxy)headers['api-key']=this._QDRANT_KEY;
    const opts={method,headers};if(body!==null)opts.body=JSON.stringify(body);
    const bs=opts.body?opts.body.length:0;
    this._log('info',`[Qdrant:REQ] ${method} ${path} (${bs>1000?(bs/1024).toFixed(1)+'KB':bs+'B'})${this._useProxy?' [proxy]':''}`);
    try{
      const resp=await fetch(url,opts);const ms=(performance.now()-t0).toFixed(0);
      if(!resp.ok){const txt=await resp.text().catch(()=>'');this._totalErrors++;this._log('error',`[Qdrant:REQ] ${method} ${path} → ${resp.status} (${ms}ms): ${txt.substring(0,200)}`);throw new Error(`Qdrant ${resp.status}`);}
      const json=await resp.json();this._log('info',`[Qdrant:REQ] ${method} ${path} → OK (${ms}ms)`);return json;
    }catch(e){if(!e.message.startsWith('Qdrant ')){this._totalErrors++;this._log('error',`[Qdrant:REQ] ${method} ${path} → ERROR: ${e.message}`);}throw e;}
  },

  _POOL_CAP: 5000,  // Max points in collection — increased from 2000 for better diversity

  // ═══ INIT ═══
  async init(){if(this._initPromise)return this._initPromise;this._initPromise=this._doInit();return this._initPromise;},
  async _doInit(){
    const t0=performance.now();
    this._log('info','[Qdrant:INIT] ═══ v4 (Graph-First + AudioAnalyser, 72-dim) ═══');
    try{await this._req('GET','/collections');this._log('info','[Qdrant:INIT] ✓ Direct connection');}
    catch{try{this._useProxy=true;await this._req('GET','/collections');this._log('info','[Qdrant:INIT] ✓ Proxy connection');}
    catch(e){this._log('error',`[Qdrant:INIT] ✗ No connection: ${e.message}`);this._ready=false;return;}}

    // ★ CLEANUP: Delete old collections from previous versions (free disk)
    await this._cleanupOldCollections();

    try{const info=await this._req('GET',`/collections/${this._COLLECTION}`);this._poolSize=info.result?.points_count||0;
      this._log('info',`[Qdrant:INIT] ✓ Collection: ${this._poolSize} points`);
      // ★ If pool exceeds cap on startup, trim discovered tracks
      if(this._poolSize>this._POOL_CAP){
        this._log('info',`[Qdrant:INIT] Pool over cap (${this._poolSize}>${this._POOL_CAP}) — scheduling trim...`);
        setTimeout(()=>this._trimPool(),3000);
      }
    }
    catch{
      this._log('info','[Qdrant:INIT] Creating collection (v3 schema)...');
      try{
        await this._req('PUT',`/collections/${this._COLLECTION}`,{vectors:{size:this._DIMS,distance:'Cosine'},optimizers_config:{default_segment_number:2,indexing_threshold:20000},quantization_config:{scalar:{type:'int8',quantile:0.99,always_ram:true}}});
        for(const[f,s]of[['plays','integer'],['duration','integer'],['lang','keyword'],['artist_key','keyword'],['is_liked','bool']]){
          await this._req('PUT',`/collections/${this._COLLECTION}/index`,{field_name:f,field_schema:s}).catch(()=>{});}
        this._log('info','[Qdrant:INIT] ✓ Collection + indexes created');
      }catch(e){this._log('error',`[Qdrant:INIT] ✗ Creation failed: ${e.message}`);this._ready=false;return;}
    }
    this._buildMoodSets();
    this._ready=true;
    this._log('info',`[Qdrant:INIT] ═══ Engine v4 READY ✓ (${(performance.now()-t0).toFixed(0)}ms) — pool: ${this._poolSize} ═══`);
  },

  // ★ Delete old collections from previous engine versions
  async _cleanupOldCollections(){
    const oldNames=['sw_tracks','sw_tracks_v2','sw_tracks_v3','sw_v4'];
    for(const name of oldNames){
      try{
        await this._req('GET',`/collections/${name}`);
        // Exists — delete it
        this._log('info',`[Qdrant:CLEANUP] Deleting old collection "${name}"...`);
        await this._req('DELETE',`/collections/${name}`);
        this._log('info',`[Qdrant:CLEANUP] ✓ Deleted "${name}" (freed disk space)`);
      }catch{
        // 404 = doesn't exist = OK
      }
    }
  },

  // ★ Trim pool: delete oldest non-liked (discovered) points to stay under cap
  async _trimPool(){
    if(!this._ready||this._poolSize<=this._POOL_CAP)return;
    const excess=this._poolSize-this._POOL_CAP+200; // delete 200 extra buffer
    this._log('info',`[Qdrant:TRIM] Pool ${this._poolSize} > cap ${this._POOL_CAP} — deleting ~${excess} oldest discovered tracks...`);
    try{
      // Scroll oldest non-liked points (Qdrant returns by ID order = insertion order)
      const resp=await this._req('POST',`/collections/${this._COLLECTION}/points/scroll`,{
        filter:{must:[{key:'is_liked',match:{value:false}}]},
        limit:Math.min(excess,500),
        with_payload:false,with_vector:false,
      });
      const ids=(resp.result?.points||[]).map(p=>p.id);
      if(ids.length>0){
        await this._req('POST',`/collections/${this._COLLECTION}/points/delete`,{points:ids});
        this._poolSize=Math.max(0,this._poolSize-ids.length);
        // Remove from indexedUrns too (they can be re-indexed if needed)
        this._log('info',`[Qdrant:TRIM] ✓ Deleted ${ids.length} discovered points (pool now: ~${this._poolSize})`);
      }else{
        this._log('info','[Qdrant:TRIM] No non-liked points to delete');
      }
    }catch(e){
      this._log('warning',`[Qdrant:TRIM] Failed: ${e.message}`);
    }
  },

  // ★ Cleanup on wave stop: delete non-liked discovered tracks from THIS session
  async cleanup(){
    if(!this._ready)return;
    this._log('info','[Qdrant:CLEANUP] Wave stopped — trimming discovered tracks...');
    await this._trimPool();
    // Refresh pool size
    try{
      const info=await this._req('GET',`/collections/${this._COLLECTION}`);
      this._poolSize=info.result?.points_count||0;
      this._log('info',`[Qdrant:CLEANUP] Pool after cleanup: ${this._poolSize} points`);
    }catch{}
  },

  // ═══ INDEXING ═══
  _urnToId(urn){if(!urn)return 0;const m=String(urn).match(/(\d+)/g);return m?parseInt(m[m.length-1]):0;},
  _trackToPayload(track,isLiked){
    return{urn:track.urn||'',title:track.title||'',artist:track.user?.username||'',
      artist_key:(track.user?.username||track.user?.permalink||'').toLowerCase().trim(),
      genre:track.genre||'',tag_list:track.tag_list||'',plays:track.playback_count||0,
      likes:track.favoritings_count??track.likes_count??0,followers:track.user?.followers_count||0,
      duration:track.duration||0,bpm:track.bpm||0,lang:this._detectLang(track),
      is_liked:!!isLiked,created_at:track.created_at||'',
      artwork_url:track.artwork_url||'',user_avatar:track.user?.avatar_url||'',
      user_permalink:track.user?.permalink||''};
  },
  _payloadToTrack(p){
    if(!p)return null;
    return{urn:p.urn,title:p.title,user:{username:p.artist,permalink:p.user_permalink||'',avatar_url:p.user_avatar||'',followers_count:p.followers||0},
      genre:p.genre,tag_list:p.tag_list,playback_count:p.plays,favoritings_count:p.likes,likes_count:p.likes,
      duration:p.duration,bpm:p.bpm,created_at:p.created_at,artwork_url:p.artwork_url,_qdrant:true};
  },

  async indexTracks(tracks,isLiked=false){
    if(!this._ready)return 0;
    // ★ Pool cap: don't index discovered tracks if pool is over limit
    if(!isLiked&&this._poolSize>=this._POOL_CAP){
      this._log('info',`[Qdrant:INDEX] Skip: pool at cap (${this._poolSize}>=${this._POOL_CAP}), not indexing ${tracks.length} discovered tracks`);
      return 0;
    }
    const points=[];let skDupe=0;
    for(const t of tracks){
      if(!t?.urn||this._indexedUrns.has(t.urn)){skDupe++;continue;}
      const id=this._urnToId(t.urn);if(!id)continue;
      points.push({id,vector:Array.from(this.vectorize(t)),payload:this._trackToPayload(t,isLiked)});
      this._indexedUrns.add(t.urn);
      if(isLiked&&!this._likedIds.includes(id))this._likedIds.push(id);
    }
    if(!points.length)return 0;
    this._log('info',`[Qdrant:INDEX] Upserting ${points.length} ${isLiked?'LIKED':'discovered'} (${skDupe} dupes skipped)`);
    let indexed=0;
    for(let i=0;i<points.length;i+=100){
      const chunk=points.slice(i,i+100);
      try{await this._req('PUT',`/collections/${this._COLLECTION}/points`,{points:chunk});indexed+=chunk.length;}
      catch(e){this._log('error',`[Qdrant:INDEX] Chunk failed: ${e.message}`);}
    }
    this._poolSize+=indexed;this._totalIndexed+=indexed;
    this._log('info',`[Qdrant:INDEX] Done: +${indexed} (pool: ${this._poolSize})`);
    return indexed;
  },

  // ═══ SESSION FEEDBACK ═══
  resetSession(){const p=this._sessionPositive.length,n=this._sessionNegative.length;this._sessionPositive=[];this._sessionNegative=[];this._log('info',`[Qdrant:SESSION] Reset (was ${p}pos/${n}neg)`);},

  async recordFeedback(track,type){
    if(!this._ready||!track?.urn)return;
    if(!this._indexedUrns.has(track.urn))await this.indexTracks([track],false).catch(()=>{});
    const id=this._urnToId(track.urn);if(!id)return;
    if(type==='positive'){
      if(!this._sessionPositive.includes(id)){this._sessionPositive.push(id);if(this._sessionPositive.length>40)this._sessionPositive.shift();}
      this._log('info',`[Qdrant:FEEDBACK] ✓ POS: "${track.title}" — ${this._sessionPositive.length}pos/${this._sessionNegative.length}neg`);
    }else if(type==='negative'){
      if(!this._sessionNegative.includes(id)){this._sessionNegative.push(id);if(this._sessionNegative.length>25)this._sessionNegative.shift();}
      this._log('info',`[Qdrant:FEEDBACK] ✗ NEG: "${track.title}" — ${this._sessionPositive.length}pos/${this._sessionNegative.length}neg`);
    }
  },

  // ═══ RECOMMEND — Graph-First approach ═══
  _buildFilter(opts){
    const must=[{key:'plays',range:{gte:200}},{key:'duration',range:{gte:30000,lte:1800000}}];
    const must_not=[{key:'lang',match:{value:'foreign'}}];
    let exIds=0,exArt=0;
    if(opts.excludeUrns?.length>0){
      const ids=[],seen=new Set();
      for(const u of opts.excludeUrns){const id=this._urnToId(u);if(id>0&&!seen.has(id)){ids.push(id);seen.add(id);}if(ids.length>=2000)break;}
      if(ids.length>0){must_not.push({has_id:ids});exIds=ids.length;}
    }
    if(opts.excludeArtists?.length>0){const a=opts.excludeArtists.slice(0,500);must_not.push({key:'artist_key',match:{any:a}});exArt=a.length;}
    if(opts.mode==='discover')must.push({key:'is_liked',match:{value:false}});
    else if(opts.mode==='popular')must.push({key:'plays',range:{gte:10000}});
    this._log('info',`[Qdrant:FILTER] ${must.length} must + ${must_not.length} must_not | excl: ${exIds} IDs, ${exArt} artists`);
    return{must,must_not};
  },

  async recommend(opts={}){
    if(!this._ready){this._log('info','[Qdrant:REC] Not ready');return[];}
    if(this._poolSize<100){this._log('info',`[Qdrant:REC] Pool too small (${this._poolSize}<100)`);return[];}
    // ★ FIX RACE CONDITION: profileReady must be true
    if(!this._profileReady){this._log('info','[Qdrant:REC] Profile not ready yet — skip');return[];}

    const t0=performance.now();
    const{preset,pinTrack,mode,limit=80,excludeUrns=[],excludeArtists=[]}=opts;
    this._log('info',`[Qdrant:REC] ═══ Pool:${this._poolSize} | ${this._sessionPositive.length}pos/${this._sessionNegative.length}neg | liked:${this._likedIds.length} (${this._likedIds.length - this._ymLikedCount}SC+${this._ymLikedCount}YM) | mode=${mode||'default'} ═══`);
    const filter=this._buildFilter({excludeUrns,excludeArtists,mode});

    // ═══ STRATEGY: ALWAYS use Recommend API ═══
    // Even with 0 session feedback — use liked track IDs as positives!
    let positive = [];
    let negative = this._sessionNegative.slice(-15);
    // ★ When pinTrack is set, it should DOMINATE. Reduce liked IDs to 5
    const hasPinTrack = !!pinTrack;

    if(this._sessionPositive.length>0){
      positive = this._sessionPositive.slice(hasPinTrack ? -8 : -25);
      this._log('info',`[Qdrant:REC] Using session feedback: ${positive.length} pos${hasPinTrack?' (reduced for pin)':''}`);
    } else {
      // ★★★ FIX: 10 was WAY too few → same tracks every session.
      // 35 random liked IDs = much wider taste representation = more diverse results.
      // Qdrant Recommend API handles 35 IDs efficiently (average_vector strategy).
      const sampleSize = Math.min(hasPinTrack ? 5 : 35, this._likedIds.length);
      const shuffled = [...this._likedIds];
      for(let i=shuffled.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[shuffled[i],shuffled[j]]=[shuffled[j],shuffled[i]];}
      positive = shuffled.slice(0, sampleSize);
      this._log('info',`[Qdrant:REC] Cold start: ${positive.length} liked IDs (of ${this._likedIds.length} total)${hasPinTrack?' (few — pin track dominant)':''}`);
    }

    // ★ Add pin track vector — TRIPLE WEIGHT (push 3 copies so it dominates Recommend API)
    if(pinTrack){
      const pinVec = Array.from(this.vectorize(pinTrack));
      positive.push(pinVec, pinVec, pinVec); // 3x weight
      this._log('info',`[Qdrant:REC] +pin track vector x3: "${(pinTrack.title||'?').substring(0,30)}" (DOMINANT)`);
    }
    // ★ Add preset vector with MOOD-SPECIFIC tuning
    if(preset&&preset.tags){
      // Build synthetic track that maximally activates the right mood dimensions
      const tagStr = (preset.tags||[]).join(' ');
      const synth={
        title: tagStr,
        genre: (preset.tags||[]).slice(0,2).join(' '),
        tag_list: tagStr,
        description: tagStr + ' ' + tagStr, // double for stronger NLP activation
        bpm: /workout|hype|edm|trap|energetic/.test(tagStr) ? 150 :
             /sleep|calm|ambient|relax|piano/.test(tagStr) ? 65 :
             /chill|lo-fi|acoustic|morning/.test(tagStr) ? 85 :
             /sad|emotional|melancholy|dark/.test(tagStr) ? 78 :
             /happy|fun|party|dance|pop/.test(tagStr) ? 125 : 110,
        duration: 210000,
        playback_count: preset.mode === 'popular' ? 500000 : 50000,
        favoritings_count: 5000,
        user: { username: '', followers_count: 10000 },
      };
      const presetVec = Array.from(this.vectorize(synth));
      // Push 2x for stronger influence
      positive.push(presetVec, presetVec);
      this._log('info',`[Qdrant:REC] +preset vector x2: "${preset.name}" (tags: ${tagStr})`);

      // ★ MOOD-SPECIFIC NEGATIVE: for sad → add energetic/happy as NEGATIVE
      // This ensures sad recommendations DON'T include upbeat tracks
      const palette = preset.palette || '';
      if (palette === 'sad' || /sad|melancholy|emotional/.test(tagStr)) {
        const antiSynth = { title:'happy party dance hype energetic upbeat fun', genre:'edm',
          tag_list:'happy party dance hype energetic upbeat workout', bpm:145, duration:210000,
          playback_count:100000, user:{username:'',followers_count:10000} };
        negative.push(Array.from(this.vectorize(antiSynth)));
        this._log('info','[Qdrant:REC] +anti-mood negative: blocking happy/energetic for SAD mode');
      } else if (palette === 'energetic' || /energetic|workout|hype/.test(tagStr)) {
        const antiSynth = { title:'calm sad melancholy ambient sleep peaceful', genre:'ambient',
          tag_list:'calm sad melancholy ambient sleep', bpm:65, duration:300000,
          playback_count:10000, user:{username:'',followers_count:5000} };
        negative.push(Array.from(this.vectorize(antiSynth)));
        this._log('info','[Qdrant:REC] +anti-mood negative: blocking calm/sad for ENERGETIC mode');
      } else if (palette === 'calm' || /calm|sleep|ambient|relax|morning/.test(tagStr)) {
        const antiSynth = { title:'trap bass aggressive heavy hype hard edm', genre:'trap',
          tag_list:'trap bass aggressive heavy hype workout hardstyle', bpm:150, duration:180000,
          playback_count:200000, user:{username:'',followers_count:20000} };
        negative.push(Array.from(this.vectorize(antiSynth)));
        this._log('info','[Qdrant:REC] +anti-mood negative: blocking aggressive/hype for CALM mode');
      } else if (palette === 'happy' || /happy|fun|party/.test(tagStr)) {
        const antiSynth = { title:'sad dark melancholy depressing lonely dark ambient', genre:'dark ambient',
          tag_list:'sad dark melancholy depressing lonely', bpm:70, duration:300000,
          playback_count:5000, user:{username:'',followers_count:2000} };
        negative.push(Array.from(this.vectorize(antiSynth)));
        this._log('info','[Qdrant:REC] +anti-mood negative: blocking sad/dark for HAPPY mode');
      }
    }

    // ★ Mode-specific: for 'favorite' mode, ONLY use liked IDs (strongest signal)
    if(preset?.mode === 'favorite' && this._likedIds.length > 0) {
      const sampleSize = Math.min(40, this._likedIds.length);
      const shuffled = [...this._likedIds];
      for(let i=shuffled.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[shuffled[i],shuffled[j]]=[shuffled[j],shuffled[i]];}
      positive = shuffled.slice(0, sampleSize); // ONLY liked, no session
      this._log('info',`[Qdrant:REC] FAVORITE mode: using ${positive.length} liked IDs ONLY (of ${this._likedIds.length})`);
    }

    if(positive.length===0){this._log('warning','[Qdrant:REC] No positive examples available');return[];}

    try{
      const body={positive,negative,filter,limit,with_payload:true,strategy:'best_score'};
      const idCount=body.positive.filter(p=>typeof p==='number').length;
      const vecCount=body.positive.filter(p=>Array.isArray(p)).length;
      this._log('info',`[Qdrant:REC] Recommend API: ${idCount} IDs + ${vecCount} vectors positive, ${negative.length} negative`);
      const resp=await this._req('POST',`/collections/${this._COLLECTION}/points/recommend`,body);
      const results=(resp.result||[]).map(r=>({track:this._payloadToTrack(r.payload),score:r.score*10})).filter(r=>r.track);
      const ms=(performance.now()-t0).toFixed(0);
      if(results.length>=5){
        this._log('info',`[Qdrant:REC] ★ SUCCESS: ${results.length} results in ${ms}ms`);
        this._log('info',`[Qdrant:REC]   Top: ${results.slice(0,3).map(r=>`"${r.track.title}"(${r.score.toFixed(1)})`).join(', ')}`);
        this._lastRecommendMs=parseInt(ms);return results;
      }else{
        this._log('warning',`[Qdrant:REC] Only ${results.length} results — insufficient`);
      }
    }catch(e){this._log('error',`[Qdrant:REC] Recommend failed: ${e.message}`);}
    return[];
  },

  // ═══ SEEDING ═══
  async seedPool(likedTracks){
    if(!this._ready||!likedTracks?.length)return;
    const t0=performance.now();
    // ★ Count YM tracks (they have _fromYM flag or we check the setting)
    const settings = (typeof Store !== 'undefined') ? (Store.get('settings') || {}) : {};
    const ymEnabled = !!settings.swUseYmPlaylist;
    this._log('info',`[Qdrant:SEED] ═══ Seeding ${likedTracks.length} likes (YM playlist: ${ymEnabled ? 'ON' : 'OFF'}) ═══`);
    // Index all liked tracks
    await this.indexTracks(likedTracks,true);
    this._ymLikedCount = ymEnabled ? likedTracks.filter(t => t._fromYM).length : 0;
    // ★ FIX: Mark profile as ready AFTER indexing (race condition fix)
    this._profileReady=true;
    this._log('info',`[Qdrant:SEED] ★ Profile READY: ${this._likedIds.length} liked IDs (${this._likedIds.length - this._ymLikedCount} SC + ${this._ymLikedCount} YM)`);
    // Enrich with Related Tracks
    const sample=this._sampleArray(likedTracks,12);
    this._log('info',`[Qdrant:SEED] Enriching from ${sample.length} seeds...`);
    await Promise.allSettled(sample.map(t=>this.enrichFromSeed(t.urn)));
    try{const info=await this._req('GET',`/collections/${this._COLLECTION}`);this._poolSize=info.result?.points_count||this._poolSize;}catch{}
    this._log('info',`[Qdrant:SEED] ═══ Done in ${(performance.now()-t0).toFixed(0)}ms — pool: ${this._poolSize}, liked IDs: ${this._likedIds.length} ═══`);
  },

  async enrichFromSeed(urn){
    if(!this._ready||!urn||this._enrichedSeeds.has(urn))return;
    this._enrichedSeeds.add(urn);
    try{if(typeof API==='undefined')return;
      const rel=await API.getRelatedTracks(urn,20);
      const tracks=(rel.collection||rel||[]).filter(t=>t?.urn&&t?.title);
      if(tracks.length>0){const c=await this.indexTracks(tracks,false);if(c>0)this._log('info',`[Qdrant:ENRICH] ...${urn.slice(-8)}: +${c} related`);}
    }catch{}
  },

  async enrichFromPlayback(track){
    if(!this._ready||!track?.urn)return;
    this._log('info',`[Qdrant:PLAY] "${(track.title||'?').substring(0,30)}" — indexing`);
    await this.indexTracks([track],false).catch(()=>{});
    this.enrichFromSeed(track.urn);
  },

  // ═══ HELPERS ═══
  _sampleArray(arr,n){if(!arr||arr.length<=n)return arr||[];const c=[...arr];for(let i=c.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[c[i],c[j]]=[c[j],c[i]];}return c.slice(0,n);},
  getStats(){return{ready:this._ready,profileReady:this._profileReady,poolSize:this._poolSize,
    likedIds:this._likedIds.length,indexed:this._indexedUrns.size,enriched:this._enrichedSeeds.size,
    sessionPos:this._sessionPositive.length,sessionNeg:this._sessionNegative.length,
    totalIndexed:this._totalIndexed,totalRequests:this._totalRequests,totalErrors:this._totalErrors,
    lastRecommendMs:this._lastRecommendMs,useProxy:this._useProxy};},
  logStats(){const s=this.getStats();
    this._log('info','[Qdrant:STATS] ═══════════════════════════════');
    this._log('info',`[Qdrant:STATS] Pool:${s.poolSize} | LikedIDs:${s.likedIds} | Profile:${s.profileReady?'YES':'NO'}`);
    this._log('info',`[Qdrant:STATS] Session: ${s.sessionPos}pos/${s.sessionNeg}neg | Enriched:${s.enriched}`);
    this._log('info',`[Qdrant:STATS] API: ${s.totalRequests}req/${s.totalErrors}err | Last rec: ${s.lastRecommendMs}ms`);
    this._log('info','[Qdrant:STATS] ═══════════════════════════════');return s;},
};
