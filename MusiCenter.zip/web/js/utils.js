

const Utils = {
  
  dur(ms) {
    if (!ms) return '0:00';
    const s = Math.floor(ms / 1000);
    const m = Math.floor(s / 60);
    return `${m}:${String(s % 60).padStart(2, '0')}`;
  },

  
  formatTime(sec) {
    if (!sec || sec < 0) return '0:00';
    const s = Math.floor(sec);
    const m = Math.floor(s / 60);
    return `${m}:${String(s % 60).padStart(2, '0')}`;
  },

  
  fc(n) {
    if (n == null) return '0';
    if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
    if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`;
    return String(n);
  },

  
  parseTags(tagStr) {
    if (!tagStr) return [];
    const tags = [];
    
    const re = /"([^"]+)"|(\S+)/g;
    let m;
    while ((m = re.exec(tagStr)) !== null) {
      const tag = (m[1] || m[2] || '').replace(/"/g, '').trim();
      if (tag.length > 1) tags.push(tag);
    }
    return tags;
  },

  
  ago(dateStr) {
    if (!dateStr) return '';
    const diff = Date.now() - new Date(dateStr).getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 1) return 'сейчас';
    if (mins < 60) return `${mins}м`;
    const hours = Math.floor(mins / 60);
    if (hours < 24) return `${hours}ч`;
    const days = Math.floor(hours / 24);
    if (days < 7) return `${days}д`;
    const weeks = Math.floor(days / 7);
    if (weeks < 4) return `${weeks}н`;
    const months = Math.floor(days / 30);
    if (months < 12) return `${months}мес`;
    return `${Math.floor(months / 12)}г`;
  },

  
  art(url, size = 't500x500') {
    if (!url) return null;
    let result = url.replace('-large', `-${size}`);
    
    if (this._imgProxyEnabled && result.includes('sndcdn.com')) {
      if (this._imgProxyFn) {
        result = this._imgProxyFn(result);
      } else {
        result = '/imgproxy?url=' + encodeURIComponent(result) + '&m=1';
      }
    }
    return result;
  },

  
  _imgProxyEnabled: false,
  _imgProxyChecked: false,
  _imgProxyFn: null,

  
  checkImageAccess() {
    if (this._imgProxyChecked) return;
    this._imgProxyChecked = true;

    const settings = Store.get('settings') || {};
    if (settings.bypassEnabled) {
      this._imgProxyEnabled = true;
      return;
    }

    const testImg = new Image();
    let resolved = false;

    const onFail = () => {
      if (resolved) return;
      resolved = true;
      console.log('[Utils] sndcdn.com CDN blocked — will suggest bypass via BypassEngine');
      Utils.log('info', '[Utils] sndcdn.com CDN blocked detected');
    };

    testImg.onload = () => { resolved = true; };
    testImg.onerror = onFail;
    testImg.src = 'https://a1.sndcdn.com/images/default_avatar_large.png?_=' + Date.now();
    setTimeout(() => { if (!resolved) onFail(); }, 5000);
  },

  
  debounce(fn, ms) {
    let timer;
    return function (...args) {
      clearTimeout(timer);
      timer = setTimeout(() => fn.apply(this, args), ms);
    };
  },

  
  throttle(fn, ms) {
    let last = 0;
    return function (...args) {
      const now = Date.now();
      if (now - last >= ms) {
        last = now;
        fn.apply(this, args);
      }
    };
  },

  
  html(str) {
    const t = document.createElement('template');
    t.innerHTML = str.trim();
    return t.content.firstChild;
  },

  
  esc(str) {
    if (!str) return '';
    return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
              .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  },

  /** Get greeting based on time of day */
  greeting() {
    const h = new Date().getHours();
    if (h < 6) return 'Доброй ночи';
    if (h < 12) return 'Доброе утро';
    if (h < 18) return 'Добрый день';
    return 'Добрый вечер';
  },

  /** Animate element in */
  animateIn(el, delay = 0) {
    el.style.animationDelay = `${delay}ms`;
    el.classList.add('animate-in');
  },

  /** Generate unique ID */
  uid() {
    return Math.random().toString(36).substr(2, 9);
  },

  /** FIX #18: Send log to server (persisted to session log file) */
  log(level, message) {
    try {
      fetch('/local/log', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ level, message }),
      }).catch(() => {});
    } catch {}
  },

  /** FIX #7: Linkify URLs in text, returns HTML with clickable links */
  linkify(text) {
    if (!text) return '';
    const escaped = this.esc(text);
    // Match URLs with protocol OR common domain patterns without protocol
    // After esc(), & becomes &amp; so we include that in URL chars
    const urlRegex = /(https?:\/\/[^\s<]+|(?:[\w-]+\.)+(?:com|net|org|io|link|me|co|be|ru|tv|gg|cc|info|dev|app|xyz|pro|club|website|site|online|live|stream|music|band|page)(?:\/[^\s<]*)?)/gi;
    return escaped.replace(urlRegex, (match) => {
      // Decode &amp; back to & for the actual URL
      const cleanUrl = match.replace(/&amp;/g, '&');
      // Add https:// if missing
      const fullUrl = cleanUrl.startsWith('http') ? cleanUrl : 'https://' + cleanUrl;
      const displayUrl = match.length > 50 ? match.substring(0, 47) + '...' : match;
      return `<a href="#" class="desc-link" onclick="event.preventDefault();event.stopPropagation();Utils._confirmLink('${this.esc(fullUrl)}')" title="${this.esc(fullUrl)}">${displayUrl}</a>`;
    });
  },

  /** FIX #7: Confirm before opening external link */
  _confirmLink(url) {
    Utils.log('info', '[Link] User clicked link: ' + url);
    InAppModal.confirm({
      title: 'Перейти по ссылке?',
      message: url,
      confirmText: 'Да, открыть',
      onConfirm: () => {
        window.open(url, '_blank');
        Utils.log('info', '[Link] Opened external link: ' + url);
      },
    });
  },
};

/* ── FIX 1: Comments overlay — JS-based centering ───── */
Utils.centerCommentsOverlay = function() {
  const overlay  = document.getElementById('comments-overlay');
  const sidebar  = document.getElementById('sidebar');
  if (!overlay) return;
  const sidebarW = sidebar ? sidebar.getBoundingClientRect().width : 200;
  const contentW = window.innerWidth - sidebarW;
  const center   = Math.round(sidebarW + contentW / 2);
  overlay.style.left      = center + 'px';
  overlay.style.transform = 'translateX(-50%)';
};

document.addEventListener('DOMContentLoaded', () => {
  Utils.centerCommentsOverlay();
  window.addEventListener('resize', Utils.throttle(Utils.centerCommentsOverlay, 100));
});

/* ═══════════════════════════════════════════════════════
   TOAST MANAGER — stacking, anti-spam, comment-aware
   ═══════════════════════════════════════════════════════ */

const ToastManager = {
  _active: [],         // [{el, height, key, timer}]
  _registry: new Map(),// key → expiry (anti-spam)

  _COMMENT_SLOT: 62,   // px per visible comment
  _BASE_BOTTOM: 82,    // px above player bar
  _GAP: 8,             // px gap between stacked toasts
  _COMMENT_GAP: 16,    // extra gap above the top comment

  /* How much vertical space comments occupy right now */
  _commentsHeight() {
    const overlay = document.getElementById('comments-overlay');
    if (!overlay) return 0;
    const count = overlay.querySelectorAll('.timed-comment.visible').length;
    return count > 0 ? count * this._COMMENT_SLOT + this._COMMENT_GAP : 0;
  },

  /* Bottom position (px) of the lowest toast slot */
  _baseBottom() {
    return this._BASE_BOTTOM + this._commentsHeight();
  },

  /* Recalculate and smoothly reposition every active toast */
  _reposition() {
    let bottom = this._baseBottom();
    // toasts array: index 0 = newest/topmost; iterate reversed (bottom → top)
    for (let i = this._active.length - 1; i >= 0; i--) {
      const item = this._active[i];
      if (!item.el.isConnected) continue;
      item.el.style.bottom = bottom + 'px';
      bottom += (item.height || 40) + this._GAP;
    }
  },

  /* Show a toast. key = anti-spam dedup key (optional). */
  show(msg, duration = 2500, key = null) {
    // Anti-spam
    if (key) {
      const expiry = this._registry.get(key);
      if (expiry && Date.now() < expiry) return;
      this._registry.set(key, Date.now() + duration + 600);
    }

    Utils.log('info', '[Toast] ' + msg);

    const el = document.createElement('div');
    el.className = 'mc-toast';
    el.textContent = msg;
    if (key) el.dataset.toastKey = key;
    document.body.appendChild(el);

    // Horizontal center
    const _center = () => {
      const ctrl = document.querySelector('.npb-controls');
      el.style.left = ctrl
        ? Math.round(ctrl.getBoundingClientRect().left + ctrl.getBoundingClientRect().width / 2) + 'px'
        : '50%';
    };

    const item = { el, height: 0, key, timer: null };
    this._active.push(item);

    // Reposition on window resize or comment count change
    const _resizeH = () => { this._reposition(); _center(); };
    window.addEventListener('resize', _resizeH);

    let _commentWatch = setInterval(() => this._reposition(), 250);

    requestAnimationFrame(() => {
      _center();
      item.height = el.offsetHeight || 40;
      // Start from slightly below final position (enter animation)
      el.style.bottom = (this._baseBottom() - 10) + 'px';
      this._reposition(); // adjust all
      requestAnimationFrame(() => el.classList.add('mc-toast-visible'));
    });

    item.timer = setTimeout(() => {
      window.removeEventListener('resize', _resizeH);
      clearInterval(_commentWatch);
      el.classList.remove('mc-toast-visible');
      el.classList.add('mc-toast-exit');
      setTimeout(() => {
        el.remove();
        this._active = this._active.filter(a => a !== item);
        if (key) this._registry.delete(key);
        this._reposition(); // slide remaining toasts down
      }, 420);
    }, duration);
  },

  /* Persistent toast — returns dismiss() function */
  persistent(msg) {
    Utils.log('info', '[Toast] ' + msg);

    const el = document.createElement('div');
    el.className = 'mc-toast mc-toast-persistent';
    el.innerHTML = `<span class="mc-toast-spin"></span><span class="mc-toast-ptxt">${Utils.esc(msg)}</span>`;
    document.body.appendChild(el);

    const _center = () => {
      const ctrl = document.querySelector('.npb-controls');
      el.style.left = ctrl
        ? Math.round(ctrl.getBoundingClientRect().left + ctrl.getBoundingClientRect().width / 2) + 'px'
        : '50%';
    };

    const item = { el, height: 0, key: null, timer: null };
    this._active.push(item);

    const _resizeH = () => { this._reposition(); _center(); };
    window.addEventListener('resize', _resizeH);
    let _commentWatch = setInterval(() => this._reposition(), 250);

    requestAnimationFrame(() => {
      _center();
      item.height = el.offsetHeight || 44;
      this._reposition();
      requestAnimationFrame(() => el.classList.add('mc-toast-visible'));
    });

    return function dismiss(finalMsg) {
      window.removeEventListener('resize', _resizeH);
      clearInterval(_commentWatch);
      if (finalMsg) {
        const ptxt = el.querySelector('.mc-toast-ptxt');
        const spin = el.querySelector('.mc-toast-spin');
        if (ptxt) ptxt.textContent = finalMsg;
        if (spin) spin.style.display = 'none';
      }
      el.classList.remove('mc-toast-visible');
      el.classList.add('mc-toast-exit');
      setTimeout(() => {
        el.remove();
        ToastManager._active = ToastManager._active.filter(a => a !== item);
        ToastManager._reposition();
      }, 420);
    };
  },
};

/* ── Public API: keep Utils.toast / Utils.toastPersistent signatures ── */
Utils._toastRegistry = ToastManager._registry; // legacy compat

Utils.toast = function(msg, duration = 2500, key = null) {
  ToastManager.show(msg, duration, key);
};

/* ── Persistent toast: responsive positioning + comment-aware ── */
Utils.toastPersistent = function(msg) {
  return ToastManager.persistent(msg);
};
/* ── FIX #10: Refresh playing state across all track cards ── */
Utils._refreshPlayingCards = function() {
  const current = Store.get('currentTrack');
  const isPlaying = Store.get('isPlaying');
  const currentUrn = current?.urn;

  document.querySelectorAll('.track-card, .search-track-row, .feed-card').forEach(card => {
    const urn = card.dataset.urn;
    const isThis = urn === currentUrn;
    const active = isThis && isPlaying;

    card.classList.toggle('playing', active);
    card.classList.toggle('active', isThis);

    // Update play/pause icon in overlay
    const playBtn = card.querySelector('.track-card-play-btn');
    if (playBtn) {
      if (active) {
        playBtn.innerHTML = '<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M6 4h4v16H6zM14 4h4v16h-4z"/></svg>';
      } else {
        playBtn.innerHTML = '<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>';
      }
    }
  });
};


/* ═══ Visibility Manager — pause heavy work when hidden ═══
   Coordinates: canvas animation, GIF bg, poll loops, etc.
   Uses Page Visibility API (document.hidden) */
const VisibilityManager = {
  _visible: true,
  _listeners: [],

  init() {
    document.addEventListener('visibilitychange', () => {
      this._visible = !document.hidden;
      Utils.log('info', `[Visibility] ${this._visible ? 'VISIBLE' : 'HIDDEN'}`);
      this._listeners.forEach(fn => { try { fn(this._visible); } catch(_) {} });
    });
  },

  isVisible() { return this._visible; },

  /** Register a callback: fn(visible: boolean) */
  onChange(fn) { this._listeners.push(fn); },
};

document.addEventListener('DOMContentLoaded', () => VisibilityManager.init());

/* ═══ Session Cache — stores data in memory for current session ═══
   Clears on app restart. Used for comments, artist tracks, artwork, etc. */
const SessionCache = {
  _comments: new Map(),    // urn → comments array
  _artistTracks: new Map(), // urn → { user, tracks }
  _artworkUrls: new Map(), // urn → resolved artwork URL
  _trackDetails: new Map(), // urn → full track object from API
  _MAX_COMMENTS: 200,
  _MAX_ARTISTS: 100,
  _MAX_ARTWORK: 500,
  _MAX_TRACKS: 500,
  /** ★ Memory fix: enforce size limits on all caches */
  _evict(map, max) {
    if (map.size <= max) return;
    const iter = map.keys();
    let toDelete = map.size - max;
    while (toDelete-- > 0) map.delete(iter.next().value);
  },

  // Comments cache
  getComments(urn) { return this._comments.get(urn) || null; },
  setComments(urn, comments) { this._comments.set(urn, comments); this._evict(this._comments, this._MAX_COMMENTS); },

  // Artist cache
  getArtist(urn) { return this._artistTracks.get(urn) || null; },
  setArtist(urn, data) { this._artistTracks.set(urn, data); this._evict(this._artistTracks, this._MAX_ARTISTS); },

  // Artwork resolved URL cache
  getArtwork(urn) { return this._artworkUrls.get(urn) || null; },
  setArtwork(urn, url) { this._artworkUrls.set(urn, url); this._evict(this._artworkUrls, this._MAX_ARTWORK); },

  // Track details cache
  getTrack(urn) { return this._trackDetails.get(urn) || null; },
  setTrack(urn, track) { this._trackDetails.set(urn, track); this._evict(this._trackDetails, this._MAX_TRACKS); },

  // Preload comments in background when track starts playing
  async preloadComments(urn) {
    if (this._comments.has(urn)) return;
    try {
      const data = await API.getTrackComments(urn, 200);
      const comments = (data.collection || [])
        .filter(c => c.timestamp != null && c.body)
        .sort((a, b) => a.timestamp - b.timestamp);
      this._comments.set(urn, comments);
      Utils.log('info', '[SessionCache] Preloaded ' + comments.length + ' comments for ' + urn);
    } catch (e) {
      Utils.log('warning', '[SessionCache] Failed to preload comments: ' + e.message);
    }
  },

  // Preload artist data in background
  async preloadArtist(urn) {
    if (this._artistTracks.has(urn)) return;
    try {
      const [user, tracksData] = await Promise.all([
        API.getUser(urn),
        API.getUserTracks(urn, 200)
      ]);
      this._artistTracks.set(urn, { user, tracks: tracksData.collection || [] });
      Utils.log('info', '[SessionCache] Preloaded artist: ' + (user?.username || urn));
    } catch (e) {
      Utils.log('warning', '[SessionCache] Failed to preload artist: ' + e.message);
    }
  },
};


/* ═══ LLTooltip — Global tooltip for LocalLikes badges ═══
   NUCLEAR APPROACH: Uses document pointermove + elementsFromPoint()
   because mouseover/mouseenter DON'T WORK inside preserve-3d cards
   in WebView2/Chromium. elementsFromPoint() bypasses ALL event issues. */
const LLTooltip = {
  _el: null,
  _visible: false,
  _initDone: false,
  _lastBadge: null,

  init() {
    if (this._initDone) return;
    this._initDone = true;

    // Create tooltip element ONCE on body
    this._el = document.createElement('div');
    this._el.className = 'll-global-tip';
    this._el.innerHTML = '<div style="margin-bottom:6px"><b>Этот трек вы лайкнули и он лежит<br>локально на вашем устройстве!</b></div><div style="margin-bottom:6px;opacity:0.85">К сожалению, это ограничение<br>САМОГО SoundCloud — нельзя много<br>треков лайкать за раз.</div><div style="margin-bottom:6px;opacity:0.85">Этот трек лежит в плейлисте<br>«Локально Нравится», и СаундВолна<br>тоже просматривает его для<br>лучших алгоритмов!</div><div style="color:var(--accent);margin-top:4px">Нажмите ПКМ → «Попробовать лайкнуть»<br>чтобы проверить, убрал ли SoundCloud<br>ограничение!</div>';
    document.body.appendChild(this._el);

    // ★ NUCLEAR: pointermove on document — fires for EVERY mouse pixel
    // Then elementsFromPoint() checks what's actually under cursor
    // This bypasses preserve-3d, overflow:hidden, contain:layout, ALL of it
    let _raf = null;
    document.addEventListener('pointermove', (e) => {
      if (_raf) return; // throttle to 1 per frame
      _raf = requestAnimationFrame(() => {
        _raf = null;
        const els = document.elementsFromPoint(e.clientX, e.clientY);
        const badge = els.find(el => el.classList && el.classList.contains('ll-badge'));
        if (badge) {
          if (this._lastBadge !== badge || !this._visible) {
            this._lastBadge = badge;
            this._showAt(e.clientX, e.clientY, badge);
          }
        } else if (this._visible) {
          this._hide();
        }
      });
    }, { passive: true });

    Utils.log('info', '[LLTooltip] Initialized with pointermove+elementsFromPoint');
  },

  _showAt(mx, my, badge) {
    const rect = badge.getBoundingClientRect();
    const tipW = 280;
    const tipH = 240;
    let left = rect.left;
    let top = rect.bottom + 8;

    // ★ If tooltip would go below viewport → show ABOVE badge
    if (top + tipH > window.innerHeight - 12) {
      top = rect.top - tipH - 8;
    }
    // ★ If tooltip would go ABOVE viewport (the old bug) → clamp to 8px from top
    if (top < 8) {
      top = 8;
    }
    // Keep within horizontal bounds
    if (left + tipW > window.innerWidth - 12) left = window.innerWidth - tipW - 12;
    if (left < 8) left = 8;

    this._el.style.left = left + 'px';
    this._el.style.top = top + 'px';
    this._el.classList.add('visible');
    this._visible = true;
  },

  _hide() {
    if (this._el) this._el.classList.remove('visible');
    this._visible = false;
    this._lastBadge = null;
  },
};

// Auto-init when DOM ready
document.addEventListener('DOMContentLoaded', () => LLTooltip.init());
// Fallback for late loading
if (document.readyState !== 'loading') setTimeout(() => LLTooltip.init(), 0);

/* ═══ MemoryGuard — prevents Out of Memory crashes ═══
   Runs every 60s: cleans caches, nullifies detached DOM refs,
   forces GC hints for Chromium renderer. */
const MemoryGuard = {
  _interval: null,
  _cleanupCount: 0,

  init() {
    // Run cleanup every 30 seconds (more aggressive for import scenarios)
    this._interval = setInterval(() => this.cleanup(), 30000);
    // Also clean on visibility change (tab hidden = good time to GC)
    if (typeof VisibilityManager !== 'undefined') {
      VisibilityManager.onChange((visible) => {
        if (!visible) this.cleanup();
      });
    }
    Utils.log('info', '[MemoryGuard] Initialized — running every 30s');
  },

  cleanup() {
    this._cleanupCount++;
    let freed = 0;

    // 1. Cap TrackRegistry
    if (typeof TrackRegistry !== 'undefined') {
      const before = TrackRegistry._map.size;
      TrackRegistry.cleanup();
      freed += before - TrackRegistry._map.size;
    }

    // 2. Cap SessionCache
    if (typeof SessionCache !== 'undefined') {
      SessionCache._evict(SessionCache._comments, SessionCache._MAX_COMMENTS);
      SessionCache._evict(SessionCache._artistTracks, SessionCache._MAX_ARTISTS);
      SessionCache._evict(SessionCache._artworkUrls, SessionCache._MAX_ARTWORK);
      SessionCache._evict(SessionCache._trackDetails, SessionCache._MAX_TRACKS);
    }

    // 3. Clean ToastManager anti-spam registry (stale entries)
    if (typeof ToastManager !== 'undefined') {
      const now = Date.now();
      for (const [key, expiry] of ToastManager._registry) {
        if (now > expiry) { ToastManager._registry.delete(key); freed++; }
      }
    }

    // 4. Clean up detached DOM nodes (orphaned overlays, popups, modals)
    document.querySelectorAll('.ym-search-popup, .context-menu, .playlist-picker-modal').forEach(el => {
      if (!el.isConnected || !document.body.contains(el)) { el.remove(); freed++; }
    });

    // 5. Limit Store._playHistory
    if (Store._playHistory && Store._playHistory.length > 100) {
      Store._playHistory = Store._playHistory.slice(-100);
      freed += Store._playHistory.length - 100;
    }

    // 6. Limit Store recentlyPlayed in memory
    const recent = Store.get('recentlyPlayed');
    if (recent && recent.length > 100) {
      Store._state.recentlyPlayed = recent.slice(0, 100);
    }

    // 7. Every 5th cleanup, hint GC by nullifying temp references
    if (this._cleanupCount % 5 === 0) {
      // Clear any cached home page data that's not visible
      if (typeof HomePage !== 'undefined' && Store.get('currentPage') !== 'home') {
        HomePage._cache = {};
        HomePage._overlayAllTracks = [];
      }
    }

    if (freed > 0 || this._cleanupCount % 5 === 0) {
      Utils.log('info', '[MemoryGuard] Cleanup #' + this._cleanupCount +
        ': freed=' + freed +
        ', TrackReg=' + (typeof TrackRegistry !== 'undefined' ? TrackRegistry._map.size : '?') +
        ', Comments=' + (typeof SessionCache !== 'undefined' ? SessionCache._comments.size : '?'));
    }
  },
};

document.addEventListener('DOMContentLoaded', () => {
  // Delay init to not compete with app startup
  setTimeout(() => MemoryGuard.init(), 5000);
});
