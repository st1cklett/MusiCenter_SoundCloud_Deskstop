

const Store = {
  _state: {
    
    sessionId: null,
    user: null,
    isAuthenticated: false,

    
    currentTrack: null,
    queue: [],
    queueIndex: -1,
    isPlaying: false,
    volume: 50,
    shuffle: false,
    repeat: 'off', 

    
    currentPage: 'home',
    searchQuery: '',
    recentSearches: [],
    recentlyPlayed: [],

    
    playlists: [],

    
    settings: {},

    
    swBlacklist: [],
    swArtistBlacklist: [],

    
    pendingLikes: [],

    
    ymSavedToken: '',

    
    _playHistory: [],

    
    lastTrackTime: 0,
  },

  _listeners: new Map(),

  get(key) { return this._state[key]; },

  set(updates) {
    const changed = {};
    
    if ('currentTrack' in updates && updates.currentTrack) {
      const oldTrack = this._state.currentTrack;
      if (oldTrack && oldTrack.urn && oldTrack.urn !== updates.currentTrack.urn) {
        
        if (!this._prevInProgress) {
          this._playHistory.push(oldTrack);
          if (this._playHistory.length > 200) this._playHistory.shift();
        }
      }
    }
    for (const [key, val] of Object.entries(updates)) {
      if (this._state[key] !== val) {
        this._state[key] = val;
        changed[key] = val;
      }
    }
    for (const [key, val] of Object.entries(changed)) {
      const listeners = this._listeners.get(key);
      if (listeners) for (const fn of listeners) fn(val, key);
    }
    if ('sessionId' in changed || 'shuffle' in changed ||
        'repeat' in changed || 'recentSearches' in changed || 'recentlyPlayed' in changed ||
        'playlists' in changed || 'settings' in changed || 'lastTrackTime' in changed ||
        'swBlacklist' in changed || 'swArtistBlacklist' in changed || 'ymSavedToken' in changed ||
        'pendingLikes' in changed) {
      this._persist();
    } else if ('volume' in changed) {
      
      this._persistVolumeThrottled();
    }
  },

  on(key, fn) {
    if (!this._listeners.has(key)) this._listeners.set(key, new Set());
    this._listeners.get(key).add(fn);
    return () => this._listeners.get(key)?.delete(fn);
  },

  _volumePersistTimer: null,
  _persistVolumeThrottled() {
    clearTimeout(this._volumePersistTimer);
    this._volumePersistTimer = setTimeout(() => this._persist(), 400);
  },

  async _persist() {
    try {
      await fetch('/local/storage', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId: this._state.sessionId,
          volume: this._state.volume,
          shuffle: this._state.shuffle,
          repeat: this._state.repeat,
          recentSearches: this._state.recentSearches.slice(0, 50),
          recentlyPlayed: this._state.recentlyPlayed.slice(0, 100),
          lastTrack: this._state.currentTrack,
          
          playlists: this._state.playlists,
          settings: this._state.settings,
          lastTrackTime: Player ? Player.getCurrentTime() : 0,
          swBlacklist: this._state.swBlacklist || [],
          swArtistBlacklist: this._state.swArtistBlacklist || [],
          pendingLikes: this._state.pendingLikes || [],
          ymSavedToken: this._state.ymSavedToken || '',
        }),
      });
    } catch (e) { console.warn('Failed to persist state:', e); }
  },

  async load() {
    try {
      const resp = await fetch('/local/storage');
      const data = await resp.json();
      if (data.sessionId) this._state.sessionId = data.sessionId;
      if (data.volume != null) this._state.volume = data.volume;
      if (data.shuffle != null) this._state.shuffle = data.shuffle;
      if (data.repeat) this._state.repeat = data.repeat;
      if (data.recentSearches) this._state.recentSearches = data.recentSearches;
      if (data.recentlyPlayed) this._state.recentlyPlayed = data.recentlyPlayed;
      if (data.lastTrack) this._state.currentTrack = data.lastTrack;
      
      
      if (data.lastTrack) {
        this._state.queue = [data.lastTrack];
        this._state.queueIndex = 0;
      }
      if (data.playlists) {
        
        this._state.playlists = data.playlists.map(pl => {
          if (pl.title === 'Яндекс Музыка' && !pl.isYandex) return { ...pl, isYandex: true };
          if (pl.title === 'Локально Нравится' && !pl.isLocalLikes) return { ...pl, isLocalLikes: true };
          return pl;
        });
      }
      if (data.settings) this._state.settings = data.settings;
      if (data.lastTrackTime != null) this._state.lastTrackTime = data.lastTrackTime;
      if (data.swBlacklist) this._state.swBlacklist = data.swBlacklist;
      if (data.swArtistBlacklist) this._state.swArtistBlacklist = data.swArtistBlacklist;
      if (data.pendingLikes) this._state.pendingLikes = data.pendingLikes;
      
      if (data.ymSavedToken) {
        this._state.ymSavedToken = data.ymSavedToken;
        
        if (typeof YandexImport !== 'undefined') {
          YandexImport._savedToken = data.ymSavedToken;
        } else {
          
          window._ymTokenPending = data.ymSavedToken;
        }
      }
    } catch (e) { console.warn('Failed to load state:', e); }
  },

  
  play(track, queue) {
    
    
    if (typeof SoundWave !== 'undefined' && SoundWave.isActive() && !SoundWave.isPaused() && !SoundWave._swResuming && !SoundWave._starting) {
      const swQueue = SoundWave._swSavedQueue.length > 0 ? SoundWave._swSavedQueue : (SoundWave._queue || []);
      const isSwTrack = swQueue.some(t => t.urn === track.urn);
      if (!isSwTrack) {
        
        SoundWave._swPaused = true;
        SoundWave._swSavedTrack = this._state.currentTrack;
        SoundWave._swSavedPos = Player.getCurrentTime();
        SoundWave._swSavedQueue = [...this._state.queue];
        SoundWave._swSavedIdx = this._state.queueIndex;
        Utils.log('info', `[Store] SoundWave auto-paused: saved "${SoundWave._swSavedTrack?.title}" at ${SoundWave._swSavedPos.toFixed(1)}s`);
        SoundWave._updatePausedBar();
        
        const h = document.getElementById('soundwave-hero');
        if (h) { h.outerHTML = SoundWave.renderHero(); SoundWave.initCanvas(); }
      }
    }

    if (queue) {
      const idx = queue.findIndex(t => t.urn === track.urn);
      Utils.log('info', `[Store] Play: "${track.title}" idx=${idx} queue=${queue.length} tracks, shuffle=${this._state.shuffle}`);
      this.set({ currentTrack: track, queue, queueIndex: idx >= 0 ? idx : 0, isPlaying: true });
    } else {
      const currentQueue = this._state.queue;
      this.set({ currentTrack: track, queue: [...currentQueue, track], queueIndex: currentQueue.length, isPlaying: true });
    }
    this._addToRecentlyPlayed(track);
  },

  pause()      { this.set({ isPlaying: false }); },
  resume()     { this.set({ isPlaying: true }); },
  togglePlay() { if (this._state.currentTrack) this.set({ isPlaying: !this._state.isPlaying }); },

  
  _playHistory: [],  

  next() {
    const { queue, queueIndex, repeat, shuffle } = this._state;
    if (queue.length === 0) return;
    
    let nextIdx;
    if (shuffle) {
      const ahead = queue.length - queueIndex - 1;
      if (ahead <= 0) {
        if (repeat === 'all') nextIdx = 0;
        else if (typeof SoundWave !== 'undefined' && SoundWave.isActive()) {
          
          SoundWave._forceGenerate();
          return;
        }
        else { this.set({ isPlaying: false }); return; }
      } else {
        nextIdx = queueIndex + 1 + Math.floor(Math.random() * ahead);
      }
    } else {
      nextIdx = queueIndex + 1;
    }
    if (nextIdx >= queue.length) {
      if (repeat === 'all') nextIdx = 0;
      else if (typeof SoundWave !== 'undefined' && SoundWave.isActive()) {
        
        SoundWave._forceGenerate();
        return;
      }
      else { this.set({ isPlaying: false }); return; }
    }
    Utils.log('info', `[Store] Next: idx ${queueIndex}→${nextIdx} "${queue[nextIdx]?.title}" (queue=${queue.length}, shuffle=${shuffle}, repeat=${repeat})`);
    this.set({ currentTrack: queue[nextIdx], queueIndex: nextIdx, isPlaying: true });
    this._addToRecentlyPlayed(queue[nextIdx]);
  },

  _prevInProgress: false,

  prev() {
    const { queue, queueIndex } = this._state;
    this._prevInProgress = true; 
    
    if (this._playHistory.length > 0) {
      const prevTrack = this._playHistory.pop();
      Utils.log('info', `[Store] Prev (history): "${prevTrack.title}" (history=${this._playHistory.length})`);
      
      const idx = queue.findIndex(t => t.urn === prevTrack.urn);
      if (idx >= 0) {
        this.set({ currentTrack: queue[idx], queueIndex: idx, isPlaying: true });
        this._prevInProgress = false;
        return;
      }
      
      const newQueue = [...queue, prevTrack];
      this.set({ currentTrack: prevTrack, queue: newQueue, queueIndex: newQueue.length - 1, isPlaying: true });
      this._prevInProgress = false;
      return;
    }
    
    const prevIdx = Math.max(0, queueIndex - 1);
    Utils.log('info', `[Store] Prev (fallback): idx ${queueIndex}→${prevIdx} "${queue[prevIdx]?.title}"`);
    if (queue[prevIdx]) this.set({ currentTrack: queue[prevIdx], queueIndex: prevIdx, isPlaying: true });
    this._prevInProgress = false;
  },

  setVolume(v)      { this.set({ volume: Math.round(Math.max(0, Math.min(100, v))) }); },
  toggleShuffle()   { this.set({ shuffle: !this._state.shuffle }); },
  toggleRepeat()    {
    const modes = ['off', 'all', 'one'];
    this.set({ repeat: modes[(modes.indexOf(this._state.repeat) + 1) % 3] });
  },

  addToQueue(tracks) {
    this.set({ queue: [...this._state.queue, ...tracks] });
  },
  removeFromQueue(index)  {
    const queue = this._state.queue.filter((_, i) => i !== index);
    let qi = this._state.queueIndex;
    if (index < qi) qi--;
    else if (index === qi) qi = Math.min(qi, queue.length - 1);
    this.set({ queue, queueIndex: qi });
  },
  clearQueue() { this.set({ queue: [], queueIndex: -1 }); },

  _addToRecentlyPlayed(track) {
    if (!track) return;
    const recent = this._state.recentlyPlayed.filter(t => t.urn !== track.urn);
    recent.unshift(track);
    this.set({ recentlyPlayed: recent.slice(0, 100) });
  },

  addRecentSearch(query) {
    if (!query?.trim()) return;
    const searches = this._state.recentSearches.filter(s => s !== query);
    searches.unshift(query);
    this.set({ recentSearches: searches.slice(0, 50) });
  },

  
  setSession(sessionId) { this.set({ sessionId, isAuthenticated: true }); },
  logout() { this.set({ sessionId: null, user: null, isAuthenticated: false }); this._persist(); },

  
  RESERVED_PLAYLIST_NAMES: ['Локально Нравится', 'Яндекс Музыка', 'YM'],

  createPlaylist(title, _system) {
    const normalized = (title || '').trim();
    
    if (!_system && this.RESERVED_PLAYLIST_NAMES.some(n => normalized.toLowerCase() === n.toLowerCase())) {
      if (typeof Utils !== 'undefined') Utils.toast('Это название зарезервировано системой');
      return null;
    }
    const pl = {
      id: Math.random().toString(36).substr(2,9) + Date.now().toString(36),
      title: title.trim() || 'Новый плейлист',
      tracks: [],
      createdAt: new Date().toISOString(),
    };
    this.set({ playlists: [...this._state.playlists, pl] });
    return pl;
  },

  addTrackToPlaylist(playlistId, track) {
    const playlists = this._state.playlists.map(pl => {
      if (pl.id !== playlistId) return pl;
      
      if (pl.tracks.find(t => t.urn === track.urn || (t.id && t.id === track.id))) return pl;
      return { ...pl, tracks: [track, ...pl.tracks] };
    });
    this.set({ playlists });
  },

  removeTrackFromPlaylist(playlistId, urn) {
    const playlists = this._state.playlists.map(pl =>
      pl.id === playlistId ? { ...pl, tracks: pl.tracks.filter(t => t.urn !== urn) } : pl
    );
    this.set({ playlists });
  },

  renamePlaylist(id, title) {
    const pl = this._state.playlists.find(p => p.id === id);
    
    if (pl && pl.isLocalLikes) return;
    
    if (pl && (pl.isYandex || pl.title === 'Яндекс Музыка')) return;
    
    const normalized = (title || '').trim();
    if (this.RESERVED_PLAYLIST_NAMES && this.RESERVED_PLAYLIST_NAMES.some(n => normalized.toLowerCase() === n.toLowerCase())) {
      if (typeof Utils !== 'undefined') Utils.toast('Это название зарезервировано системой');
      return;
    }
    const playlists = this._state.playlists.map(pl =>
      pl.id === id ? { ...pl, title: title.trim() || pl.title } : pl
    );
    this.set({ playlists });
  },

  deletePlaylist(id) {
    
    const targetPl = this._state.playlists.find(p => p.id === id);
    if (targetPl && targetPl.isLocalLikes) {
      if (typeof Utils !== 'undefined') Utils.toast('Плейлист «Локально Нравится» нельзя удалить');
      return;
    }
    
    const pl = this._state.playlists.find(p => p.id === id);
    if (pl && (pl.isYandex || pl.title === 'Яндекс Музыка')) {
      const settings = this._state.settings || {};
      if (settings.swUseYmPlaylist) {
        settings.swUseYmPlaylist = false;
        this.set({ settings });
        if (typeof SoundWave !== 'undefined' && SoundWave.isActive()) {
          SoundWave.stop();
          Utils.toast('СаундВолна остановлена — плейлист Яндекс Музыки удалён');
          if (this._state.currentPage === 'home' && typeof HomePage !== 'undefined') {
            setTimeout(() => HomePage.render(), 100);
          }
        }
      }
    }
    this.set({ playlists: this._state.playlists.filter(pl => pl.id !== id) });
  },

  setPlaylistCover(id, coverUrl) {
    const playlists = this._state.playlists.map(pl =>
      pl.id === id ? { ...pl, coverUrl } : pl
    );
    this.set({ playlists });
  },
};


const LocalLikes = {
  PLAYLIST_TITLE: 'Локально Нравится',

  
  getPlaylist() {
    let pl = (Store.get('playlists') || []).find(p => p.isLocalLikes === true);
    if (!pl) {
      pl = Store.createPlaylist(this.PLAYLIST_TITLE, true); 
      
      const playlists = Store.get('playlists').map(p =>
        p.id === pl.id ? { ...p, isLocalLikes: true } : p
      );
      Store.set({ playlists });
      pl = playlists.find(p => p.id === pl.id);
    }
    return pl;
  },

  
  addTrack(track) {
    if (!track?.urn) return;
    const pl = this.getPlaylist();
    Store.addTrackToPlaylist(pl.id, track);
    Utils.log('info', '[LocalLikes] Added: ' + (track.title || track.urn));
  },

  
  removeTrack(urn) {
    const pl = this.getPlaylist();
    if (pl) Store.removeTrackFromPlaylist(pl.id, urn);

    
    if (typeof TrackRegistry !== 'undefined') {
      const regTrack = TrackRegistry.get(urn);
      if (regTrack) delete regTrack._isLocalLike;
    }
    
    const storeQueue = (Store._state?.queue || []);
    storeQueue.forEach(t => { if (t?.urn === urn) delete t._isLocalLike; });
    const curTrack = Store.get('currentTrack');
    if (curTrack?.urn === urn) delete curTrack._isLocalLike;

    
    const escaped = CSS.escape(urn);
    document.querySelectorAll('[data-urn="' + escaped + '"]').forEach(card => {
      card.querySelectorAll('.ll-badge').forEach(b => {
        b.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
        b.style.opacity = '0';
        b.style.transform = 'scale(0.5)';
        setTimeout(() => b.remove(), 300);
      });
      card.querySelectorAll('.ll-row-icon').forEach(b => {
        b.style.transition = 'opacity 0.3s ease';
        b.style.opacity = '0';
        setTimeout(() => b.remove(), 300);
      });
      card.querySelectorAll('.ll-row-art-dot').forEach(b => {
        b.style.transition = 'opacity 0.3s ease';
        b.style.opacity = '0';
        setTimeout(() => b.remove(), 300);
      });
    });
    Utils.log('info', '[LocalLikes] Removed: ' + urn);
  },

  
  hasTrack(urn) {
    const pl = (Store.get('playlists') || []).find(p => p.isLocalLikes === true);
    if (!pl) return false;
    return pl.tracks.some(t => t.urn === urn);
  },

  
  getTracks() {
    const pl = (Store.get('playlists') || []).find(p => p.isLocalLikes === true);
    return pl ? (pl.tracks || []) : [];
  },

  
  async tryLikeAndRemove(urn) {
    try {
      await API.likeTrack(urn);
      this.removeTrack(urn);
      if (typeof NowPlayingComponent !== 'undefined') {
        NowPlayingComponent._likedTracks.add(urn);
      }
      
      this._animateRemoveTrack(urn);
      Utils.toast('Лайк прошёл! Трек удалён из «Локально Нравится»');
      Utils.log('info', '[LocalLikes] Successfully liked on SC and removed: ' + urn);
      return true;
    } catch (err) {
      if (err instanceof RateLimitError || err.status === 429) {
        Utils.toast('Лайк всё ещё недоступен! Ограничение SoundCloud.', 4000, 'local-like-fail');
      } else {
        Utils.toast('Не удалось лайкнуть — попробуйте позже', 2500, 'like-fail');
      }
      return false;
    }
  },

  
  _bulkRunning: false,
  _bulkAbort: false,

  async bulkTryLike() {
    if (this._bulkRunning) {
      
      this._bulkAbort = true;
      Utils.toast('Остановка...');
      return;
    }

    const tracks = this.getTracks();
    if (tracks.length === 0) {
      Utils.toast('Нет треков для лайка');
      return;
    }

    this._bulkRunning = true;
    this._bulkAbort = false;

    
    const btn = document.getElementById('ll-try-all-btn');
    if (btn) {
      btn.classList.add('ll-bulk-active');
      btn.innerHTML = '<div class="ll-bulk-spinner"></div> <span id="ll-bulk-text">0 / ' + tracks.length + '</span>';
    }

    let liked = 0;
    let failed = 0;
    const total = tracks.length;
    
    const snapshot = [...tracks];

    for (let i = 0; i < snapshot.length; i++) {
      if (this._bulkAbort) break;

      const t = snapshot[i];
      if (!t?.urn) continue;

      
      const textEl = document.getElementById('ll-bulk-text');
      if (textEl) textEl.textContent = (liked + failed) + ' / ' + total + ' (лайкаем...)';

      try {
        await API.likeTrack(t.urn);
        liked++;

        
        this.removeTrack(t.urn);
        if (typeof NowPlayingComponent !== 'undefined') {
          NowPlayingComponent._likedTracks.add(t.urn);
        }

        
        this._animateRemoveTrack(t.urn);

        
        if (textEl) textEl.textContent = liked + ' ✓  / ' + total;

        Utils.log('info', '[LocalLikes] Bulk liked: ' + t.title);

      } catch (err) {
        if (err instanceof RateLimitError || err.status === 429) {
          
          failed = snapshot.length - i;
          Utils.toast('Лайк недоступен! Удалось лайкнуть: ' + liked + ' из ' + total + '. Остальные попробуйте позже.', 6000, 'bulk-limit');
          Utils.log('warning', '[LocalLikes] Bulk stopped at 429 after ' + liked + ' likes');
          break;
        }
        
        failed++;
        Utils.log('warning', '[LocalLikes] Bulk skip error: ' + (err.message || err));
        continue;
      }

      
      if (i < snapshot.length - 1 && !this._bulkAbort) {
        await new Promise(r => setTimeout(r, 2500));
      }
    }

    this._bulkRunning = false;
    this._bulkAbort = false;

    
    if (btn) {
      btn.classList.remove('ll-bulk-active');
      const remaining = this.getTracks().length;
      if (remaining === 0) {
        btn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#4caf50" stroke-width="2.5"><path d="M20 6L9 17l-5-5"/></svg> Все лайкнуты!';
        btn.disabled = true;
      } else {
        btn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg> Попробовать лайкнуть все';
      }
    }

    if (liked > 0 && failed === 0) {
      Utils.toast('Все ' + liked + ' треков лайкнуты!', 4000, 'bulk-done');
    } else if (liked > 0) {
      
    }

    
    const countEl = document.querySelector('.playlist-detail-count');
    if (countEl) {
      const remaining = this.getTracks().length;
      countEl.textContent = remaining + ' ' + (remaining === 1 ? 'трек' : remaining >= 2 && remaining <= 4 ? 'трека' : 'треков');
    }
  },

  
  _animateRemoveTrack(urn) {
    const escaped = CSS.escape(urn);
    document.querySelectorAll('[data-urn="' + escaped + '"]').forEach(card => {
      const container =
        card.closest('.collection-grid-item') ||
        card.closest('.h-scroll-item') ||
        card.closest('.overlay-item') ||
        card.closest('.pl-track-row-wrap') ||
        card.closest('.track-row') ||
        card;

      
      container.style.transition = 'opacity 0.4s ease, transform 0.4s ease';
      container.style.opacity = '0';
      container.style.transform = 'scale(0.85) translateY(-8px)';

      
      setTimeout(() => {
        const h = container.offsetHeight;
        container.style.transition += ', max-height 0.35s ease, margin 0.35s ease, padding 0.35s ease';
        container.style.maxHeight = h + 'px';
        container.style.overflow = 'hidden';
        requestAnimationFrame(() => {
          container.style.maxHeight = '0';
          container.style.marginBottom = '0';
          container.style.paddingBottom = '0';
          container.style.marginTop = '0';
          container.style.paddingTop = '0';
        });
        setTimeout(() => container.remove(), 360);
      }, 380);
    });
  },
};
