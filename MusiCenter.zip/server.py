"""Flask server - serves frontend and proxies SoundCloud API."""
import json
import logging
import os
import threading
import time
import urllib.parse
import hmac
import hashlib
import base64
from datetime import datetime, timezone
import requests
from flask import Flask, request, jsonify, send_from_directory, Response
import logging as _logging
_logging.getLogger('werkzeug').setLevel(_logging.ERROR)

MX_BASE      = 'https://apic-desktop.musixmatch.com'
MX_API_URL   = MX_BASE + '/ws/1.1/'
MX_HMAC_KEY  = b'IEJ5E8XFaHQvIQNfs7IC'
MX_HEADERS   = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
                  'Musixmatch/0.19.4 Chrome/58.0.3029.110 Electron/1.7.6 Safari/537.36',
    'Accept': 'application/json',
}
MX_COOKIES = {'AWSELB': 'unknown'}
MX_TIMEOUT = 12

_mx_token      = None
_mx_token_time = 0
_mx_token_lock = threading.Lock()
_mx_captcha_until = 0

def _mx_sign(method, params_dict):
    """Build HMAC-SHA1 signature for Musixmatch desktop API."""
    ts = datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')
    sorted_params = sorted(params_dict.items())
    query_str = urllib.parse.urlencode(sorted_params)
    to_sign = f'/ws/1.1/{method}?{query_str}{ts}'
    sig = hmac.new(MX_HMAC_KEY, to_sign.encode('utf-8'), hashlib.sha1).digest()
    return base64.urlsafe_b64encode(sig).decode('utf-8'), ts

def _mx_get_token():
    """Get or refresh an anonymous Musixmatch user token (thread-safe)."""
    global _mx_token, _mx_token_time
    with _mx_token_lock:
        if _mx_token and (time.time() - _mx_token_time) < 600:
            return _mx_token

        log.info('[MX] Requesting new anonymous user token...')
        params = {
            'app_id': 'web-desktop-app-v1.0',
        }
        sig, ts = _mx_sign('token.get', params)
        params['signature'] = sig
        params['signature_protocol'] = 'sha1'

        for attempt in range(3):
            try:
                resp = requests.get(
                    MX_API_URL + 'token.get',
                    params=params, headers=MX_HEADERS,
                    cookies=MX_COOKIES, timeout=MX_TIMEOUT
                )
                data = resp.json()
                token = data.get('message', {}).get('body', {}).get('user_token', '')
                if token and token != 'MusixmatchUserToken' and 'undefined' not in token:
                    _mx_token = token
                    _mx_token_time = time.time()
                    log.info(f'[MX] Got user token: {token[:24]}...')
                    return token
                log.warning(f'[MX] Token attempt {attempt+1}: invalid token "{token[:30]}"')
            except Exception as e:
                log.warning(f'[MX] Token attempt {attempt+1} failed: {e}')
            time.sleep(0.5)

        log.error('[MX] All token attempts failed')
        return None

def _mx_api_call(method, extra_params=None):
    """Make a signed Musixmatch desktop API call. Returns parsed JSON or None."""
    global _mx_captcha_until

    if time.time() < _mx_captcha_until:
        remaining = int(_mx_captcha_until - time.time())
        log.info(f'[MX] Skipping {method} — captcha cooldown ({remaining}s left)')
        return None

    token = _mx_get_token()
    if not token:
        return None

    params = {
        'app_id':    'web-desktop-app-v1.0',
        'usertoken': token,
        'format':    'json',
    }
    if extra_params:
        params.update(extra_params)

    sig, ts = _mx_sign(method, params)
    params['signature']          = sig
    params['signature_protocol'] = 'sha1'

    try:
        resp = requests.get(
            MX_API_URL + method,
            params=params, headers=MX_HEADERS,
            cookies=MX_COOKIES, timeout=MX_TIMEOUT
        )
        data = resp.json()
        status = data.get('message', {}).get('header', {}).get('status_code', 0)
        hint   = data.get('message', {}).get('header', {}).get('hint', '')

        if status == 401 and hint == 'captcha':
            log.warning('[MX] Captcha required — cooldown 90s, resetting token')
            _mx_captcha_until = time.time() + 90
            with _mx_token_lock:
                _mx_token = None
                _mx_token_time = 0
            return None
        if status == 401:
            log.warning(f'[MX] Auth error ({hint}) — resetting token')
            with _mx_token_lock:
                _mx_token = None
                _mx_token_time = 0
            return None
        if status != 200:
            log.warning(f'[MX] API {method} status={status} hint={hint}')
            return None
        return data
    except Exception as e:
        log.warning(f'[MX] API call {method} failed: {e}')
        return None

API_BASE = 'https://backend.soundcloud.work.gd'
PROXY_TIMEOUT = 30

BYPASS_BACKENDS = [
    'https://backend.soundcloud.work.gd',
    'https://api-v2.soundcloud.com',
    'https://api.soundcloud.com',
]

CORS_PROXIES = [
    'https://corsproxy.io/?',
    'https://api.allorigins.win/raw?url=',
    'https://api.codetabs.com/v1/proxy?quest=',
]

def _build_artwork_proxy_url(method_index, img_url):
    """Return a proxied URL for method_index (0=direct, 1-10=external proxies)."""
    enc = urllib.parse.quote(img_url, safe='')
    methods = [
        img_url,
        f'https://wsrv.nl/?url={enc}&output=jpg&default=1',
        f'https://images.weserv.nl/?url={enc}&output=jpg&default=1',
        f'https://corsproxy.io/?{enc}',
        f'https://api.allorigins.win/raw?url={enc}',
        f'https://thingproxy.freeboard.io/fetch/{img_url}',
        f'https://api.codetabs.com/v1/proxy?quest={enc}',
        f'https://proxy.cors.sh/{img_url}',
        f'https://cors.bridged.cc/{img_url}',
        f'https://cors-anywhere.herokuapp.com/{img_url}',
        f'https://yacdn.org/proxy/{img_url}',
        f'https://api.codetabs.com/v1/proxy?quest={enc}',
    ]
    if method_index < 0 or method_index >= len(methods):
        return None
    return methods[method_index]

ARTWORK_PROXY_METHOD_COUNT = 12

DOH_PROVIDERS = [
    'https://cloudflare-dns.com/dns-query',
    'https://dns.google/resolve',
    'https://dns.quad9.net:5053/dns-query',
]

log = logging.getLogger('MusiCenter.Server')

_active_backend = API_BASE
_backend_lock = threading.Lock()

def get_active_backend():
    with _backend_lock:
        return _active_backend

def set_active_backend(url):
    global _active_backend
    with _backend_lock:
        _active_backend = url
    log.info(f'[BYPASS] Active backend set to: {url}')

def resolve_via_doh(hostname):
    """Resolve hostname using DNS-over-HTTPS to bypass DNS poisoning."""
    for provider in DOH_PROVIDERS:
        try:
            if 'google' in provider:
                resp = requests.get(provider, params={'name': hostname, 'type': 'A'},
                                   headers={'Accept': 'application/dns-json'}, timeout=5)
                if resp.ok:
                    data = resp.json()
                    for ans in data.get('Answer', []):
                        if ans.get('type') == 1:
                            return ans['data']
            else:
                resp = requests.get(provider, params={'name': hostname, 'type': 'A'},
                                   headers={'Accept': 'application/dns-json'}, timeout=5)
                if resp.ok:
                    data = resp.json()
                    for ans in data.get('Answer', []):
                        if ans.get('type') == 1:
                            return ans['data']
        except Exception as e:
            log.debug(f'[DOH] {provider} failed for {hostname}: {e}')
            continue
    return None

SEARCH_FORMATS = [
    lambda q, t, lim, off: (f'{API_BASE}/search/tracks', {'q': q, 'limit': lim, 'offset': off, 'linked_partitioning': 1}),
    lambda q, t, lim, off: (f'{API_BASE}/search', {'q': q, 'type': t, 'limit': lim, 'offset': off}),
    lambda q, t, lim, off: (f'{API_BASE}/search', {'q': q, 'kind': t, 'limit': lim, 'offset': off}),
    lambda q, t, lim, off: (f'{API_BASE}/tracks', {'q': q, 'limit': lim, 'offset': off}),
    lambda q, t, lim, off: (f'{API_BASE}/search', {'q': q, 'limit': lim, 'offset': off}),
    lambda q, t, lim, off: (f'{API_BASE}/search', {'q': q, 'filter': 'streamable', 'limit': lim, 'offset': off}),
    lambda q, t, lim, off: (f'{API_BASE}/tracks', {'q': q, 'filter': 'streamable', 'limit': lim, 'offset': off}),
    lambda q, t, lim, off: (f'{API_BASE}/search/tracks', {'q': q, 'facet': 'genre', 'limit': lim, 'offset': off, 'linked_partitioning': 1}),
    lambda q, t, lim, off: (f'{API_BASE}/search', {'query_urn': 'soundcloud:search-autocomplete', 'q': q, 'limit': lim}),
    lambda q, t, lim, off: (f'{API_BASE}/search', {'q': q, 'type': t, 'variant_ids': '', 'limit': lim, 'offset': off}),
    lambda q, t, lim, off: (f'{API_BASE}/search/users', {'q': q, 'limit': lim, 'offset': off}) if t == 'users' else (f'{API_BASE}/search/tracks', {'q': q, 'limit': lim, 'offset': off}),
    lambda q, t, lim, off: (f'{API_BASE}/search/playlists', {'q': q, 'limit': lim, 'offset': off}) if t == 'playlists' else (f'{API_BASE}/search/tracks', {'q': q, 'limit': lim, 'offset': off}),
    lambda q, t, lim, off: (f'{API_BASE}/search/autocomplete', {'q': q, 'limit': lim}),
    lambda q, t, lim, off: (f'{API_BASE}/tracks', {'q': q, 'types': 'track', 'license': 'all-rights-reserved', 'limit': lim}),
    lambda q, t, lim, off: (f'{API_BASE}/resolve', {'url': f'https://soundcloud.com/search?q={q}'}),
]


def create_app(web_dir, appdata_dir):
    app = Flask(__name__, static_folder=None)
    app.config['APPDATA_DIR'] = appdata_dir
    storage_file = os.path.join(appdata_dir, 'storage.json')

    _storage_lock = threading.Lock()

    def _load_storage():
        with _storage_lock:
            if not os.path.exists(storage_file):
                return {}
            try:
                with open(storage_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception as e:
                log.warning(f'Failed to load storage: {e}')
                return {}

    def _save_storage(data):
        with _storage_lock:
            tmp = storage_file + '.tmp'
            with open(tmp, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            os.replace(tmp, storage_file)

    @app.route('/')
    def index():
        return send_from_directory(web_dir, 'index.html')

    @app.route('/<path:filename>')
    def static_files(filename):
        return send_from_directory(web_dir, filename)

    QDRANT_URL = 'https://230ea21a-0600-4b2d-8482-fd57f2b315f2.europe-west3-0.gcp.cloud.qdrant.io:6333'
    QDRANT_KEY = 'YOUR_QDRANT_API_KEY_HERE'

    @app.route('/api/qdrant/<path:path>', methods=['GET', 'POST', 'PUT', 'DELETE', 'PATCH'])
    def qdrant_proxy(path):
        try:
            url = f'{QDRANT_URL}/{path}'
            headers = {'Content-Type': 'application/json', 'api-key': QDRANT_KEY}
            resp = requests.request(
                request.method, url, headers=headers,
                data=request.get_data(), timeout=30
            )
            return resp.content, resp.status_code, {'Content-Type': resp.headers.get('Content-Type', 'application/json')}
        except Exception as e:
            return json.dumps({'error': str(e)}), 502, {'Content-Type': 'application/json'}

    @app.route('/local/log', methods=['POST'])
    def js_log():
        data = request.get_json(force=True, silent=True) or {}
        level = data.get('level', 'info').upper()
        msg = data.get('message', '')
        lvl = getattr(logging, level, logging.INFO)
        logging.getLogger('MusiCenter.JS').log(lvl, '[JS] %s', msg)
        return jsonify({'ok': True})

    @app.route('/local/storage', methods=['GET'])
    def get_storage():
        return jsonify(_load_storage())

    @app.route('/local/storage', methods=['POST'])
    def set_storage():
        data = request.get_json(force=True)
        current = _load_storage()
        current.update(data)
        _save_storage(current)
        return jsonify({'ok': True})

    @app.route('/local/storage/<key>', methods=['GET'])
    def get_storage_key(key):
        data = _load_storage()
        return jsonify({'value': data.get(key)})

    @app.route('/local/storage/<key>', methods=['DELETE'])
    def delete_storage_key(key):
        data = _load_storage()
        data.pop(key, None)
        _save_storage(data)
        return jsonify({'ok': True})

    @app.route('/local/bypass/probe', methods=['POST'])
    def bypass_probe():
        """Try a list of backend methods; return the first that works."""
        data = request.get_json(force=True, silent=True) or {}
        session_id = data.get('sessionId', '')
        method_index = data.get('methodIndex', 0)

        backends = []
        for base in BYPASS_BACKENDS:
            backends.append(base)
        for proxy in CORS_PROXIES:
            backends.append(proxy + BYPASS_BACKENDS[0])

        if method_index >= len(backends):
            return jsonify({'ok': False, 'error': 'all_exhausted', 'total': len(backends)})

        url = backends[method_index]
        test_url = url.rstrip('/') + '/me'
        headers = {}
        if session_id:
            headers['x-session-id'] = session_id

        try:
            resp = requests.get(test_url, headers=headers, timeout=12)
            if resp.status_code == 200:
                base = url
                for proxy in CORS_PROXIES:
                    if url.startswith(proxy):
                        base = url
                        break
                set_active_backend(base if not any(url.startswith(p) for p in CORS_PROXIES) else BYPASS_BACKENDS[0])
                return jsonify({'ok': True, 'methodIndex': method_index, 'backend': url})
        except Exception as e:
            log.debug(f'[BYPASS] Method {method_index} ({url}) failed: {e}')

        return jsonify({'ok': False, 'methodIndex': method_index})

    @app.route('/local/bypass/check_artwork', methods=['POST'])
    def check_artwork():
        """Check if SoundCloud artwork CDN is reachable."""
        data = request.get_json(force=True, silent=True) or {}
        artwork_url = data.get('url', '')
        if not artwork_url or 'sndcdn.com' not in artwork_url:
            return jsonify({'reachable': False, 'error': 'invalid_url'})
        try:
            resp = requests.head(artwork_url, timeout=8, allow_redirects=True)
            return jsonify({'reachable': resp.status_code == 200, 'status': resp.status_code})
        except Exception as e:
            return jsonify({'reachable': False, 'error': str(e)})

    @app.route('/local/bypass/doh_resolve', methods=['POST'])
    def doh_resolve():
        """Resolve a hostname via DNS-over-HTTPS."""
        data = request.get_json(force=True, silent=True) or {}
        hostname = data.get('hostname', 'backend.soundcloud.work.gd')
        ip = resolve_via_doh(hostname)
        return jsonify({'hostname': hostname, 'ip': ip})

    @app.route('/local/bypass/status', methods=['GET'])
    def bypass_status():
        return jsonify({'activeBackend': get_active_backend(), 'defaultBackend': API_BASE})

    _cdn_cache = {}
    _CDN_CACHE_MAX = 500
    _CDN_CACHE_TTL = 3600

    @app.route('/cdn/<path:url>')
    def proxy_cdn(url):
        """Proxy any sndcdn.com URL through the server."""
        full_url = 'https://' + url
        qs = request.query_string.decode()
        if qs:
            full_url += '?' + qs

        if 'sndcdn.com' not in url and 'soundcloud.com' not in url:
            return jsonify({'error': 'forbidden domain'}), 403

        now = time.time()
        if full_url in _cdn_cache:
            ct, data, ts = _cdn_cache[full_url]
            if now - ts < _CDN_CACHE_TTL:
                return Response(data, content_type=ct, headers={
                    'Cache-Control': 'public, max-age=86400',
                    'Access-Control-Allow-Origin': '*',
                })

        try:
            resp = requests.get(full_url, timeout=15, stream=False,
                                headers={'User-Agent': 'Mozilla/5.0'})
            if resp.status_code == 200:
                ct = resp.headers.get('content-type', 'image/jpeg')
                data = resp.content

                if len(_cdn_cache) >= _CDN_CACHE_MAX:
                    oldest_key = min(_cdn_cache, key=lambda k: _cdn_cache[k][2])
                    del _cdn_cache[oldest_key]
                _cdn_cache[full_url] = (ct, data, now)

                return Response(data, content_type=ct, headers={
                    'Cache-Control': 'public, max-age=86400',
                    'Access-Control-Allow-Origin': '*',
                })
            else:
                return Response(b'', status=resp.status_code)
        except Exception as e:
            log.warning(f'[CDN] Failed to proxy {full_url}: {e}')
            return Response(b'', status=502)

    @app.route('/local/bypass/check_cdn', methods=['GET'])
    def check_cdn_reachable():
        """Check if sndcdn.com CDN is directly reachable (not blocked)."""
        test_url = 'https://i1.sndcdn.com/artworks-000000000000-000000-large.jpg'
        try:
            resp = requests.head(test_url, timeout=6, allow_redirects=True,
                                 headers={'User-Agent': 'Mozilla/5.0'})
            reachable = resp.status_code < 500
            log.info(f'[CDN] Direct check: status={resp.status_code} reachable={reachable}')
            return jsonify({'reachable': reachable, 'status': resp.status_code})
        except requests.Timeout:
            log.info('[CDN] Direct check: TIMEOUT — CDN is blocked')
            return jsonify({'reachable': False, 'error': 'timeout'})
        except requests.ConnectionError as e:
            log.info(f'[CDN] Direct check: CONNECTION ERROR — CDN is blocked: {e}')
            return jsonify({'reachable': False, 'error': 'connection_error'})
        except Exception as e:
            log.info(f'[CDN] Direct check: ERROR — {e}')
            return jsonify({'reachable': False, 'error': str(e)})

    @app.route('/imgproxy')
    def proxy_image():
        """Proxy images from blocked SoundCloud CDN using 10+ fallback services."""
        url = request.args.get('url', '')
        method = int(request.args.get('m', '0'))
        if not url or not any(d in url for d in ['sndcdn.com', 'soundcloud.com']):
            return Response('Forbidden', status=403)

        req_headers = {'User-Agent': 'Mozilla/5.0', 'Referer': 'https://soundcloud.com/'}

        TIMEOUTS = {0: 5, 1: 8, 2: 8, 3: 6, 4: 8, 5: 6, 6: 6, 7: 6, 8: 6, 9: 6, 10: 6, 11: 6}

        for idx in range(method, ARTWORK_PROXY_METHOD_COUNT):
            proxy_url = _build_artwork_proxy_url(idx, url)
            if not proxy_url:
                continue
            timeout = TIMEOUTS.get(idx, 6)
            try:
                resp = requests.get(proxy_url, timeout=timeout, stream=False,
                                    headers=req_headers, allow_redirects=True)
                if resp.status_code == 200 and len(resp.content) > 100:
                    ct = resp.headers.get('content-type', 'image/jpeg')
                    if 'image' in ct or 'octet' in ct or idx == 0:
                        log.debug(f'[IMGPROXY] method={idx} success for {url[:60]}')
                        return Response(resp.content, content_type=ct, headers={
                            'Cache-Control': 'public, max-age=86400',
                            'Access-Control-Allow-Origin': '*',
                            'X-Proxy-Method': str(idx),
                        })
                log.debug(f'[IMGPROXY] method={idx} status={resp.status_code}, trying next')
            except Exception as e:
                log.debug(f'[IMGPROXY] method={idx} error: {e}')
                continue

        log.warning(f'[IMGPROXY] All {ARTWORK_PROXY_METHOD_COUNT} methods failed for {url[:60]}')
        return Response(b'', status=502, headers={'X-Proxy-Method': 'all_failed'})

    @app.route('/local/bypass/artwork_method_count', methods=['GET'])
    def artwork_method_count():
        """Tell the frontend how many proxy methods are available."""
        return jsonify({'count': ARTWORK_PROXY_METHOD_COUNT})

    _sc_client_id_cache = {'id': None, 'ts': 0}

    def _get_sc_client_id():
        import time as _time
        if _sc_client_id_cache['id'] and (_time.time() - _sc_client_id_cache['ts']) < 3600:
            return _sc_client_id_cache['id']
        try:
            resp = requests.get('https://soundcloud.com', headers={
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }, timeout=10)
            if resp.status_code != 200:
                return None
            import re
            js_urls = re.findall(r'src="(https://a-v2\.sndcdn\.com/assets/[^"]+\.js)"', resp.text)
            if not js_urls:
                js_urls = re.findall(r'(https://a-v2\.sndcdn\.com/assets/[a-zA-Z0-9_-]+\.js)', resp.text)
            for js_url in js_urls[-5:]:
                try:
                    jr = requests.get(js_url, timeout=10)
                    if jr.status_code == 200:
                        m = re.search(r'client_id[=:]["\'"]([a-zA-Z0-9]{20,})["\']', jr.text)
                        if m:
                            cid = m.group(1)
                            _sc_client_id_cache['id'] = cid
                            _sc_client_id_cache['ts'] = _time.time()
                            log.info(f'[SC] Extracted client_id: {cid[:8]}...')
                            return cid
                except Exception:
                    continue
        except Exception as e:
            log.debug(f'[SC] client_id extraction failed: {e}')
        return None

    @app.route('/api/mixed-selections', methods=['GET'])
    def mixed_selections():
        session_id = request.headers.get('x-session-id')
        params = dict(request.args)
        if 'limit' not in params:
            params['limit'] = 10

        if session_id:
            try:
                resp = requests.get('https://api-v2.soundcloud.com/mixed-selections',
                    headers={'Authorization': f'OAuth {session_id}', 'Accept': 'application/json'},
                    params=params, timeout=15)
                if resp.status_code == 200:
                    log.info('[MIXED] Success with OAuth token')
                    return Response(resp.content, status=200, headers={'Content-Type': 'application/json'})
                log.debug(f'[MIXED] OAuth attempt: {resp.status_code}')
            except Exception as e:
                log.debug(f'[MIXED] OAuth error: {e}')

        client_id = _get_sc_client_id()
        if client_id:
            try:
                params['client_id'] = client_id
                resp = requests.get('https://api-v2.soundcloud.com/mixed-selections',
                    params=params, timeout=15)
                if resp.status_code == 200:
                    log.info('[MIXED] Success with client_id')
                    return Response(resp.content, status=200, headers={'Content-Type': 'application/json'})
                log.debug(f'[MIXED] client_id attempt: {resp.status_code}')
            except Exception as e:
                log.debug(f'[MIXED] client_id error: {e}')

        if session_id:
            try:
                resp = requests.get(f'{get_active_backend()}/mixed-selections',
                    headers={'Authorization': f'OAuth {session_id}', 'Accept': 'application/json'},
                    params=params, timeout=15)
                if resp.status_code == 200:
                    log.info('[MIXED] Success via proxy')
                    return Response(resp.content, status=200, headers={'Content-Type': 'application/json'})
            except Exception:
                pass

        log.warning('[MIXED] All methods failed')
        return jsonify({'collection': []}), 200

    @app.route('/api/system-playlists/<path:pl_id>', methods=['GET'])
    def system_playlist(pl_id):
        session_id = request.headers.get('x-session-id')
        headers = {}
        if session_id:
            headers['Authorization'] = f'OAuth {session_id}'
        headers['Accept'] = 'application/json'

        for base in ['https://api-v2.soundcloud.com', get_active_backend()]:
            try:
                resp = requests.get(f'{base}/system-playlists/{pl_id}', headers=headers,
                                    params=dict(request.args), timeout=15)
                if resp.status_code == 200:
                    return Response(resp.content, status=200,
                                    headers={'Content-Type': 'application/json'})
            except Exception:
                continue
        return jsonify({'error': 'Not found'}), 404

    @app.route('/api/search_smart', methods=['GET'])
    def smart_search():
        q = request.args.get('q', '')
        t = request.args.get('type', 'tracks')
        lim = request.args.get('limit', 30)
        off = request.args.get('offset', 0)

        session_id = request.headers.get('x-session-id')
        headers = {}
        if session_id:
            headers['x-session-id'] = session_id

        last_status = 404
        last_body = b'{}'

        backend = get_active_backend()

        search_formats = [
            lambda q, t, lim, off, b=backend: (f'{b}/search/tracks', {'q': q, 'limit': lim, 'offset': off, 'linked_partitioning': 1}),
            lambda q, t, lim, off, b=backend: (f'{b}/search', {'q': q, 'type': t, 'limit': lim, 'offset': off}),
            lambda q, t, lim, off, b=backend: (f'{b}/search', {'q': q, 'kind': t, 'limit': lim, 'offset': off}),
            lambda q, t, lim, off, b=backend: (f'{b}/tracks', {'q': q, 'limit': lim, 'offset': off}),
            lambda q, t, lim, off, b=backend: (f'{b}/search', {'q': q, 'limit': lim, 'offset': off}),
        ]

        for fmt in search_formats:
            try:
                url, params = fmt(q, t, lim, off)
                resp = requests.get(url, headers=headers, params=params, timeout=15)
                log.debug(f'[SEARCH] Trying {url} => {resp.status_code}')
                if resp.status_code == 200:
                    try:
                        data = resp.json()
                        if isinstance(data, list):
                            data = {'collection': data}
                        elif 'collection' not in data:
                            if isinstance(data, dict) and 'tracks' in data:
                                data = {'collection': data['tracks']}
                            else:
                                data = {'collection': []}
                    except Exception:
                        data = {'collection': []}
                    return jsonify(data), 200
                last_status = resp.status_code
                last_body = resp.content
            except requests.Timeout:
                log.warning(f'[SEARCH] Timeout for format')
                continue
            except Exception as e:
                log.warning(f'[SEARCH] Error: {e}')
                continue

        log.error(f'[SEARCH] All formats failed for q={q!r}')
        return jsonify({'collection': [], 'error': f'All search formats failed (last: {last_status})'}), 200

    @app.route('/api/musixmatch/lyrics')
    def mx_lyrics():
        """Search for lyrics via Musixmatch unofficial desktop API.
        Params: artist, title
        Returns: { synced: "LRC string"|null, plain: "text"|null, source: "musixmatch" }
        """
        artist = request.args.get('artist', '').strip()
        title  = request.args.get('title', '').strip()
        if not title:
            return jsonify({'error': 'title required'}), 400

        log.info(f'[MX] Lyrics search: artist="{artist}" title="{title}"')

        match_params = {'q_track': title}
        if artist:
            match_params['q_artist'] = artist
        data = _mx_api_call('matcher.track.get', match_params)

        if not data:
            log.info('[MX] matcher.track.get returned None')
            return jsonify({'synced': None, 'plain': None, 'source': 'musixmatch'}), 200

        try:
            track = data['message']['body']['track']
            track_id      = track['track_id']
            commontrack_id = track.get('commontrack_id', track_id)
            has_subtitles = track.get('has_subtitles', 0)
            has_lyrics    = track.get('has_lyrics', 0)
            log.info(f'[MX] Matched track_id={track_id} has_sub={has_subtitles} has_lyr={has_lyrics}')
        except (KeyError, TypeError, IndexError) as e:
            log.info(f'[MX] Track parse error: {e}')
            return jsonify({'synced': None, 'plain': None, 'source': 'musixmatch'}), 200

        result = {'synced': None, 'plain': None, 'source': 'musixmatch'}

        if has_subtitles:
            sub_data = _mx_api_call('track.subtitles.get', {
                'track_id':        str(track_id),
                'subtitle_format': 'lrc',
            })
            if sub_data:
                try:
                    sub_list = sub_data['message']['body'].get('subtitle_list', [])
                    if sub_list:
                        sub_body = sub_list[0]['subtitle'].get('subtitle_body', '')
                        if sub_body and '[' in sub_body:
                            result['synced'] = sub_body
                            log.info(f'[MX] Got synced LRC ({len(sub_body)} chars)')
                except (KeyError, TypeError, IndexError) as e:
                    log.info(f'[MX] Subtitle parse error: {e}')

        if has_lyrics:
            lyr_data = _mx_api_call('track.lyrics.get', {
                'track_id': str(track_id),
            })
            if lyr_data:
                try:
                    lyrics_body = lyr_data['message']['body']['lyrics'].get('lyrics_body', '')
                    if lyrics_body and len(lyrics_body) > 10:
                        result['plain'] = lyrics_body
                        log.info(f'[MX] Got plain lyrics ({len(lyrics_body)} chars)')
                except (KeyError, TypeError, IndexError) as e:
                    log.info(f'[MX] Lyrics parse error: {e}')

        found = bool(result['synced'] or result['plain'])
        log.info(f'[MX] Result: synced={"yes" if result["synced"] else "no"} plain={"yes" if result["plain"] else "no"}')
        return jsonify(result), 200

    @app.route('/api/musixmatch/status')
    def mx_status():
        """Check if Musixmatch token is available and not in cooldown."""
        with _mx_token_lock:
            has_token = _mx_token is not None
        in_cooldown = time.time() < _mx_captcha_until
        cooldown_left = max(0, int(_mx_captcha_until - time.time())) if in_cooldown else 0
        return jsonify({
            'available': has_token and not in_cooldown,
            'cooldown': in_cooldown,
            'cooldown_seconds': cooldown_left,
        })

    @app.route('/api/<path:path>', methods=['GET', 'POST', 'PUT', 'DELETE'])
    def proxy_api(path):
        url = f'{get_active_backend()}/{path}'
        headers = {}
        session_id = request.headers.get('x-session-id')
        if session_id:
            headers['x-session-id'] = session_id

        params = dict(request.args)

        _is_auth = ('auth' in path or path.rstrip('/') in ('me', 'users/me'))
        _timeout = 10 if _is_auth else PROXY_TIMEOUT
        if _is_auth:
            sid_preview = (session_id[:8] + '...') if session_id else 'NONE'
            log.info(f'[AUTH] {request.method} /api/{path} | session_id={sid_preview}')

        try:
            if request.method == 'GET':
                resp = requests.get(url, headers=headers, params=params, timeout=_timeout)
            elif request.method == 'POST':
                resp = requests.post(url, headers=headers, params=params,
                                     json=request.get_json(silent=True), timeout=_timeout)
            elif request.method == 'PUT':
                resp = requests.put(url, headers=headers, params=params,
                                    json=request.get_json(silent=True), timeout=_timeout)
            elif request.method == 'DELETE':
                resp = requests.delete(url, headers=headers, params=params, timeout=_timeout)
            else:
                return jsonify({'error': 'Method not allowed'}), 405

            if _is_auth:
                ct = resp.headers.get('content-type', '')
                try:
                    body_preview = str(resp.json())[:400]
                except Exception:
                    body_preview = resp.text[:200]
                log.info(f'[AUTH] Response {resp.status_code} for /api/{path} | ct={ct} | body={body_preview}')

            if resp.status_code == 429:
                retry_after = resp.headers.get('Retry-After', resp.headers.get('X-RateLimit-Reset', 'unknown'))
                log.warning(f'[PROXY] 429 Rate Limited for {path} | Retry-After: {retry_after}s | '
                            f'method={request.method}')

            excluded_headers = {'content-encoding', 'transfer-encoding', 'connection'}
            response_headers = {k: v for k, v in resp.headers.items()
                                if k.lower() not in excluded_headers}
            return Response(resp.content, status=resp.status_code, headers=response_headers)

        except requests.Timeout:
            log.error(f'[PROXY] Timeout for {path}')
            return jsonify({'error': 'Backend timeout'}), 504
        except requests.ConnectionError as e:
            log.error(f'[PROXY] ConnectionError for {path}: {e}')
            return jsonify({'error': 'Backend unreachable'}), 502
        except Exception as e:
            log.error(f'[PROXY] Unexpected error for {path}: {e}')
            return jsonify({'error': str(e)}), 500

    @app.route('/stream/<path:path>')
    def proxy_stream(path):
        url = f'{get_active_backend()}/{path}'
        params = dict(request.args)
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept': 'audio/mpeg, audio/*, */*',
        }
        session_id = params.pop('session_id', None) or request.headers.get('x-session-id')
        if session_id:
            headers['x-session-id'] = session_id

        range_header = request.headers.get('Range')
        if range_header:
            headers['Range'] = range_header

        try:
            resp = requests.get(url, headers=headers, params=params,
                                stream=False, timeout=30, allow_redirects=True)
            excluded = {'content-encoding', 'transfer-encoding', 'connection', 'keep-alive'}
            response_headers = {k: v for k, v in resp.headers.items()
                                if k.lower() not in excluded}
            response_headers['Access-Control-Allow-Origin'] = '*'
            response_headers['Accept-Ranges'] = 'bytes'
            response_headers['Content-Length'] = str(len(resp.content))

            return Response(resp.content, status=resp.status_code, headers=response_headers)
        except requests.Timeout:
            log.error(f'[STREAM] Timeout for {path}')
            return jsonify({'error': 'stream timeout'}), 504
        except Exception as e:
            log.error(f'[STREAM] Error for {path}: {e}')
            return jsonify({'error': str(e)}), 502

    register_ym_import_routes(app)

    return app


_ym_import_state = {
    'status': 'idle',
    'progress': 0,
    'total': 0,
    'found': 0,
    'not_found': 0,
    'liked': 0,
    'like_errors': 0,
    'skipped': 0,
    'auto_skipped': 0,
    'tracks': [],
    'not_found_list': [],
    'ym_tracks_remaining': [],
    'error': None,
    'cancel': False,
    'pause': False,
    'pause_message': '',
    'token': '',
    'session_id': '',
    'backend_url': '',
}
_ym_import_lock = threading.Lock()

_ym_import_save_path = None

def _save_import_progress():
    """Save current import progress to disk for crash recovery."""
    if not _ym_import_save_path:
        return
    try:
        with _ym_import_lock:
            state = {
                'status': _ym_import_state['status'],
                'progress': _ym_import_state['progress'],
                'total': _ym_import_state['total'],
                'found': _ym_import_state['found'],
                'not_found': _ym_import_state['not_found'],
                'liked': _ym_import_state['liked'],
                'like_errors': _ym_import_state['like_errors'],
                'skipped': _ym_import_state.get('skipped', 0),
                'auto_skipped': _ym_import_state.get('auto_skipped', 0),
                'tracks': _ym_import_state['tracks'],
                'not_found_list': _ym_import_state['not_found_list'],
                'ym_tracks_remaining': _ym_import_state.get('ym_tracks_remaining', []),
                'token': _ym_import_state.get('token', ''),
                'session_id': _ym_import_state.get('session_id', ''),
                'backend_url': _ym_import_state.get('backend_url', ''),
                '_liking_phase': _ym_import_state.get('_liking_phase', False),
                '_tracks_to_like': _ym_import_state.get('_tracks_to_like'),
                '_like_total': _ym_import_state.get('_like_total', 0),
                '_like_progress': _ym_import_state.get('_like_progress', 0),
                'saved_at': __import__('time').time(),
            }
        import json as _json
        tmp = _ym_import_save_path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            _json.dump(state, f, ensure_ascii=False)
        os.replace(tmp, _ym_import_save_path)
    except Exception as e:
        log.warning(f'[YM Import] Failed to save progress: {e}')

def _load_import_progress():
    """Load saved import progress from disk (crash recovery)."""
    if not _ym_import_save_path or not os.path.exists(_ym_import_save_path):
        return None
    try:
        import json as _json
        with open(_ym_import_save_path, 'r', encoding='utf-8') as f:
            state = _json.load(f)
        if state.get('status') in ('searching', 'liking', 'paused'):
            remaining = state.get('ym_tracks_remaining', [])
            tracks_to_like = state.get('_tracks_to_like')
            if remaining or tracks_to_like:
                log.info(f'[YM Import] Found saved progress: status={state["status"]}, '
                         f'found={state["found"]}, remaining={len(remaining)}, '
                         f'tracks_to_like={len(tracks_to_like) if tracks_to_like else 0}')
                return state
        return None
    except Exception as e:
        log.warning(f'[YM Import] Failed to load saved progress: {e}')
        return None

def _clear_import_progress():
    """Delete saved progress file."""
    if _ym_import_save_path and os.path.exists(_ym_import_save_path):
        try:
            os.remove(_ym_import_save_path)
        except Exception:
            pass


def _reset_ym_import():
    with _ym_import_lock:
        _ym_import_state.update({
            'status': 'idle', 'progress': 0, 'total': 0,
            'found': 0, 'not_found': 0, 'liked': 0, 'like_errors': 0, 'skipped': 0, 'auto_skipped': 0,
            'tracks': [], 'not_found_list': [], 'ym_tracks_remaining': [],
            'error': None, 'cancel': False, 'pause': False, 'pause_message': '',
            'token': '', 'session_id': '', 'backend_url': '',
            '_liking_phase': False, '_tracks_to_like': None,
            '_like_total': 0, '_like_progress': 0,
        })
    _clear_import_progress()


def _do_ym_import(token, session_id, backend_url, resume_tracks=None):
    """Background thread: fetch YM likes → search SC → like immediately on find."""
    import time as _time

    log.info(f'[YM Import] Thread started (resume={resume_tracks is not None})')

    try:
        _do_ym_import_inner(token, session_id, backend_url, resume_tracks)
    except Exception as e:
        log.error(f'[YM Import] Thread crashed: {e}', exc_info=True)
        with _ym_import_lock:
            _ym_import_state['status'] = 'error'
            _ym_import_state['error'] = f'Критическая ошибка импорта: {str(e)}'


def _do_ym_import_inner(token, session_id, backend_url, resume_tracks=None):
    """Inner import logic — separated so _do_ym_import can catch all exceptions."""
    import time as _time

    with _ym_import_lock:
        _ym_import_state['token'] = token
        _ym_import_state['session_id'] = session_id
        _ym_import_state['backend_url'] = backend_url

    headers = {}
    if session_id:
        headers['x-session-id'] = session_id

    if resume_tracks is not None:
        ym_tracks = resume_tracks
        with _ym_import_lock:
            if _ym_import_state.get('_liking_phase'):
                _ym_import_state['status'] = 'liking'
            else:
                _ym_import_state['status'] = 'searching'
            _ym_import_state['pause'] = False
            _ym_import_state['pause_message'] = ''
        log.info(f'[YM Import] Resuming with {len(ym_tracks)} remaining tracks (liking_phase={_ym_import_state.get("_liking_phase", False)})')
    else:
        with _ym_import_lock:
            _ym_import_state['status'] = 'fetching'
            _ym_import_state['progress'] = 0

        try:
            log.info('[YM Import] Importing yandex_music library...')
            from yandex_music import Client as YMClient
            log.info('[YM Import] yandex_music imported OK, initializing client...')
            ym = YMClient(token).init()
            log.info('[YM Import] YM client initialized, fetching likes...')
            likes = ym.users_likes_tracks()
            if not likes:
                with _ym_import_lock:
                    _ym_import_state['status'] = 'error'
                    _ym_import_state['error'] = 'Не удалось получить лайкнутые треки. Проверьте токен.'
                return

            track_ids = []
            for lt in likes:
                tid = getattr(lt, 'id', None)
                aid = getattr(lt, 'album_id', None)
                if tid:
                    track_ids.append(f"{tid}:{aid}" if aid else str(tid))

            log.info(f'[YM Import] Got {len(track_ids)} track IDs from likes')

            ym_tracks = []
            batch_size = 50
            for i in range(0, len(track_ids), batch_size):
                if _ym_import_state.get('cancel'):
                    with _ym_import_lock:
                        _ym_import_state['status'] = 'idle'
                    return
                batch = track_ids[i:i + batch_size]
                try:
                    fetched = ym.tracks(batch)
                    for t in fetched:
                        artists = ''
                        try:
                            artists = ', '.join([a.name for a in (t.artists or [])]) if t.artists else ''
                        except Exception:
                            pass
                        cover = ''
                        try:
                            if t.cover_uri:
                                cover = 'https://' + t.cover_uri.replace('%%', '200x200')
                            elif t.albums and t.albums[0].cover_uri:
                                cover = 'https://' + t.albums[0].cover_uri.replace('%%', '200x200')
                        except Exception:
                            pass
                        ym_tracks.append({
                            'title': getattr(t, 'title', '') or '',
                            'artist': artists,
                            'duration_ms': getattr(t, 'duration_ms', 0) or 0,
                            'ym_artwork': cover,
                        })
                except Exception as e:
                    log.warning(f'[YM Import] Batch fetch error (batch {i//batch_size}): {e}')
                    for tid_full in batch:
                        try:
                            plain_id = tid_full.split(':')[0]
                            single = ym.tracks([plain_id])
                            if single:
                                t = single[0]
                                artists = ''
                                try:
                                    artists = ', '.join([a.name for a in (t.artists or [])]) if t.artists else ''
                                except Exception:
                                    pass
                                cover = ''
                                try:
                                    if t.cover_uri:
                                        cover = 'https://' + t.cover_uri.replace('%%', '200x200')
                                except Exception:
                                    pass
                                ym_tracks.append({
                                    'title': getattr(t, 'title', '') or '',
                                    'artist': artists,
                                    'duration_ms': getattr(t, 'duration_ms', 0) or 0,
                                    'ym_artwork': cover,
                                })
                        except Exception:
                            continue

                with _ym_import_lock:
                    _ym_import_state['progress_fetch'] = len(ym_tracks)

            with _ym_import_lock:
                _ym_import_state['_original_total'] = len(ym_tracks)
                _ym_import_state['total'] = len(ym_tracks)
                _ym_import_state['status'] = 'searching'

            ym_tracks.reverse()

            log.info(f'[YM Import] Fetched {len(ym_tracks)} liked tracks from Yandex Music (reversed: oldest first)')

            already_found_titles = set()
            try:
                import json as _json
                appdata = os.path.dirname(_ym_import_save_path) if _ym_import_save_path else None
                storage_path = os.path.join(appdata, 'storage.json') if appdata else None

                if storage_path and os.path.exists(storage_path):
                    with open(storage_path, 'r', encoding='utf-8') as sf:
                        stor = _json.load(sf)
                    playlists = stor.get('playlists', [])
                    ym_pl = None
                    for pl in playlists:
                        if pl.get('isYandex') or pl.get('title') == 'Яндекс Музыка':
                            ym_pl = pl
                            break
                    if ym_pl and ym_pl.get('tracks'):
                        for t in ym_pl['tracks']:
                            title = (t.get('title') or '').lower().strip()
                            if title:
                                already_found_titles.add(title)
                        log.info(f'[YM Import] Found existing YM playlist with {len(already_found_titles)} tracks — will skip already-imported')
                    else:
                        log.info('[YM Import] No existing YM playlist found — importing from scratch')
                else:
                    log.info('[YM Import] No storage.json found — importing from scratch')
            except Exception as e:
                log.warning(f'[YM Import] Could not read existing playlist: {e}')

            if already_found_titles:
                before = len(ym_tracks)
                ym_tracks_filtered = []
                skipped_auto = 0
                for yt in ym_tracks:
                    yt_title = (yt.get('title') or '').lower().strip()
                    if yt_title and yt_title in already_found_titles:
                        skipped_auto += 1
                    else:
                        ym_tracks_filtered.append(yt)
                ym_tracks = ym_tracks_filtered
                with _ym_import_lock:
                    _ym_import_state['total'] = before
                    _ym_import_state['skipped'] = 0
                    _ym_import_state['auto_skipped'] = skipped_auto
                    _ym_import_state['progress'] = skipped_auto
                log.info(f'[YM Import] Auto-skipped {skipped_auto} already-imported tracks ({before} → {len(ym_tracks)} remaining)')

        except ImportError:
            with _ym_import_lock:
                _ym_import_state['status'] = 'error'
                _ym_import_state['error'] = 'Библиотека yandex-music не установлена. Выполните: pip install yandex-music'
            return
        except Exception as e:
            with _ym_import_lock:
                _ym_import_state['status'] = 'error'
                _ym_import_state['error'] = f'Ошибка Яндекс Музыки: {str(e)}'
            return

    found_tracks = list(_ym_import_state.get('tracks', []))
    not_found_list = list(_ym_import_state.get('not_found_list', []))
    skipped = _ym_import_state.get('skipped', 0)
    delay = 0.4

    liked_ids = set()
    if session_id:
        try:
            offset = 0
            for _ in range(15):
                lresp = requests.get(f'{backend_url}/me/likes/tracks',
                                     headers=headers, params={'limit': 200, 'offset': offset}, timeout=15)
                if lresp.status_code != 200:
                    break
                ldata = lresp.json()
                col = ldata.get('collection', []) if isinstance(ldata, dict) else ldata
                if not col:
                    break
                for t in col:
                    tid = t.get('id')
                    if tid:
                        liked_ids.add(tid)
                offset += len(col)
                if len(col) < 200:
                    break
                _time.sleep(0.3)
            log.info(f'[YM Import] Pre-fetched {len(liked_ids)} already-liked track IDs')
        except Exception as e:
            log.warning(f'[YM Import] Failed to pre-fetch liked IDs: {e}')

    is_liking_resume = _ym_import_state.get('_liking_phase', False)

    if not is_liking_resume:
        for idx, ym_t in enumerate(ym_tracks):
            if _ym_import_state.get('cancel'):
                with _ym_import_lock:
                    _ym_import_state['ym_tracks_remaining'] = ym_tracks[idx:]
                    _ym_import_state['status'] = 'paused'
                return

            query = f"{ym_t['artist']} {ym_t['title']}".strip()
            if not query:
                not_found_list.append(ym_t)
                with _ym_import_lock:
                    _ym_import_state['progress'] = _ym_import_state.get('progress', 0) + 1
                    _ym_import_state['not_found'] = len(not_found_list)
                    _ym_import_state['not_found_list'] = not_found_list
                continue

            sc_track = None
            for attempt in range(2):
                try:
                    url = f'{backend_url}/search/tracks'
                    params = {'q': query, 'limit': 5, 'offset': 0, 'linked_partitioning': 1}
                    resp = requests.get(url, headers=headers, params=params, timeout=10)

                    if resp.status_code == 429:
                        retry_after = int(resp.headers.get('Retry-After', delay * 3))
                        log.warning(f'[YM Import] Search 429, waiting {retry_after}s')
                        _time.sleep(min(retry_after, 15))
                        delay = min(delay * 2, 5)
                        continue

                    if resp.status_code == 200:
                        data = resp.json()
                        collection = data if isinstance(data, list) else data.get('collection', [])
                        for sc in collection:
                            sc_title = (sc.get('title') or '').lower()
                            sc_artist = (sc.get('user', {}).get('username') or '').lower()
                            ym_title_l = ym_t['title'].lower()
                            ym_artist_l = ym_t['artist'].lower()
                            title_match = ym_title_l in sc_title or sc_title in ym_title_l
                            artist_match = any(a.strip().lower() in sc_artist or sc_artist in a.strip().lower()
                                              for a in ym_artist_l.split(','))
                            if title_match or (artist_match and len(ym_title_l) > 2):
                                sc_track = sc
                                break
                        if not sc_track and collection:
                            sc_track = collection[0]
                        break
                    elif resp.status_code == 404:
                        url2 = f'{backend_url}/tracks'
                        resp2 = requests.get(url2, headers=headers, params={'q': query, 'limit': 5}, timeout=15)
                        if resp2.status_code == 200:
                            data2 = resp2.json()
                            collection2 = data2 if isinstance(data2, list) else data2.get('collection', [])
                            if collection2:
                                sc_track = collection2[0]
                        break
                    else:
                        break
                except requests.Timeout:
                    break
                except Exception as e:
                    log.warning(f'[YM Import] Search error for "{query}": {e}')
                    break

            if sc_track:
                found_tracks.append({
                    'id': sc_track.get('id'),
                    'urn': sc_track.get('urn') or f"soundcloud:tracks:{sc_track.get('id')}",
                    'title': sc_track.get('title', ''),
                    'user': {'username': sc_track.get('user', {}).get('username', ''), 'urn': sc_track.get('user', {}).get('urn', ''), 'permalink': sc_track.get('user', {}).get('permalink', ''), 'avatar_url': sc_track.get('user', {}).get('avatar_url', '')},
                    'artwork_url': sc_track.get('artwork_url'),
                    'duration': sc_track.get('duration', 0),
                    'permalink_url': sc_track.get('permalink_url', ''),
                    'playback_count': sc_track.get('playback_count', 0),
                    'likes_count': sc_track.get('likes_count', sc_track.get('favoritings_count', 0)),
                    'genre': sc_track.get('genre', ''),
                })
                track_id = sc_track.get('id')
                if track_id and track_id in liked_ids:
                    skipped += 1
            else:
                not_found_list.append(ym_t)

            with _ym_import_lock:
                _ym_import_state['progress'] = _ym_import_state.get('progress', 0) + 1
                _ym_import_state['found'] = len(found_tracks)
                _ym_import_state['not_found'] = len(not_found_list)
                _ym_import_state['skipped'] = skipped
                _ym_import_state['tracks'] = found_tracks
                _ym_import_state['not_found_list'] = not_found_list
                _ym_import_state['ym_tracks_remaining'] = ym_tracks[idx + 1:]

            if (idx + 1) % 10 == 0:
                _save_import_progress()

            if _ym_import_state.get('pause'):
                with _ym_import_lock:
                    _ym_import_state['status'] = 'paused'
                _save_import_progress()
                return

            _time.sleep(delay)
            if delay > 0.3:
                delay = max(0.3, delay * 0.92)

        log.info(f'[YM Import] Phase 1 complete: {len(found_tracks)} found, {len(not_found_list)} not found, {skipped} already liked')

        with _ym_import_lock:
            _ym_import_state['tracks'] = found_tracks
            _ym_import_state['not_found_list'] = not_found_list
            _ym_import_state['skipped'] = skipped

    if _ym_import_state.get('cancel'):
        with _ym_import_lock:
            _ym_import_state['status'] = 'paused'
        return

    found_tracks = list(_ym_import_state.get('tracks', []))

    tracks_to_like = _ym_import_state.get('_tracks_to_like', None)
    if tracks_to_like is None:
        tracks_to_like = []
        for t in found_tracks:
            tid = t.get('id')
            if tid and tid not in liked_ids:
                tracks_to_like.append(t)
        log.info(f'[YM Import] Phase 2: {len(tracks_to_like)} tracks to like ({skipped} already liked, skipping)')

    liked = _ym_import_state.get('liked', 0)
    like_errors = _ym_import_state.get('like_errors', 0)
    like_delay = 1.0
    consecutive_429 = 0
    max_consecutive_429 = 3

    with _ym_import_lock:
        _ym_import_state['status'] = 'liking'
        _ym_import_state['_liking_phase'] = True
        _ym_import_state['_like_total'] = len(tracks_to_like)
        _ym_import_state['_like_progress'] = liked

    for li, sc_track in enumerate(tracks_to_like):
        if _ym_import_state.get('cancel') or _ym_import_state.get('pause'):
            with _ym_import_lock:
                _ym_import_state['_tracks_to_like'] = tracks_to_like[li:]
                _ym_import_state['status'] = 'paused'
                _ym_import_state['pause_message'] = (
                    f'К сожалению, SoundCloud НЕ МОЖЕТ так много лайкать треков за короткое время. '
                    f'Мы лайкнули {liked} треков. Через пару часов вы сможете продолжить!'
                )
            _save_import_progress()
            log.info(f'[YM Import] Liking paused at {li}, {len(tracks_to_like)-li} remaining')
            return

        if not session_id:
            break

        track_id = sc_track.get('id')
        if not track_id:
            continue

        like_ok = False
        for lat in range(2):
            try:
                like_url = f'{backend_url}/likes/tracks/{track_id}'
                lresp = requests.post(like_url, headers=headers, timeout=15)
                if lresp.status_code in (200, 201, 204):
                    like_ok = True
                    consecutive_429 = 0
                    liked_ids.add(track_id)
                    break
                elif lresp.status_code == 429:
                    consecutive_429 += 1
                    if consecutive_429 >= max_consecutive_429:
                        log.warning('[YM Import] Rate limit on likes — pausing')
                        with _ym_import_lock:
                            _ym_import_state['liked'] = liked
                            _ym_import_state['like_errors'] = like_errors
                            _ym_import_state['_tracks_to_like'] = tracks_to_like[li:]
                            _ym_import_state['status'] = 'paused'
                            _ym_import_state['pause'] = True
                            _ym_import_state['pause_message'] = (
                                f'К сожалению, SoundCloud НЕ МОЖЕТ так много лайкать треков за короткое время. '
                                f'Мы лайкнули {liked} треков. Через пару часов вы сможете продолжить! '
                                f'Иногда вы можете зайти на сайт SoundCloud подтвердить что это вы лайкаете треки, тогда импорт продолжится!'
                            )
                        _save_import_progress()
                        return
                    retry_after = int(lresp.headers.get('Retry-After', like_delay * 4))
                    _time.sleep(min(retry_after, 30))
                    like_delay = min(like_delay * 2, 15)
                    continue
                elif lresp.status_code in (401, 403):
                    break
                else:
                    break
            except Exception:
                break

        if like_ok:
            liked += 1
        else:
            like_errors += 1

        with _ym_import_lock:
            _ym_import_state['liked'] = liked
            _ym_import_state['like_errors'] = like_errors
            _ym_import_state['_like_progress'] = liked

        if liked > 0 and liked % 5 == 0:
            _save_import_progress()

        _time.sleep(like_delay)
        if like_delay > 0.7 and consecutive_429 == 0:
            like_delay = max(0.7, like_delay * 0.93)

    with _ym_import_lock:
        _ym_import_state['status'] = 'done'
        _ym_import_state['tracks'] = found_tracks
        _ym_import_state['not_found_list'] = not_found_list
        _ym_import_state['ym_tracks_remaining'] = []
        _ym_import_state['_tracks_to_like'] = None
        _ym_import_state['_liking_phase'] = False

    log.info(f'[YM Import] Complete: {len(found_tracks)} found, {len(not_found_list)} not found, {liked} liked, {skipped} skipped')
    _clear_import_progress()


def register_ym_import_routes(app):
    """Register Yandex Music import routes on the Flask app."""

    global _ym_import_save_path
    _ym_import_save_path = os.path.join(app.config.get('APPDATA_DIR', os.path.expanduser('~')), 'ym_import_progress.json')

    saved = _load_import_progress()
    if saved:
        with _ym_import_lock:
            for key in ('progress', 'total', 'found', 'not_found', 'liked',
                        'like_errors', 'skipped', 'auto_skipped', 'tracks', 'not_found_list',
                        'ym_tracks_remaining', 'token', 'session_id', 'backend_url',
                        '_liking_phase', '_tracks_to_like', '_like_total', '_like_progress'):
                if key in saved:
                    _ym_import_state[key] = saved[key]
            _ym_import_state['status'] = 'paused'
            _ym_import_state['pause'] = True
            _ym_import_state['cancel'] = False
        log.info(f'[YM Import] Restored saved progress from disk (found={saved.get("found",0)}, remaining={len(saved.get("ym_tracks_remaining",[]))})')

    @app.route('/local/ym_import/start', methods=['POST'])
    def ym_import_start():
        data = request.get_json(force=True, silent=True) or {}
        token = data.get('token', '').strip()
        if not token:
            log.warning('[YM Import] Start called without token')
            return jsonify({'ok': False, 'error': 'Токен Яндекс Музыки не указан'}), 400

        if _ym_import_state['status'] in ('fetching', 'searching', 'liking'):
            log.warning(f'[YM Import] Start rejected — already running (status={_ym_import_state["status"]})')
            return jsonify({'ok': False, 'error': 'Импорт уже запущен'}), 409

        _reset_ym_import()
        session_id = data.get('sessionId', '') or request.headers.get('x-session-id', '')
        backend = get_active_backend()

        log.info(f'[YM Import] Starting import thread (token=***{token[-4:] if len(token)>4 else "?"}, session={"yes" if session_id else "no"}, backend={backend})')

        t = threading.Thread(target=_do_ym_import, args=(token, session_id, backend),
                            daemon=True, name='ym-import')
        t.start()
        return jsonify({'ok': True})

    @app.route('/local/ym_import/saved_state', methods=['GET'])
    def ym_import_saved_state():
        """Check if there is saved import progress from a crash/close."""
        with _ym_import_lock:
            if _ym_import_state['status'] in ('fetching', 'searching', 'liking', 'paused'):
                return jsonify({
                    'has_saved': True,
                    'status': _ym_import_state['status'],
                    'found': _ym_import_state['found'],
                    'not_found': _ym_import_state['not_found'],
                    'liked': _ym_import_state['liked'],
                    'skipped': _ym_import_state.get('skipped', 0),
                    'total': _ym_import_state['total'],
                    'progress': _ym_import_state['progress'],
                    'remaining': len(_ym_import_state.get('ym_tracks_remaining', [])),
                    'tracks_to_like': len(_ym_import_state.get('_tracks_to_like') or []),
                    '_liking_phase': _ym_import_state.get('_liking_phase', False),
                })
        return jsonify({'has_saved': False})

    @app.route('/local/ym_import/resume', methods=['POST'])
    def ym_import_resume():
        """Resume a paused import from where it stopped."""
        with _ym_import_lock:
            if _ym_import_state['status'] != 'paused':
                return jsonify({'ok': False, 'error': 'Импорт не приостановлен'}), 400
            is_liking = _ym_import_state.get('_liking_phase', False)
            remaining = list(_ym_import_state.get('ym_tracks_remaining', []))
            tracks_to_like = _ym_import_state.get('_tracks_to_like', None)
            token = _ym_import_state.get('token', '')
            session_id = _ym_import_state.get('session_id', '')
            backend = _ym_import_state.get('backend_url', '') or get_active_backend()

        if is_liking:
            if not tracks_to_like or len(tracks_to_like) == 0:
                with _ym_import_lock:
                    _ym_import_state['status'] = 'done'
                return jsonify({'ok': True, 'message': 'Все треки уже лайкнуты'})
            log.info(f'[YM Import] Resuming LIKING phase: {len(tracks_to_like)} tracks to like')
        else:
            if not remaining:
                with _ym_import_lock:
                    _ym_import_state['status'] = 'done'
                return jsonify({'ok': True, 'message': 'Нечего продолжать'})

        test_ok = False
        try:
            headers = {}
            if session_id:
                headers['x-session-id'] = session_id
            resp = requests.get(f'{backend}/me', headers=headers, timeout=10)
            test_ok = resp.status_code == 200
        except Exception:
            test_ok = True

        resume_tracks = [] if is_liking else remaining

        t = threading.Thread(target=_do_ym_import, args=(token, session_id, backend, resume_tracks),
                            daemon=True, name='ym-import-resume')
        t.start()
        return jsonify({'ok': True, 'remaining': len(tracks_to_like or remaining)})

    @app.route('/local/ym_import/status', methods=['GET'])
    def ym_import_status():
        with _ym_import_lock:
            return jsonify({
                'status': _ym_import_state['status'],
                'progress': _ym_import_state['progress'],
                'total': _ym_import_state['total'],
                'found': _ym_import_state['found'],
                'not_found': _ym_import_state['not_found'],
                'liked': _ym_import_state['liked'],
                'like_errors': _ym_import_state['like_errors'],
                'skipped': _ym_import_state.get('skipped', 0),
                'auto_skipped': _ym_import_state.get('auto_skipped', 0),
                'error': _ym_import_state['error'],
                'pause_message': _ym_import_state.get('pause_message', ''),
                'remaining': len(_ym_import_state.get('ym_tracks_remaining', [])),
                'like_total': _ym_import_state.get('_like_total', 0),
                'like_progress': _ym_import_state.get('_like_progress', 0),
                '_liking_phase': _ym_import_state.get('_liking_phase', False),
                'tracks_to_like': len(_ym_import_state.get('_tracks_to_like') or []),
            })

    @app.route('/local/ym_import/results', methods=['GET'])
    def ym_import_results():
        with _ym_import_lock:
            return jsonify({
                'tracks': _ym_import_state['tracks'],
                'not_found_list': _ym_import_state['not_found_list'],
            })

    @app.route('/local/ym_import/not_found', methods=['GET'])
    def ym_import_not_found():
        """Get the list of not-found tracks (for the sidebar tab)."""
        with _ym_import_lock:
            return jsonify({'not_found_list': _ym_import_state['not_found_list']})

    @app.route('/local/ym_import/manual_search', methods=['POST'])
    def ym_import_manual_search():
        """Search SoundCloud for a track manually."""
        data = request.get_json(force=True, silent=True) or {}
        query = data.get('query', '').strip()
        if not query:
            return jsonify({'ok': False, 'error': 'Пустой запрос'}), 400

        session_id = data.get('sessionId', '') or _ym_import_state.get('session_id', '')
        backend = _ym_import_state.get('backend_url', '') or get_active_backend()
        headers = {}
        if session_id:
            headers['x-session-id'] = session_id

        try:
            url = f'{backend}/search/tracks'
            params = {'q': query, 'limit': 10, 'offset': 0, 'linked_partitioning': 1}
            resp = requests.get(url, headers=headers, params=params, timeout=15)
            if resp.status_code == 200:
                result = resp.json()
                collection = result if isinstance(result, list) else result.get('collection', [])
                return jsonify({'ok': True, 'collection': collection})
            return jsonify({'ok': False, 'error': f'SC returned {resp.status_code}'}), 200
        except Exception as e:
            return jsonify({'ok': False, 'error': str(e)}), 200

    @app.route('/local/ym_import/like_track', methods=['POST'])
    def ym_import_like_track():
        """Like a single SC track and remove from not_found_list."""
        data = request.get_json(force=True, silent=True) or {}
        track_id = data.get('trackId')
        nf_index = data.get('nfIndex')

        session_id = data.get('sessionId', '') or _ym_import_state.get('session_id', '')
        backend = _ym_import_state.get('backend_url', '') or get_active_backend()
        headers = {}
        if session_id:
            headers['x-session-id'] = session_id

        like_ok = False
        if track_id:
            try:
                like_url = f'{backend}/likes/tracks/{track_id}'
                resp = requests.post(like_url, headers=headers, timeout=15)
                like_ok = resp.status_code in (200, 201, 204)
                if resp.status_code == 429:
                    return jsonify({'ok': False, 'error': 'rate_limit', 'message': 'Лимит ещё не снят! Повторите позже!'}), 200
            except Exception as e:
                return jsonify({'ok': False, 'error': str(e)}), 200

        if nf_index is not None:
            with _ym_import_lock:
                nfl = _ym_import_state['not_found_list']
                if 0 <= nf_index < len(nfl):
                    nfl.pop(nf_index)
                    _ym_import_state['not_found'] = len(nfl)

        return jsonify({'ok': like_ok, 'not_found_count': len(_ym_import_state['not_found_list'])})

    @app.route('/local/ym_import/remove_not_found', methods=['POST'])
    def ym_import_remove_not_found():
        """Remove a track from not_found_list (user confirmed it doesn't exist)."""
        data = request.get_json(force=True, silent=True) or {}
        nf_index = data.get('nfIndex')
        if nf_index is None:
            return jsonify({'ok': False}), 400
        with _ym_import_lock:
            nfl = _ym_import_state['not_found_list']
            if 0 <= nf_index < len(nfl):
                nfl.pop(nf_index)
                _ym_import_state['not_found'] = len(nfl)
        return jsonify({'ok': True, 'not_found_count': len(_ym_import_state['not_found_list'])})

    @app.route('/local/ym_import/clear_not_found', methods=['POST'])
    def ym_import_clear_not_found():
        """Clear ALL not_found tracks."""
        with _ym_import_lock:
            _ym_import_state['not_found_list'] = []
            _ym_import_state['not_found'] = 0
        _save_import_progress()
        log.info('[YM Import] All not-found tracks cleared by user')
        return jsonify({'ok': True})

    @app.route('/local/ym_import/cancel', methods=['POST'])
    def ym_import_cancel():
        with _ym_import_lock:
            _ym_import_state['cancel'] = True
            _ym_import_state['pause'] = True
        _save_import_progress()
        return jsonify({'ok': True})

    @app.route('/local/ym_import/reset', methods=['POST'])
    def ym_import_reset():
        _reset_ym_import()
        return jsonify({'ok': True})
